from __future__ import annotations

import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
OUT = ROOT.parent / f"NESK_{VERSION}_FirstListen.zip"
EXCLUDED_PARTS = {
    ".venv",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "build",
    "dist",
    "release",
    "support",
    "work",
    ".git",
}
EXCLUDED_FILENAMES = {".coverage"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".spec"}
_RUNTIME_ARTIFACT_SUFFIXES = (
    ".log",
    ".log.1",
    ".db",
    ".db-journal",
    ".db-wal",
    ".db-shm",
    ".sqlite",
    ".sqlite-journal",
    ".sqlite-wal",
    ".sqlite-shm",
    ".sqlite3",
    ".sqlite3-journal",
    ".sqlite3-wal",
    ".sqlite3-shm",
)


def include(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    # ``--basetemp`` is sometimes pointed at the project root on restricted
    # Windows profiles.  Treat its pytest scratch directories as runtime
    # artifacts so source packaging cannot accidentally include generated
    # config/database fixtures.
    if any(
        part in EXCLUDED_PARTS or part.endswith(".egg-info") or part.startswith("pytest-")
        for part in rel.parts
    ):
        return False
    name = path.name.lower()
    if name in EXCLUDED_FILENAMES:
        return False
    if name == ".env" or name.startswith(".env."):
        return False
    if name.endswith(_RUNTIME_ARTIFACT_SUFFIXES) or ".log." in name:
        return False
    if path.suffix in EXCLUDED_SUFFIXES:
        return False
    return path.is_file()


def main() -> None:
    if OUT.exists():
        OUT.unlink()
    prefix = f"NESK_{VERSION}_FirstListen"
    with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in sorted(ROOT.rglob("*")):
            if include(path):
                arc = Path(prefix) / path.relative_to(ROOT)
                zf.write(path, arc.as_posix())
    print(OUT)


if __name__ == "__main__":
    main()
