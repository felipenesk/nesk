from __future__ import annotations

import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(label: str, command: list[str], *, env: dict[str, str] | None = None) -> None:
    print(f"\n== {label} ==")
    merged = os.environ.copy()
    merged["PYTHONPATH"] = str(ROOT / "src") + os.pathsep + merged.get("PYTHONPATH", "")
    if env:
        merged.update(env)
    subprocess.run(command, cwd=ROOT, check=True, env=merged)


def versions() -> str:
    version_file = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    version_py = (ROOT / "src/nesk/version.py").read_text(encoding="utf-8")
    py_match = re.search(r'__version__\s*=\s*["\']([^"\']+)', version_py)
    project = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    project_match = re.search(r'^version\s*=\s*"([^"]+)"', project, flags=re.MULTILINE)
    values = {version_file, py_match.group(1) if py_match else "", project_match.group(1) if project_match else ""}
    if len(values) != 1:
        raise SystemExit(f"Versões desalinhadas: {values}")
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    changelog = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
    if version_file not in readme or version_file not in changelog:
        raise SystemExit("README/CHANGELOG não refletem a versão atual.")
    print(f"Version sync OK: {version_file}")
    return version_file


def hygiene() -> None:
    # Developer/runtime artifacts (.venv, build, dist, caches) are allowed to
    # exist locally because release packaging filters them out. Hygiene here
    # focuses on what could accidentally ship from source directories.
    credential_re = re.compile(r'(?i)(api[_-]?key|password|secret|access[_-]?token)\s*[=:]\s*["\'][^"\']{8,}["\']')
    scan_roots = [ROOT / "src", ROOT / "config", ROOT / "scripts", ROOT / "docs"]
    for scan_root in scan_roots:
        for path in scan_root.rglob("*"):
            if not path.is_file() or path.suffix not in {".py", ".json", ".md", ".bat", ".toml"}:
                continue
            if credential_re.search(path.read_text(encoding="utf-8", errors="ignore")):
                raise SystemExit(f"Possível credencial literal detectada em {path.relative_to(ROOT)}")
    print("Source hygiene OK")


def clean_install_test() -> None:
    with tempfile.TemporaryDirectory(prefix="nesk-install-") as td:
        target = Path(td) / "site"
        run(
            "Clean package install",
            [sys.executable, "-m", "pip", "install", "--quiet", "--no-deps", "--no-build-isolation", "--target", str(target), "."],
        )
        code = (
            "import nesk; "
            "from nesk.core.intent_router import LocalIntentRouter; "
            "from nesk.platform.windows.program_directory import ProgramDirectory; "
            "assert nesk.__version__; "
            "assert LocalIntentRouter().route('abre Discord'); "
            "assert 'discord' in ProgramDirectory.static().allowed_programs(); "
            "print('clean_install_ok')"
        )
        env = {"PYTHONPATH": str(target)}
        # Run outside source cwd so imports cannot accidentally fall back to ./src.
        subprocess.run([sys.executable, "-c", code], cwd=td, check=True, env={**os.environ, **env})


def main() -> None:
    version = versions()
    hygiene()
    run("Compile", [sys.executable, "-m", "compileall", "-q", "src", "scripts", "tests"])
    # The release check does not need pytest's mutable cache. Some restricted
    # Windows profiles also deny pytest's scan of its global temp root, so use
    # one private base directory adjacent to the source tree for this run.
    with tempfile.TemporaryDirectory(prefix="nesk-pytest-", dir=ROOT.parent) as test_tmp:
        run(
            "Tests",
            [
                sys.executable,
                "-m",
                "pytest",
                "-q",
                "-p",
                "no:cacheprovider",
                "--basetemp",
                test_tmp,
            ],
        )
    run("Smoke", [sys.executable, "scripts/smoke_test.py"])
    with tempfile.TemporaryDirectory(prefix="nesk-selfcheck-") as td:
        run("Headless self-check", [sys.executable, "-m", "nesk.app", "--self-check"], env={"NESK_DATA_DIR": td, "NESK_AI_PROVIDER": "local"})
    clean_install_test()
    print(f"\nRELEASE CHECK OK — NESK {version}")


if __name__ == "__main__":
    main()
