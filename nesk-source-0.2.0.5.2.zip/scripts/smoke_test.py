from __future__ import annotations

import tempfile
from pathlib import Path

from nesk.core.assistant import NeskCore
from nesk.core.intent_router import LocalIntentRouter
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.storage.database import ConversationStore
from nesk.tools.registry import ToolRegistry
from nesk.tools.system_status import SystemStatusTool
from nesk.voice.session import VoiceSession, VoiceState


def main() -> None:
    with tempfile.TemporaryDirectory() as folder:
        store = ConversationStore(Path(folder) / "smoke.db")
        registry = ToolRegistry()
        registry.register(SystemStatusTool())
        core = NeskCore(provider=LocalFallbackProvider(), store=store, tools=registry)

        print("[1] Conversa:", core.handle("Oi NESK").text)
        print("[2] Sistema:", core.handle("quanto de RAM estou usando?").text)
        print("[3] Histórico:", len(store.recent(10)), "mensagens")

        router = LocalIntentRouter()
        natural = router.route("Nesk bota o navegador aí")
        search = router.route("pesquisa Dragonsteel no YouTube")
        assert natural and natural.name == "browser.open_default"
        assert search and search.name == "browser.search" and search.args["engine"] == "youtube"
        print("[4] NLU natural: OK")

        voice = VoiceSession()
        voice.transition(VoiceState.IDLE)
        voice.transition(VoiceState.LISTENING)
        voice.transition(VoiceState.TRANSCRIBING)
        voice.transition(VoiceState.PROCESSING)
        voice.transition(VoiceState.SPEAKING)
        voice.transition(VoiceState.IDLE)
        print("[5] Voice state machine: OK")

        print("SMOKE TEST OK")


if __name__ == "__main__":
    main()
