@echo off
setlocal EnableExtensions
cd /d "%~dp0\.."
set "NESK_VERSION=DEV"
if exist "VERSION" set /p NESK_VERSION=<VERSION
title NESK %NESK_VERSION% - Setup

echo ============================================================
echo                  NESK - INSTALACAO / UPDATE
echo ============================================================
echo.
echo [1/5] Procurando Python compativel...

set "PYTHON_CMD="
py -3.11 -c "import sys; print(sys.version)" >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=py -3.11"

if not defined PYTHON_CMD (
    py -3 -c "import sys; assert (3,10) <= sys.version_info[:2] < (3,15)" >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py -3"
)

if not defined PYTHON_CMD (
    python -c "import sys; assert (3,10) <= sys.version_info[:2] < (3,15)" >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD (
    echo.
    echo [ERRO] Nao encontrei Python 3.10, 3.11, 3.12, 3.13 ou 3.14.
    echo [ERRO] Para esta fase, recomendo Python 3.11 64-bit.
    goto :error
)

echo [OK] Python encontrado: %PYTHON_CMD%
echo.
echo [2/5] Preparando ambiente isolado .venv...
if not exist ".venv\Scripts\python.exe" (
    %PYTHON_CMD% -m venv .venv
    if errorlevel 1 goto :error
) else (
    echo [OK] Ambiente existente detectado; sera sincronizado.
)

echo.
echo [3/5] Atualizando instalador de pacotes...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :error

echo.
echo [4/5] Instalando NESK + First Listen...
".venv\Scripts\python.exe" -m pip install -e ".[voice]"
if errorlevel 1 goto :error

echo.
echo [5/5] Validando dependencias basicas de voz...
".venv\Scripts\python.exe" -c "import numpy, sounddevice, faster_whisper; print('[OK] Voice stack importada.')"
if errorlevel 1 goto :error

> ".venv\.nesk_setup_version" echo %NESK_VERSION%

echo.
echo ============================================================
echo [OK] NESK %NESK_VERSION% First Listen instalado com sucesso.
echo ============================================================
echo [INFO] O modelo STT local e baixado apenas no primeiro uso do botao de voz.
echo.
if /I "%~1"=="--from-launcher" exit /b 0
pause
exit /b 0

:error
echo.
echo ============================================================
echo [FALHA] A instalacao nao foi concluida.
echo ============================================================
echo Copie o erro acima ou tire um print e envie para revisao.
echo.
if /I "%~1"=="--from-launcher" exit /b 1
pause
exit /b 1
