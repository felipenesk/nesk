from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from diagnostics import collect, project_root


def main() -> None:
    support = project_root() / "support"
    support.mkdir(exist_ok=True)
    target = support / "NESK_DIAGNOSTICO_SEGURO.json"
    payload = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "diagnostics": collect(),
        "note": "Relatório deliberadamente sem chaves, mensagens, logs ou caminhos pessoais.",
    }
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Relatório seguro criado em: {target.relative_to(project_root())}")


if __name__ == "__main__":
    main()
