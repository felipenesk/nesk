from __future__ import annotations

import difflib
import os
import re
import sys
import unicodedata
from pathlib import Path

import psutil

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from nesk.core.config import load_config  # noqa: E402
from nesk.version import __version__  # noqa: E402
from nesk.voice.capture import MicrophoneError  # noqa: E402
from nesk.voice.pipeline import SpeechPipeline  # noqa: E402


PHRASES = [
    "NESK, abre o Discord.",
    "NESK, fecha o Discord.",
    "NESK, abre o YouTube para mim.",
    "NESK, pesquisa Minecraft 1.12.2.",
    "Abre o Discord.",
    "Fecha o Discord.",
    "Não.",
    "Sim.",
]


def normalize(text: str) -> str:
    decomposed = unicodedata.normalize("NFKD", text.casefold())
    plain = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return " ".join(re.findall(r"[a-z0-9.]+", plain)).strip(" .")


def _memory_mb() -> float | None:
    try:
        return psutil.Process(os.getpid()).memory_info().rss / (1024**2)
    except (psutil.Error, OSError):
        return None


def _print_turn_metrics(outcome) -> None:
    capture = outcome.capture
    diagnostics = outcome.diagnostics
    if capture is not None:
        audio = capture.audio
        print(
            "CAPTURA: "
            f"{audio.duration_seconds:.2f}s / {audio.sample_rate} Hz / "
            f"RMS {audio.rms_dbfs:.1f} dBFS / pico {audio.peak_dbfs:.1f} dBFS / "
            f"endpoint={'sim' if capture.endpoint_detected else 'timeout'}"
        )
        if capture.first_frame_latency_ms is not None:
            print(f"PRIMEIRO FRAME: {capture.first_frame_latency_ms:.0f} ms")
    if diagnostics is not None:
        print(
            "MÉTRICAS: "
            f"útil={diagnostics.prepared_audio_seconds:.2f}s / "
            f"pré={diagnostics.preprocessing_seconds:.3f}s / "
            f"STT={diagnostics.inference_seconds:.2f}s / "
            f"RTF={diagnostics.realtime_factor:.2f}x / "
            f"segmentos={diagnostics.segment_count} / "
            f"modelo={diagnostics.model_load_count} carga(s)"
        )
        if diagnostics.rejection_reason:
            print(f"REJEIÇÃO TÉCNICA: {diagnostics.rejection_reason}")
    memory = _memory_mb()
    if memory is not None:
        print(f"RAM DO PROCESSO: {memory:.0f} MB")


def main() -> int:
    print(f"NESK {__version__} — Teste de Qualidade de Voz PT-BR")
    print("Usa o mesmo SpeechPipeline da interface; não chama o Core e não salva áudio/transcrições.")
    print("Feche a interface NESK antes do benchmark para evitar dois modelos locais na RAM.")
    print("Fale normalmente e faça uma pausa curta ao terminar; endpointing encerra cada gravação.")
    print()

    config, data_root = load_config()
    pipeline = SpeechPipeline.from_config(config, data_root=data_root)
    exact = 0
    similarities: list[float] = []
    rejected = 0

    try:
        for index, expected in enumerate(PHRASES, start=1):
            print("=" * 68)
            print(f"[{index}/{len(PHRASES)}] Fale: {expected}")
            input("Pressione ENTER quando estiver pronto... ")
            try:
                print("GRAVANDO — fale agora.")
                outcome = pipeline.capture_until_endpoint()
            except (MicrophoneError, KeyboardInterrupt) as exc:
                pipeline.cancel()
                print(f"[FALHA] Captura: {exc}")
                return 1

            print(f"OUVIDO: {outcome.transcript if outcome.accepted else '<descartado>'}")
            _print_turn_metrics(outcome)
            if not outcome.accepted:
                rejected += 1
                similarities.append(0.0)
                print(f"RESULTADO: REJEITADO COM SEGURANÇA ({outcome.reason})")
                continue

            got = normalize(outcome.transcript)
            want = normalize(expected)
            score = difflib.SequenceMatcher(a=want, b=got).ratio()
            similarities.append(score)
            if got == want:
                exact += 1
                print("RESULTADO: EXATO")
            else:
                print(f"RESULTADO: DIFERENTE ({score * 100:.0f}% de similaridade textual)")
    finally:
        pipeline.close()

    average = (sum(similarities) / len(similarities)) if similarities else 0.0
    print("\n" + "=" * 68)
    print("RESUMO — somente desta execução, nada foi salvo em disco")
    print(f"frases exatas: {exact}/{len(PHRASES)}")
    print(f"similaridade média: {average * 100:.1f}%")
    print(f"falas rejeitadas com segurança: {rejected}")
    print("[OK] Teste concluído. Nenhuma ação do NESK Core foi executada.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
