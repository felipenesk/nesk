@echo off
setlocal EnableExtensions
cd /d "%~dp0\.."
set "NESK_VERSION=DEV"
if exist "VERSION" set /p NESK_VERSION=<VERSION
title NESK %NESK_VERSION% - Build EXE

if not exist ".venv\Scripts\python.exe" (
    echo [ERRO] Rode INICIAR_NESK.bat pelo menos uma vez antes do build.
    if not defined NESK_NONINTERACTIVE pause
    exit /b 1
)

".venv\Scripts\python.exe" -c "import struct,sys; sys.exit(0 if struct.calcsize(chr(80))*8 == 64 else 1)"
if errorlevel 1 (
    echo [ERRO] O build oficial de teste exige Python 64-bit.
    if not defined NESK_NONINTERACTIVE pause
    exit /b 1
)

".venv\Scripts\python.exe" -m pip install -e ".[voice,dev,exe]"
if errorlevel 1 goto :error

".venv\Scripts\python.exe" scripts\release_check.py
if errorlevel 1 goto :error

rmdir /s /q build 2>nul
rmdir /s /q dist 2>nul
rmdir /s /q release 2>nul
mkdir release

echo [NESK] Gerando executavel Windows onedir...
".venv\Scripts\python.exe" -m PyInstaller ^
  --noconfirm --clean --noupx --windowed ^
  --name NESK ^
  --paths src ^
  --collect-all faster_whisper ^
  --collect-all ctranslate2 ^
  --collect-all sounddevice ^
  --collect-all av ^
  --collect-all tokenizers ^
  --collect-all huggingface_hub ^
  src\nesk\app.py
if errorlevel 1 goto :error

set "NESK_DATA_DIR=%TEMP%\NESK_EXE_SELFTEST_%RANDOM%%RANDOM%"
echo [NESK] Validando executavel empacotado...
"dist\NESK\NESK.exe" --self-check
set "SELFTEST=%ERRORLEVEL%"
rmdir /s /q "%NESK_DATA_DIR%" 2>nul
set "NESK_DATA_DIR="
if not "%SELFTEST%"=="0" (
    echo [ERRO] O executavel foi gerado, mas falhou no self-check: %SELFTEST%.
    goto :error
)

copy README.md "dist\NESK\README.txt" >nul
copy PRIVACY.md "dist\NESK\PRIVACY.txt" >nul
copy SECURITY.md "dist\NESK\SECURITY.txt" >nul

powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'dist\NESK\*' -DestinationPath 'release\NESK_%NESK_VERSION%_Windows_x64.zip' -Force"
if errorlevel 1 goto :error

echo.
echo ============================================================
echo [OK] EXE validado: dist\NESK\NESK.exe
echo [OK] Pacote: release\NESK_%NESK_VERSION%_Windows_x64.zip
echo ============================================================
echo [AVISO] A build First Listen ainda deve ser testada manualmente com microfone no Windows 10 de referencia.
if not defined NESK_NONINTERACTIVE pause
exit /b 0

:error
echo.
echo [ERRO] Build do executavel falhou. Veja a mensagem acima.
if not defined NESK_NONINTERACTIVE pause
exit /b 1
