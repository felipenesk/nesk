from __future__ import annotations

import os
import struct
import sys
import tempfile
from pathlib import Path


def main() -> int:
    print("NESK — Preflight")
    ok = True
    version = sys.version_info[:2]
    print("Python:", sys.version.split()[0])
    if not ((3, 10) <= version < (3, 15)):
        print("[FALHA] Python precisa estar entre 3.10 e 3.14.")
        ok = False
    bits = struct.calcsize("P") * 8
    print("Arquitetura Python:", f"{bits}-bit")
    if bits != 64:
        print("[AVISO] Recomendada instalação 64-bit para o NESK.")
    if os.name != "nt":
        print("[INFO] Este preflight está fora do Windows; integrações Windows não serão validadas.")
    try:
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "write.test"
            p.write_text("ok", encoding="utf-8")
    except OSError:
        print("[FALHA] Não consegui validar escrita temporária.")
        ok = False
    print("[OK] Preflight aprovado." if ok else "[FALHA] Preflight encontrou problemas.")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
