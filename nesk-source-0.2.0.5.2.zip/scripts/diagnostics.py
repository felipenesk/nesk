from __future__ import annotations

import json
import os
import platform
import sqlite3
import sys
from importlib import metadata
from pathlib import Path


def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def project_version() -> str:
    try:
        return (project_root() / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        return "desconhecida"


def package_version(name: str) -> str:
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        return "não instalado"


def data_root() -> Path:
    override = os.getenv("NESK_DATA_DIR")
    if override:
        return Path(override).expanduser()
    local = os.getenv("LOCALAPPDATA")
    return Path(local) / "NESK" if local else Path.home() / ".nesk"


def sqlite_status(root: Path) -> tuple[str, int | None, int]:
    db = root / "nesk.db"
    if not db.exists():
        return "ainda não criado", None, 0
    try:
        with sqlite3.connect(db, timeout=2) as con:
            schema = int(con.execute("PRAGMA user_version").fetchone()[0])
            check = str(con.execute("PRAGMA quick_check").fetchone()[0])
        return check, schema, db.stat().st_size
    except (sqlite3.Error, OSError):
        return "erro ao verificar", None, 0


def collect() -> dict[str, object]:
    root = data_root()
    integrity, schema, db_bytes = sqlite_status(root)
    try:
        writable = root.exists() and os.access(root, os.W_OK)
    except OSError:
        writable = False
    return {
        "nesk_version": project_version(),
        "python": sys.version.split()[0],
        "python_64bit": sys.maxsize > 2**32,
        "os": platform.system(),
        "os_release": platform.release(),
        "machine": platform.machine(),
        "psutil": package_version("psutil"),
        "PySide6": package_version("PySide6"),
        "numpy": package_version("numpy"),
        "sounddevice": package_version("sounddevice"),
        "faster_whisper": package_version("faster-whisper"),
        "openai": package_version("openai"),
        "provider": os.getenv("NESK_AI_PROVIDER", "local"),
        "custom_data_dir": bool(os.getenv("NESK_DATA_DIR")),
        "data_dir_exists": root.exists(),
        "data_dir_writable": writable,
        "database_integrity": integrity,
        "database_schema": schema,
        "database_size_bytes": db_bytes,
        "api_key_configured": bool(os.getenv("OPENAI_API_KEY")),
    }


def main() -> None:
    print(f"NESK {project_version()} — Diagnóstico seguro")
    for key, value in collect().items():
        print(f"{key}: {value}")
    print("Observação: não imprime chaves, mensagens, nomes de usuário nem caminhos pessoais.")


if __name__ == "__main__":
    main()
