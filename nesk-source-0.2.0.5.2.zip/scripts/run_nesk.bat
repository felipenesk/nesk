@echo off
setlocal EnableExtensions
cd /d "%~dp0\.."
set "NESK_VERSION=DEV"
if exist "VERSION" set /p NESK_VERSION=<VERSION
title NESK %NESK_VERSION% - Run

if not exist ".venv\Scripts\python.exe" (
  echo [ERRO] Ambiente .venv nao encontrado.
  echo Rode scripts\setup_windows.bat primeiro ou use INICIAR_NESK.bat.
  echo.
  pause
  exit /b 1
)

echo [NESK] Iniciando...
".venv\Scripts\python.exe" -m nesk.app
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
  echo.
  echo [ERRO] NESK encerrou com codigo %EXITCODE%.
  echo Tire um print desta janela e envie para revisao.
  echo.
  pause
)
exit /b %EXITCODE%
