from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from nesk.core.config import load_config  # noqa: E402
from nesk.version import __version__  # noqa: E402
from nesk.voice.capture import MicrophoneError  # noqa: E402
from nesk.voice.pipeline import SpeechPipeline  # noqa: E402


def _print_metrics(outcome) -> None:
    capture = outcome.capture
    if capture is not None:
        audio = capture.audio
        print(f"Áudio capturado: {audio.duration_seconds:.2f}s (somente RAM)")
        print(f"nível RMS: {audio.rms_dbfs:.1f} dBFS / pico: {audio.peak_dbfs:.1f} dBFS")
        print(f"sample rate real: {audio.sample_rate} Hz / endpoint: {'sim' if capture.endpoint_detected else 'timeout/manual'}")
        if capture.first_frame_latency_ms is not None:
            print(f"primeiro frame: {capture.first_frame_latency_ms:.0f} ms")
    diagnostics = outcome.diagnostics
    if diagnostics is None:
        return
    print("\nMÉTRICAS (sem conteúdo):")
    print(f"pré-processamento: {diagnostics.preprocessing_seconds:.3f}s")
    print(f"inferência: {diagnostics.inference_seconds:.2f}s")
    print(f"fator tempo-real: {diagnostics.realtime_factor:.2f}x")
    print(f"áudio útil: {diagnostics.prepared_audio_seconds:.2f}s")
    print(f"segmentos: {diagnostics.segment_count}")
    print(f"idioma: {diagnostics.language}")
    print(f"cargas do modelo neste processo: {diagnostics.model_load_count}")
    if diagnostics.average_logprob is not None:
        print(f"confiança técnica (avg_logprob): {diagnostics.average_logprob:.3f}")
    if diagnostics.max_no_speech_probability is not None:
        print(f"no_speech máximo: {diagnostics.max_no_speech_probability:.3f}")
    if diagnostics.max_compression_ratio is not None:
        print(f"compression ratio máximo: {diagnostics.max_compression_ratio:.3f}")
    if diagnostics.rejection_reason:
        print(f"motivo técnico de rejeição: {diagnostics.rejection_reason}")


def main() -> int:
    print(f"NESK {__version__} — Probe STT PT-BR")
    print("Este teste usa o mesmo SpeechPipeline da interface, não executa comandos e não salva áudio.")
    print("Fale uma frase curta e faça uma pausa; o endpoint encerra a captura automaticamente.")
    input("Pressione ENTER para iniciar... ")

    config, data_root = load_config()
    pipeline = SpeechPipeline.from_config(config, data_root=data_root)
    try:
        try:
            print("GRAVANDO — fale agora.")
            outcome = pipeline.capture_until_endpoint()
        except (MicrophoneError, KeyboardInterrupt) as exc:
            pipeline.cancel()
            print(f"[FALHA] Captura: {exc}")
            return 1
        _print_metrics(outcome)
        print("\nTRANSCRIÇÃO:")
        print(outcome.transcript if outcome.accepted else "<descartada>")
        if not outcome.accepted:
            print(f"[REJEITADO] {outcome.reason}")
            return 1
        print("\n[OK] Probe finalizado. Nenhuma ação do Core foi executada.")
        return 0
    finally:
        pipeline.close()


if __name__ == "__main__":
    raise SystemExit(main())
