from __future__ import annotations

import sys
from importlib import metadata


def version(name: str) -> str:
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        return "não instalado"


def main() -> int:
    print("NESK — Diagnóstico First Listen")
    print("numpy:", version("numpy"))
    print("sounddevice:", version("sounddevice"))
    print("faster-whisper:", version("faster-whisper"))
    capture: dict = {}
    try:
        from nesk.core.config import load_config
        config, _ = load_config()
        voice = config.get("voice", {})
        stt = voice.get("stt", {})
        capture = voice.get("capture", {})
        print("stt_provider:", stt.get("provider", "local"))
        print("stt_language:", stt.get("language", "pt"))
        print("stt_local_model:", stt.get("local_model", "small"))
        print("stt_beam_size:", stt.get("beam_size", 5))
        print("stt_hotwords_count:", len(stt.get("hotwords", []) or []))
        print("stt_vad_filter:", bool(stt.get("vad_filter", True)))
        print("stt_log_prob_threshold:", stt.get("log_prob_threshold", -1.0))
        print("capture_min_seconds:", capture.get("min_seconds", 0.12))
        print("endpoint_speech_rms_dbfs:", capture.get("endpoint_speech_rms_dbfs", -60.0))
        print("endpoint_silence_ms:", capture.get("endpoint_silence_ms", 650))
        print("endpoint_min_speech_ms:", capture.get("endpoint_min_speech_ms", 120))
        print("raw_rms_peak_gate:", "desativado")
        print("startup_timeout_ms:", capture.get("startup_timeout_ms", 750))
        print("post_roll_ms:", capture.get("post_roll_ms", 180))
        print("capture_block_ms:", capture.get("block_ms", 20))
        print("capture_latency:", capture.get("latency", "low"))
        print("audio_storage:", bool(voice.get("store_audio", False)))
    except Exception as exc:
        print("[AVISO] Config STT não pôde ser lida:", type(exc).__name__)
    try:
        import sounddevice as sd
    except ImportError:
        print("[FALHA] sounddevice não instalado.")
        return 1

    try:
        devices = sd.query_devices()
        inputs = [d for d in devices if int(d["max_input_channels"]) > 0]
        print("microfones_detectados:", len(inputs))
        if not inputs:
            print("[AVISO] Nenhum dispositivo de entrada foi detectado.")
            return 0
        selected_device = capture.get("device")
        selected = sd.query_devices(selected_device, "input")
        actual_request = capture.get("sample_rate") or selected["default_samplerate"]
        print("microfone_configurado:", str(selected["name"]))
        print("dispositivo_configurado:", selected_device if selected_device is not None else "padrão")
        print("sample_rate_solicitado:", int(round(float(actual_request))))
        sd.check_input_settings(
            device=selected_device,
            channels=1,
            dtype="int16",
            samplerate=float(actual_request),
        )
        print("[OK] Microfone configurado aceita captura PCM16 mono.")
        return 0
    except Exception as exc:
        print(f"[AVISO] Não consegui validar o microfone configurado: {type(exc).__name__}: {exc}")
        # The rest of NESK remains usable; field testing can select/fix the mic.
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
