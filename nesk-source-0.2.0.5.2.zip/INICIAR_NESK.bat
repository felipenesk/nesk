@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "NESK_VERSION=DEV"
if exist "VERSION" set /p NESK_VERSION=<VERSION
title NESK %NESK_VERSION% - Launcher

echo ============================================================
echo                    NESK %NESK_VERSION% FIRST LISTEN
echo ============================================================
echo.

set "NEEDS_SETUP=0"
if not exist ".venv\Scripts\python.exe" set "NEEDS_SETUP=1"
if not exist ".venv\.nesk_setup_version" set "NEEDS_SETUP=1"
if exist ".venv\.nesk_setup_version" (
    set /p INSTALLED_VERSION=<.venv\.nesk_setup_version
    if /I not "%INSTALLED_VERSION%"=="%NESK_VERSION%" set "NEEDS_SETUP=1"
)

if "%NEEDS_SETUP%"=="1" (
    echo [NESK] Preparando dependencias da versao %NESK_VERSION%...
    echo [NESK] A 0.2 instala o modulo local de reconhecimento de voz.
    echo.
    call scripts\setup_windows.bat --from-launcher
    if errorlevel 1 goto :error
)

echo [NESK] Iniciando interface...
echo [NESK] Esta janela pode permanecer aberta enquanto o NESK roda.
echo.

".venv\Scripts\python.exe" -m nesk.app
set "EXITCODE=%ERRORLEVEL%"

if not "%EXITCODE%"=="0" (
    echo.
    echo [ERRO] O NESK encerrou com codigo %EXITCODE%.
    echo [ERRO] Tire um print desta tela e envie para revisao.
    echo.
    pause
    exit /b %EXITCODE%
)

exit /b 0

:error
echo.
echo [ERRO] O primeiro boot/sincronizacao do NESK falhou.
echo [ERRO] Tire um print desta tela e envie para revisao.
echo.
pause
exit /b 1
