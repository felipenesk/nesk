# NESK Security Model — 0.2.0

```text
texto OU transcrição de voz
          ↓
 NLU local / contexto transitório
          ↓
 interpretador semântico opcional
          ↓
 candidato estruturado validado
          ↓
      NESK Core / Intent
          ↓
Tool Registry
          ↓
Permission Policy
          ↓
LOW: permite
MEDIUM: confirma
HIGH: bloqueia
          ↓
Tool allow-listed
```

## Regra principal da voz
**Transcrição não é autoridade extra.** Falar um comando não contorna nenhuma regra da Foundation. Voz e texto passam pelo mesmo Core, Intent, Tool Registry e Permission Policy.

## Garantias desta fase
- Áudio não vira shell/comando bruto.
- Texto/transcrição não vira CMD/PowerShell arbitrário.
- Tool exceptions não derrubam o Core.
- Ações MEDIUM continuam exigindo confirmação explícita.
- `ProgramDirectory` aceita discovery/config somente após validar fonte, `.exe`, existência, escopo/raiz confiável e ausência de argumentos; roots e `%VAR%` permitidas vêm de APIs Windows, não do ambiente do launcher. A exceção `HKLM` é revalidada para o target local exato e exclui UNC/device, perfil, Desktop, Downloads e TEMP; paths nunca atravessam a fronteira semântica.
- `programs.close` continua limitado a nomes de processo exatos da allowlist Foundation; app descoberto não ganha close por nome parecido.
- URLs continuam limitadas a HTTP/HTTPS.
- STT é provider-neutral e não recebe acesso às Tools.
- Buffer de áudio local fica em memória e é descartado após o turno por padrão.
- `local_only` impede memória de ser liberada para cloud.
- Provider semântico não recebe ToolRegistry nem pode devolver shell, URL, caminho ou nome de ferramenta arbitrário.
- Ação semântica só é aceita se a Tool estiver registrada, o alvo passar allowlist/catálogo e a Confidence/modalidade forem seguras.
- Provider não pode transformar target inventado, path-like ou URL-like em argumento de programa/busca indireta.
- Multi-select existe apenas para duas opções pendentes, tipadas e pré-validadas de `programs.open`; cada Intent atravessa PermissionPolicy separadamente.
- `não`, pergunta explicativa, hipótese, menção e contexto incompatível não viram comando; ambiguidade gera clarificação sem executar.
- Resultado semântico de timeout, erro, schema inválido, nova solicitação ou shutdown é descartado antes do Tool Registry.
- Nenhum caminho de auto-modificação existe.

## Não objetivos
- Terminal arbitrário.
- Admin/root automático.
- Instalação autônoma de software.
- Auto-update sem aprovação.
- Controle irrestrito de arquivos.
- Scan de disco/PATH para executar aplicativos, atalhos com argumentos ou kill de processo por substring.
- Wake word nesta build.
- Reconhecimento biométrico de voz nesta build.

## Release
- O `.exe` experimental precisa passar pelo self-check antes do ZIP ser criado.
- Build oficial de teste exige Python 64-bit no Windows.
- O hardware de microfone ainda precisa de validação manual no Windows 10 de referência.
