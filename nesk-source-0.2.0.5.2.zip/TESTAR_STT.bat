@echo off
setlocal
cd /d "%~dp0"
title NESK - Probe STT PT-BR

if not exist ".venv\Scripts\python.exe" (
  echo [FALHA] Ambiente .venv nao encontrado.
  echo Execute INICIAR_NESK.bat primeiro para instalar a versao.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" scripts\stt_probe.py
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo [FALHA] O probe terminou com erro %RC%.
pause
exit /b %RC%
