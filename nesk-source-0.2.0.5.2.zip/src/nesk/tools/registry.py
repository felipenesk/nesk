from __future__ import annotations

import logging
from typing import Any

from nesk.core.permissions import PermissionDecision, PermissionPolicy
from nesk.tools.base import Tool, ToolResult


class ToolRegistry:
    def __init__(self, policy: PermissionPolicy | None = None) -> None:
        self.policy = policy or PermissionPolicy()
        self._tools: dict[str, Tool] = {}
        self.logger = logging.getLogger("nesk")

    def register(self, tool: Tool) -> None:
        if tool.name in self._tools:
            raise ValueError(f"Ferramenta duplicada: {tool.name}")
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def names(self) -> list[str]:
        return sorted(self._tools)

    def describe(self, *, exclude: set[str] | None = None) -> list[dict[str, Any]]:
        """Human/legacy summary kept stable across Foundation builds."""
        hidden = exclude or set()
        return [
            {
                "name": name,
                "description": self._tools[name].description,
                "risk": self._tools[name].risk.name.lower(),
            }
            for name in sorted(self._tools)
            if name not in hidden
        ]

    def schemas(self, *, exclude: set[str] | None = None) -> list[dict[str, Any]]:
        """Structured tool schemas for future model/agent resolvers."""
        hidden = exclude or set()
        return [self._tools[name].schema() for name in sorted(self._tools) if name not in hidden]

    def execute(self, tool_name: str, *, confirmed: bool = False, **kwargs: Any) -> ToolResult:
        """Execute a registered tool through the central permission boundary."""
        tool = self.get(tool_name)
        if not tool:
            return ToolResult(False, f"Ferramenta não encontrada: {tool_name}")
        decision = self.policy.decide(tool.risk)
        if decision == PermissionDecision.BLOCK:
            return ToolResult(False, "Essa ação está bloqueada pela política de segurança do NESK.")
        if decision == PermissionDecision.CONFIRM and not confirmed:
            return ToolResult(
                False,
                "Essa ação exige confirmação.",
                {"needs_confirmation": True, "tool": tool_name},
            )
        try:
            return tool.run(**kwargs)
        except Exception as exc:  # Tool exceptions are a boundary, never a Core crash.
            self.logger.exception("tool_execution_error tool=%s type=%s", tool_name, type(exc).__name__)
            return ToolResult(
                False,
                f"Não consegui concluir essa ação. O erro foi registrado ({type(exc).__name__}).",
                {"tool": tool_name, "error_type": type(exc).__name__},
            )
