from __future__ import annotations

import os
from pathlib import Path

import psutil

from nesk.core.permissions import RiskLevel
from nesk.tools.base import Tool, ToolResult


def system_disk_root() -> str:
    if os.name == "nt":
        return os.getenv("SystemDrive", "C:") + "\\"
    return str(Path("/") )


class SystemStatusTool(Tool):
    name = "system.status"
    description = "Consulta CPU, memória e disco local sem modificar o sistema."
    risk = RiskLevel.LOW

    def run(self, **kwargs) -> ToolResult:
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage(system_disk_root())
        cpu = psutil.cpu_percent(interval=0.15)
        try:
            nesk_memory_mb = round(psutil.Process().memory_info().rss / (1024**2), 1)
        except (psutil.Error, OSError):
            nesk_memory_mb = None
        data = {
            "cpu_percent": round(cpu, 1),
            "ram_percent": round(memory.percent, 1),
            "ram_used_gb": round(memory.used / (1024**3), 1),
            "ram_total_gb": round(memory.total / (1024**3), 1),
            "disk_percent": round(disk.percent, 1),
            "nesk_memory_mb": nesk_memory_mb,
        }
        message = (
            f"CPU em {data['cpu_percent']}%. RAM em {data['ram_percent']}% "
            f"({data['ram_used_gb']} de {data['ram_total_gb']} GB). Disco em {data['disk_percent']}%."
        )
        return ToolResult(True, message, data)
