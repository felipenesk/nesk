from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from nesk.core.permissions import RiskLevel


@dataclass(frozen=True, slots=True)
class ToolParameter:
    name: str
    type: str = "string"
    description: str = ""
    required: bool = True


@dataclass(slots=True)
class ToolResult:
    ok: bool
    message: str
    data: dict[str, Any] | None = None


class Tool(ABC):
    name: str
    description: str
    risk: RiskLevel
    category: str = "general"
    parameters: tuple[ToolParameter, ...] = ()
    side_effects: bool = False

    @abstractmethod
    def run(self, **kwargs: Any) -> ToolResult:
        raise NotImplementedError

    def schema(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category,
            "risk": self.risk.name.lower(),
            "side_effects": self.side_effects,
            "parameters": [
                {
                    "name": item.name,
                    "type": item.type,
                    "description": item.description,
                    "required": item.required,
                }
                for item in self.parameters
            ],
        }
