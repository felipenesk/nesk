from __future__ import annotations

from nesk.core.permissions import RiskLevel
from nesk.tools.base import Tool, ToolResult
from nesk.tools.registry import ToolRegistry


class CapabilitiesTool(Tool):
    name = "nesk.capabilities"
    description = "Mostra as capacidades locais atualmente instaladas no NESK."
    risk = RiskLevel.LOW

    def __init__(self, registry: ToolRegistry) -> None:
        self.registry = registry

    def run(self, **kwargs) -> ToolResult:
        # Human-facing summary remains intentionally concise. Full descriptions are
        # returned as metadata and can later be rendered by a richer UI.
        capabilities = self.registry.describe(exclude={self.name})
        names = {item["name"] for item in capabilities}
        parts: list[str] = []
        if "system.status" in names:
            parts.append("consultar o estado do PC")
        if "programs.open" in names:
            parts.append("abrir programas permitidos")
        if "programs.close" in names:
            parts.append("fechar programas com confirmação")
        if {"browser.open_default", "browser.open_named", "browser.open_url"} & names:
            parts.append("abrir navegador, sites e URLs seguras")
        if "browser.search" in names:
            parts.append("pesquisar no Google ou YouTube")

        if parts:
            if len(parts) == 1:
                summary = parts[0]
            else:
                summary = ", ".join(parts[:-1]) + " e " + parts[-1]
            message = f"Nesta versão eu consigo {summary}. Voz e conversa completa ainda estão sendo preparados."
        else:
            message = "Nesta instalação ainda não encontrei ferramentas locais disponíveis."
        return ToolResult(True, message, {"capabilities": capabilities})
