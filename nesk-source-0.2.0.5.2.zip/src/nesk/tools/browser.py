from __future__ import annotations

import webbrowser
from urllib.parse import quote_plus, urlparse

from nesk.core.permissions import RiskLevel
from nesk.tools.base import Tool, ToolResult


KNOWN_SITES = {
    "youtube": "https://www.youtube.com",
    "google": "https://www.google.com",
    "github": "https://github.com",
    "chatgpt": "https://chatgpt.com",
    "claude": "https://claude.ai",
    "gmail": "https://mail.google.com",
    "whatsapp": "https://web.whatsapp.com",
    "twitch": "https://www.twitch.tv",
    "reddit": "https://www.reddit.com",
    "spotify_web": "https://open.spotify.com",
}

SEARCH_ENDPOINTS = {
    "google": "https://www.google.com/search?q={query}",
    "youtube": "https://www.youtube.com/results?search_query={query}",
}


class OpenUrlTool(Tool):
    name = "browser.open_url"
    description = "Abre uma URL HTTP/HTTPS no navegador padrão."
    risk = RiskLevel.LOW

    def run(self, *, url: str, **kwargs) -> ToolResult:
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            return ToolResult(False, "URL recusada: somente HTTP/HTTPS válidos são permitidos.")
        opened = webbrowser.open(url, new=2)
        return ToolResult(
            bool(opened),
            "Abri no navegador." if opened else "O sistema não confirmou a abertura do navegador.",
            {"url": url},
        )


class OpenDefaultBrowserTool(Tool):
    name = "browser.open_default"
    description = "Abre o navegador padrão sem receber comandos de shell."
    risk = RiskLevel.LOW

    def run(self, **kwargs) -> ToolResult:
        opened = webbrowser.open("https://www.google.com", new=2)
        return ToolResult(
            bool(opened),
            "Abri o navegador." if opened else "O sistema não confirmou a abertura do navegador.",
        )


class OpenNamedSiteTool(Tool):
    name = "browser.open_named"
    description = "Abre um site conhecido a partir de uma lista segura."
    risk = RiskLevel.LOW

    def run(self, *, name: str, **kwargs) -> ToolResult:
        key = name.strip().lower()
        url = KNOWN_SITES.get(key)
        if not url:
            return ToolResult(False, f"Ainda não tenho um site permitido chamado '{name}'.")
        opened = webbrowser.open(url, new=2)
        display = "Spotify" if key == "spotify_web" else name
        return ToolResult(
            bool(opened),
            f"Abri {display}." if opened else f"O sistema não confirmou a abertura de {display}.",
            {"url": url, "site": key},
        )


class SearchWebTool(Tool):
    name = "browser.search"
    description = "Pesquisa um termo no Google ou YouTube usando o navegador padrão."
    risk = RiskLevel.LOW

    def run(self, *, query: str, engine: str = "google", **kwargs) -> ToolResult:
        query = " ".join(str(query).split()).strip()
        if not query:
            return ToolResult(False, "Me diga o que você quer pesquisar.")
        if len(query) > 500:
            return ToolResult(False, "Essa pesquisa ficou longa demais. Tenta resumir um pouco.")
        engine_key = str(engine).strip().lower()
        template = SEARCH_ENDPOINTS.get(engine_key)
        if template is None:
            return ToolResult(False, f"Ainda não tenho suporte para pesquisar em '{engine}'.")
        url = template.format(query=quote_plus(query))
        opened = webbrowser.open(url, new=2)
        label = "YouTube" if engine_key == "youtube" else "Google"
        return ToolResult(
            bool(opened),
            f"Pesquisei '{query}' no {label}." if opened else f"O sistema não confirmou a abertura da pesquisa no {label}.",
            {"url": url, "query": query, "engine": engine_key},
        )
