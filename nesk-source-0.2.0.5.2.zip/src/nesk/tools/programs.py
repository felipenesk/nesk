from __future__ import annotations

import time

import psutil

from nesk.core.permissions import RiskLevel
from nesk.platform.windows.programs import ProgramLaunchError, WindowsProgramCatalog
from nesk.tools.base import Tool, ToolParameter, ToolResult


class OpenProgramTool(Tool):
    name = "programs.open"
    description = "Abre um aplicativo conhecido/permitido no Windows."
    risk = RiskLevel.LOW
    category = "windows"
    side_effects = True
    parameters = (
        ToolParameter("name", description="Nome canônico do programa"),
        ToolParameter("display_name", description="Nome amigável para resposta", required=False),
    )

    def __init__(self, catalog: WindowsProgramCatalog) -> None:
        self.catalog = catalog

    def run(self, *, name: str, display_name: str | None = None, **kwargs) -> ToolResult:
        label = (display_name or name).strip()
        target = self.catalog.resolve(name)
        if not target:
            return ToolResult(
                False,
                f"Ainda não conheço um programa permitido chamado '{label}'. Você poderá adicioná-lo nas configurações.",
            )
        try:
            self.catalog.launch(target)
        except ProgramLaunchError as exc:
            return ToolResult(
                False,
                f"Não consegui abrir {label}. O erro foi registrado para diagnóstico.",
                {"program": name, "display_name": label, "launch_error": type(exc).__name__},
            )
        return ToolResult(True, f"Abri {label}.", {"program": name, "display_name": label})


class CloseProgramTool(Tool):
    """Close only a known allow-listed application.

    The user explicitly prefers direct close commands for known programs. The
    global confirmation framework remains available for genuinely sensitive
    tools; this tool stays constrained to the allow-listed Windows catalog.
    """

    name = "programs.close"
    description = "Fecha um aplicativo conhecido/permitido no Windows."
    risk = RiskLevel.LOW
    category = "windows"
    side_effects = True
    parameters = (
        ToolParameter("name", description="Nome canônico do programa"),
        ToolParameter("display_name", description="Nome amigável para resposta", required=False),
    )

    def __init__(self, catalog: WindowsProgramCatalog) -> None:
        self.catalog = catalog

    def run(self, *, name: str, display_name: str | None = None, **kwargs) -> ToolResult:
        label = (display_name or name).strip()
        expected = self.catalog.process_names(name)
        if not expected:
            return ToolResult(False, f"Ainda não sei fechar {label} com segurança.")

        # Discord commonly launches through Update.exe. Wait only when this
        # catalog instance launched Discord very recently, and only accept the
        # catalog's exact allow-listed process names. Update.exe itself is never
        # a match or a termination target.
        matches = []
        deadline = time.monotonic() + self.catalog.recent_launch_wait_seconds(name)
        while True:
            matches = []
            for proc in psutil.process_iter(["name", "exe"]):
                try:
                    proc_name = proc.info.get("name") or ""
                    executable = proc.info.get("exe") or ""
                    if self.catalog.process_matches(name, proc_name, executable):
                        matches.append(proc)
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
            now = time.monotonic()
            if matches:
                self.catalog.clear_recent_launch(name)
                break
            if now >= deadline:
                break
            time.sleep(min(0.1, deadline - now))

        if not matches:
            return ToolResult(False, f"{label} não parece estar aberto.", {"program": name})

        closed = 0
        denied = 0
        for proc in matches:
            try:
                proc.terminate()
                closed += 1
            except psutil.AccessDenied:
                denied += 1
            except (psutil.NoSuchProcess, psutil.ZombieProcess):
                closed += 1

        if not closed and denied:
            return ToolResult(
                False,
                f"Encontrei {label}, mas o Windows não permitiu fechar o processo.",
                {"program": name, "access_denied": denied},
            )
        return ToolResult(
            True,
            f"Fechei {label}.",
            {"program": name, "processes": closed, "matched": len(matches)},
        )
