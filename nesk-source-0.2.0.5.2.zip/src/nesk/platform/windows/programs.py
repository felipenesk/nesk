from __future__ import annotations

import logging
import os
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping

from nesk.platform.windows.program_directory import (
    AppPathsReader,
    ProgramDirectory,
    ProgramResolutionKind,
    ShortcutResolver,
    default_trusted_roots,
)


@dataclass(frozen=True, slots=True)
class ProgramTarget:
    name: str
    executable: str


class ProgramLaunchError(RuntimeError):
    """Stable boundary error for failures while launching allow-listed programs."""


class WindowsProgramCatalog:
    """Resolves and launches a limited catalog of known apps.

    Important security property: user/model text is never passed to a shell. Only an
    executable resolved from the allow-list/custom catalog reaches subprocess.Popen.
    """


    PROCESS_NAMES = {
        "chrome": {"chrome.exe"},
        "edge": {"msedge.exe"},
        "firefox": {"firefox.exe"},
        "discord": {
            "discord.exe",
            "discordcanary.exe",
            "discordptb.exe",
            "discorddevelopment.exe",
        },
        "spotify": {"spotify.exe"},
        "notepad": {"notepad.exe"},
        "explorer": {"explorer.exe"},
        "calculator": {"calculatorapp.exe", "calc.exe"},
        "paint": {"mspaint.exe"},
    }

    KNOWN_EXECUTABLES = {
        "chrome": "chrome.exe",
        "edge": "msedge.exe",
        "firefox": "firefox.exe",
        "discord": "Discord.exe",
        "spotify": "Spotify.exe",
        "notepad": "notepad.exe",
        "explorer": "explorer.exe",
        "calculator": "calc.exe",
        "paint": "mspaint.exe",
    }

    _SYSTEM_BUILTIN_RELATIVE = {
        "notepad": Path("System32") / "notepad.exe",
        "explorer": Path("explorer.exe"),
        "calculator": Path("System32") / "calc.exe",
        "paint": Path("System32") / "mspaint.exe",
    }

    # Discord starts through Update.exe on common installations. The updater is
    # not the application process and must never be terminated just because a
    # close command follows an open command quickly. Keep the extra wait
    # strictly scoped to a recent Discord launch and bounded for responsiveness.
    _DISCORD_RECENT_LAUNCH_WINDOW_SECONDS = 10.0
    _DISCORD_STARTUP_WAIT_SECONDS = 5.0

    def __init__(
        self,
        custom: Mapping[str, object] | None = None,
        *,
        directory: ProgramDirectory | None = None,
        cache_path: Path | None = None,
        trusted_roots: Iterable[Path] | None = None,
        app_paths_reader: AppPathsReader | None = None,
        start_menu_roots: Iterable[Path] = (),
        shortcut_resolver: ShortcutResolver | None = None,
    ) -> None:
        # The directory owns every non-built-in launch target.  ``custom`` is
        # accepted for Foundation compatibility, but it now goes through the
        # same .exe/root/provenance validation as discovered entries instead of
        # treating any existing file or PATH token as executable.
        self.directory = directory or ProgramDirectory(
            custom,
            cache_path=cache_path,
            trusted_roots=trusted_roots,
            app_paths_reader=app_paths_reader,
            start_menu_roots=start_menu_roots,
            shortcut_resolver=shortcut_resolver,
        )
        self._recent_launches: dict[str, float] = {}
        self._launch_lock = threading.Lock()

    def refresh(self) -> int:
        """Refresh trusted program discovery outside the semantic/Core path."""

        return self.directory.refresh()

    @staticmethod
    def _common_candidates(exe: str) -> list[tuple[Path, Path]]:
        relative = {
            "chrome.exe": ["Google/Chrome/Application/chrome.exe"],
            "msedge.exe": ["Microsoft/Edge/Application/msedge.exe"],
            "firefox.exe": ["Mozilla Firefox/firefox.exe"],
            "Discord.exe": ["Discord/Update.exe"],
            "Spotify.exe": ["Spotify/Spotify.exe"],
        }.get(exe, [])
        return [(root / rel, root) for root in default_trusted_roots() for rel in relative]

    @staticmethod
    def _windows_directory() -> Path | None:
        """Return the actual Windows directory without trusting SystemRoot.

        Built-ins must not become redirectable by a caller-controlled process
        environment.  If Windows cannot provide its own directory, built-in
        resolution fails closed instead of falling back to PATH or WINDIR.
        """

        if os.name != "nt":
            return None
        try:
            import ctypes

            buffer = ctypes.create_unicode_buffer(32768)
            length = ctypes.windll.kernel32.GetWindowsDirectoryW(buffer, len(buffer))
            if not 0 < length < len(buffer):
                return None
            return Path(buffer.value).resolve(strict=True)
        except (AttributeError, OSError):
            return None

    @staticmethod
    def _validated_builtin_path(candidate: Path, root: Path) -> Path | None:
        """Accept an existing exact built-in target under its known root only."""

        try:
            resolved = candidate.resolve(strict=True)
            resolved_root = root.resolve(strict=True)
            resolved.relative_to(resolved_root)
        except (OSError, ValueError):
            return None
        if resolved.suffix.casefold() != ".exe" or not resolved.is_file():
            return None
        return resolved

    def process_names(self, name: str) -> set[str]:
        resolution = self.directory.resolve(name)
        if resolution.kind is not ProgramResolutionKind.UNIQUE or resolution.entry is None:
            return set()
        # Dynamic/discovered entries intentionally carry no inferred process
        # identity.  Only the pre-existing explicit Foundation allowlist can
        # authorize termination.
        return {item.lower() for item in self.PROCESS_NAMES.get(resolution.entry.identifier, set())}

    def process_matches(
        self,
        name: str,
        process_name: str | None,
        executable: str | None = None,
    ) -> bool:
        """Match only exact allow-listed process names for a canonical app.

        Discord Stable/PTB/Canary have explicit entries in ``PROCESS_NAMES``.
        Do not use family-prefix matching here: a similarly named unrelated
        executable must never become eligible for termination.
        """

        resolution = self.directory.resolve(name)
        key = resolution.entry.identifier if resolution.entry is not None else name.strip().lower()
        proc = (process_name or "").strip().lower()
        # Do not treat Update.exe as the app itself. It is only the launcher;
        # killing it could interfere with installation/update state.
        return proc in self.process_names(key)

    def recent_launch_wait_seconds(self, name: str) -> float:
        """Return the remaining bounded Discord-startup wait, if applicable.

        This is deliberately not a general process wait. It only covers the
        short interval immediately after NESK itself launched Discord through
        the allow-listed catalog, where Update.exe may not have spawned the
        exact final process yet.
        """

        resolution = self.directory.resolve(name)
        key = resolution.entry.identifier if resolution.entry is not None else name.strip().lower()
        if key != "discord":
            return 0.0
        now = time.monotonic()
        with self._launch_lock:
            launched_at = self._recent_launches.get(key)
            if launched_at is None:
                return 0.0
            elapsed = max(0.0, now - launched_at)
            remaining_window = self._DISCORD_RECENT_LAUNCH_WINDOW_SECONDS - elapsed
            if remaining_window <= 0:
                self._recent_launches.pop(key, None)
                return 0.0
            return min(self._DISCORD_STARTUP_WAIT_SECONDS, remaining_window)

    def clear_recent_launch(self, name: str) -> None:
        """Forget launch state once the actual app process was observed."""

        resolution = self.directory.resolve(name)
        key = resolution.entry.identifier if resolution.entry is not None else name.strip().lower()
        with self._launch_lock:
            self._recent_launches.pop(key, None)

    def _mark_recent_launch(self, name: str) -> None:
        resolution = self.directory.resolve(name)
        key = resolution.entry.identifier if resolution.entry is not None else name.strip().lower()
        if key != "discord":
            return
        with self._launch_lock:
            self._recent_launches[key] = time.monotonic()

    def _resolve_builtin(self, key: str) -> ProgramTarget | None:
        exe = self.KNOWN_EXECUTABLES.get(key)
        if not exe:
            return None
        system_relative = self._SYSTEM_BUILTIN_RELATIVE.get(key)
        if system_relative is not None:
            system_root = self._windows_directory()
            if system_root is not None:
                validated = self._validated_builtin_path(system_root / system_relative, system_root)
                if validated is not None:
                    return ProgramTarget(key, str(validated))
        for candidate, root in self._common_candidates(exe):
            validated = self._validated_builtin_path(candidate, root)
            if validated is not None:
                # Discord's Update.exe needs a special argument; handled by launch().
                return ProgramTarget(key, str(validated))
        return None

    def resolve(self, name: str) -> ProgramTarget | None:
        resolution = self.directory.resolve(name)
        entry = resolution.entry
        if resolution.kind is not ProgramResolutionKind.UNIQUE or entry is None:
            return None
        if entry.launch_target is not None:
            if not self.directory.has_valid_launch_target(entry):
                return None
            return ProgramTarget(entry.identifier, str(entry.launch_target))
        return self._resolve_builtin(entry.identifier)

    def _is_authorized_launch_target(self, target: ProgramTarget) -> bool:
        """Ensure direct callers cannot smuggle an arbitrary executable here."""

        resolution = self.directory.resolve(target.name)
        entry = resolution.entry
        if resolution.kind is not ProgramResolutionKind.UNIQUE or entry is None:
            return False
        executable = str(target.executable).strip()
        if not executable:
            return False
        if entry.launch_target is not None:
            try:
                return (
                    self.directory.has_valid_launch_target(entry)
                    and Path(executable).resolve(strict=False) == entry.launch_target
                )
            except OSError:
                return False

        # Never authorize a manually supplied path by executable basename.  A
        # file named ``notepad.exe`` on Desktop is not the Foundation Notepad
        # target.  Resolve the same canonical entry again and require exact
        # path/token equality with the catalog-produced ProgramTarget.
        expected = self.resolve(entry.identifier)
        if expected is None:
            return False
        try:
            return Path(executable).resolve(strict=False) == Path(expected.executable).resolve(strict=False)
        except OSError:
            return False

    def launch(self, target: ProgramTarget) -> None:
        """Launch an already-resolved allow-listed executable without a shell.

        Do not pass close_fds here. It is unnecessary for these detached GUI apps and
        caused compatibility trouble in the first Windows 10 field test.
        """
        executable = str(target.executable).strip()
        if not executable:
            raise ProgramLaunchError("caminho do executável está vazio")
        if not self._is_authorized_launch_target(target):
            raise ProgramLaunchError("alvo de inicialização não pertence ao catálogo confiável")

        path = Path(executable)
        args = [executable]
        if path.name.lower() == "update.exe" and "discord" in executable.lower():
            args.extend(["--processStart", "Discord.exe"])

        try:
            subprocess.Popen(args, shell=False)
        except (OSError, TypeError, ValueError, subprocess.SubprocessError) as exc:
            # Native exception strings frequently contain a local path.  Keep
            # logs and the user-visible boundary path-free; the canonical ID
            # and error class are sufficient for safe diagnostics.
            logging.getLogger("nesk").error(
                "program_launch_failed program=%s error_type=%s",
                target.name,
                type(exc).__name__,
            )
            raise ProgramLaunchError("falha de inicialização") from exc
        self._mark_recent_launch(target.name)
