from __future__ import annotations

"""Trusted, local directory of programs that NESK may name or launch.

The directory is deliberately distinct from text parsing and from process
management.  It turns a small set of verified Windows installation records into
opaque program identities; paths remain internal and never cross into semantic
requests, Intents, logs, or provider payloads.
"""

import hashlib
import json
import os
import re
import uuid
from dataclasses import dataclass, replace
from enum import Enum
from pathlib import Path
from threading import RLock
from typing import Callable, Iterable, Mapping

from nesk.nlu.lexicon import PROGRAM_ALIASES
from nesk.nlu.ptbr import normalized_words


class ProgramSource(str, Enum):
    BUILTIN = "builtin"
    CUSTOM_CONFIG = "custom_config"
    APP_PATHS = "app_paths"
    START_MENU = "start_menu"
    CACHE = "cache"


@dataclass(frozen=True, slots=True)
class ProgramEntry:
    """One public program identity backed by a trusted local source.

    ``launch_target`` is intentionally internal-only.  Semantic resolution uses
    ``identifier`` and display/aliases, while ``WindowsProgramCatalog`` is the
    only component that can turn this entry into a process launch.
    """

    identifier: str
    display_name: str
    aliases: tuple[str, ...]
    source: ProgramSource
    launch_target: Path | None = None
    sources: frozenset[ProgramSource] = frozenset()
    close_process_names: frozenset[str] = frozenset()
    # The one narrow exception to the normal installation-root rule.  It is
    # set only for an exact target registered under machine-wide App Paths;
    # user-scoped App Paths and every other source remain root-bound.
    machine_app_path_target: bool = False

    def __post_init__(self) -> None:
        if not _is_safe_public_text(self.identifier) or not _is_safe_public_text(self.display_name):
            raise ValueError("ProgramEntry exige identificador e nome de exibição")
        if not self.aliases or not all(_is_safe_public_text(alias) for alias in self.aliases):
            raise ValueError("ProgramEntry exige ao menos um alias")
        if self.launch_target is not None and self.launch_target.suffix.casefold() != ".exe":
            raise ValueError("ProgramEntry só aceita launch target .exe")

    @property
    def all_sources(self) -> frozenset[ProgramSource]:
        return self.sources or frozenset({self.source})


class ProgramResolutionKind(str, Enum):
    UNIQUE = "unique"
    AMBIGUOUS = "ambiguous"
    MISSING = "missing"


@dataclass(frozen=True, slots=True)
class ProgramResolution:
    kind: ProgramResolutionKind
    entries: tuple[ProgramEntry, ...] = ()

    @property
    def entry(self) -> ProgramEntry | None:
        return self.entries[0] if self.kind is ProgramResolutionKind.UNIQUE and self.entries else None


@dataclass(frozen=True, slots=True)
class DiscoveryRecord:
    """A non-executable discovery record pending local validation."""

    display_name: str
    path: str
    source: ProgramSource
    aliases: tuple[str, ...] = ()
    identifier_hint: str | None = None
    # ``machine`` is produced only by the HKLM App Paths reader.  It exists so
    # an exact machine registration outside the conventional roots can be
    # revalidated at launch without granting that exemption to custom config,
    # HKCU or Start Menu records.
    registry_scope: str | None = None


@dataclass(frozen=True, slots=True)
class ShortcutTarget:
    """Output allowed from an optional shortcut resolver.

    The resolver may only describe a target.  Any arguments make the shortcut
    ineligible in this Alpha; NESK never forwards shortcut arguments to a
    process.
    """

    executable: str
    arguments: str = ""


AppPathsReader = Callable[[], Iterable[DiscoveryRecord]]
ShortcutResolver = Callable[[Path], ShortcutTarget | None]

_CACHE_VERSION = 2
_APP_PATHS_SUBKEYS = (
    r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths",
    r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths",
)
_PATH_LIKE = re.compile(r"(?:^[a-z]:|[\\/]|://)", re.IGNORECASE)
_PUBLIC_TEXT_MAX = 100
_REJECTED_MACHINE_APP_PATH_PARTS = frozenset({"users", "desktop", "downloads", "temp", "tmp"})
_BUILTIN_DISPLAY_NAMES = {
    "chrome": "Chrome",
    "edge": "Edge",
    "firefox": "Firefox",
    "discord": "Discord",
    "spotify": "Spotify",
    "notepad": "Bloco de Notas",
    "explorer": "Explorador de Arquivos",
    "calculator": "Calculadora",
    "paint": "Paint",
}
_KNOWN_FOLDER_IDS = {
    # Program Files, Program Files (x86), Local AppData, Roaming AppData.
    # These are Windows-owned known-folder IDs, not process environment paths.
    "programfiles": "905e63b6-c1bf-494e-b29c-65b732d3d21a",
    "programfiles(x86)": "7c5a40ef-a0fb-4bfc-874a-c0f2e0b9fa8e",
    "localappdata": "f1b32785-6fba-4fcf-9d55-7b8e7f157091",
    "appdata": "3eb685db-65f9-4cf6-a03a-e3ef65729f3d",
}
_ENVIRONMENT_VARIABLE = re.compile(r"%([^%]+)%")


def _slug(value: str) -> str:
    cleaned = normalized_words(value).replace("_", "-")
    cleaned = re.sub(r"[^a-z0-9-]+", "-", cleaned)
    cleaned = re.sub(r"-+", "-", cleaned).strip("-")
    return cleaned or "program"


def _is_safe_public_text(value: object) -> bool:
    """Keep path-like/config-controlled text out of public semantic fields."""

    if not isinstance(value, str):
        return False
    raw = value.strip()
    return bool(
        raw
        and len(raw) <= _PUBLIC_TEXT_MAX
        and not _PATH_LIKE.search(raw)
        and not any(ord(character) < 32 for character in raw)
    )


def _display_name(value: str) -> str:
    raw = str(value).strip()
    raw = Path(raw).stem if raw.lower().endswith(".exe") else raw
    raw = re.sub(r"[_\-.]+", " ", raw)
    raw = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", raw)
    return " ".join(raw.split()) or "Programa"


def _safe_display_name(value: object) -> str | None:
    if not _is_safe_public_text(value):
        return None
    display = _display_name(str(value))
    return display if _is_safe_public_text(display) else None


def _normal_aliases(values: Iterable[str]) -> tuple[str, ...]:
    output: list[str] = []
    for value in values:
        if not _is_safe_public_text(value):
            continue
        clean = normalized_words(value)
        if clean and len(clean) <= 100 and clean not in output:
            output.append(clean)
    return tuple(output)


def _same_path(left: Path | None, right: Path | None) -> bool:
    if left is None or right is None:
        return False
    return str(left).casefold() == str(right).casefold()


def _path_within(candidate: Path, root: Path) -> bool:
    try:
        candidate.relative_to(root)
        return True
    except ValueError:
        return False


def _is_rejected_machine_app_path(candidate: Path) -> bool:
    raw = str(candidate).replace("/", "\\")
    # Network/UNC and device paths are deliberately outside this Alpha even if
    # an administrator happened to register one in App Paths.  The exception
    # exists for a local, machine-installed application such as C:\\Riot Games,
    # not for a broad path-resolution mechanism.
    if raw.startswith("\\\\") or raw.casefold().startswith("\\\\?\\"):
        return True
    return any(part.casefold() in _REJECTED_MACHINE_APP_PATH_PARTS for part in candidate.parts)


def _windows_known_folder(folder_id: str) -> Path | None:
    """Read a Windows-owned known folder without trusting process environment.

    A desktop launcher can alter environment variables such as PROGRAMFILES;
    discovery must not turn that into a new executable root.  On a non-Windows
    host or an API failure we fail closed and return no root.
    """

    if os.name != "nt":
        return None
    try:
        import ctypes
        from ctypes import wintypes

        class Guid(ctypes.Structure):
            _fields_ = [
                ("Data1", wintypes.DWORD),
                ("Data2", wintypes.WORD),
                ("Data3", wintypes.WORD),
                ("Data4", ctypes.c_ubyte * 8),
            ]

        value = uuid.UUID(folder_id)
        guid = Guid(
            value.time_low,
            value.time_mid,
            value.time_hi_version,
            (ctypes.c_ubyte * 8).from_buffer_copy(value.bytes[8:]),
        )
        raw_path = ctypes.c_void_p()
        shell32 = ctypes.windll.shell32
        shell32.SHGetKnownFolderPath.argtypes = (
            ctypes.POINTER(Guid),
            wintypes.DWORD,
            wintypes.HANDLE,
            ctypes.POINTER(ctypes.c_void_p),
        )
        shell32.SHGetKnownFolderPath.restype = ctypes.c_long
        if shell32.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(raw_path)) != 0 or not raw_path.value:
            return None
        try:
            return Path(ctypes.wstring_at(raw_path.value)).resolve(strict=False)
        finally:
            ctypes.windll.ole32.CoTaskMemFree(raw_path)
    except (AttributeError, OSError, ValueError):
        return None


def _windows_directory() -> Path | None:
    """Return Windows' own directory without trusting WINDIR/SystemRoot."""

    if os.name != "nt":
        return None
    try:
        import ctypes

        buffer = ctypes.create_unicode_buffer(32768)
        length = ctypes.windll.kernel32.GetWindowsDirectoryW(buffer, len(buffer))
        if not 0 < length < len(buffer):
            return None
        return Path(buffer.value).resolve(strict=True)
    except (AttributeError, OSError):
        return None


def _known_windows_environment_paths() -> dict[str, Path]:
    """Return the only percent variables accepted in executable records."""

    values = {
        name: path
        for name, folder_id in _KNOWN_FOLDER_IDS.items()
        if (path := _windows_known_folder(folder_id)) is not None
    }
    program_files = values.get("programfiles")
    if program_files is not None:
        values["programw6432"] = program_files
    windows_directory = _windows_directory()
    if windows_directory is not None:
        values["windir"] = windows_directory
        values["systemroot"] = windows_directory
    return values


def default_trusted_roots() -> tuple[Path, ...]:
    """Return installation roots acceptable for discovered/custom executables.

    Desktop, Downloads and arbitrary user folders are intentionally absent.  A
    static built-in may use the Windows system executable name through the
    separate built-in catalog path, but discovery never gains that exemption.
    """

    roots: list[Path] = []
    for folder_id in _KNOWN_FOLDER_IDS.values():
        root = _windows_known_folder(folder_id)
        if root is None:
            continue
        if root not in roots:
            roots.append(root)
    return tuple(roots)


def _parse_executable_path(value: str, *, variables: Mapping[str, Path] | None = None) -> Path | None:
    raw = str(value).strip()
    if not raw:
        return None
    if raw.startswith('"'):
        closing_quote = raw.find('"', 1)
        if closing_quote <= 1 or raw[closing_quote + 1 :].strip():
            return None
        raw = raw[1:closing_quote]
    if "%" in raw:
        safe_variables = variables if variables is not None else _known_windows_environment_paths()
        unknown_variable = False

        def replace_variable(match: re.Match[str]) -> str:
            nonlocal unknown_variable
            replacement = safe_variables.get(match.group(1).casefold())
            if replacement is None:
                unknown_variable = True
                return ""
            return str(replacement)

        raw = _ENVIRONMENT_VARIABLE.sub(replace_variable, raw)
        # Reject unmatched percent signs too.  They might otherwise be a
        # malformed/unknown environment expression rather than an exact path.
        if unknown_variable or "%" in raw:
            return None
    # Do not support the alternative shell-style environment syntax either.
    if "$" in raw:
        return None
    # A direct App Paths/default or custom value must be exactly an executable
    # path.  Values with command-line arguments are rejected rather than parsed
    # permissively.
    if not raw.casefold().endswith(".exe"):
        return None
    if raw.replace("/", "\\").startswith("\\\\"):
        return None
    candidate = Path(raw)
    if not candidate.is_absolute():
        return None
    return candidate


def _read_windows_app_paths() -> tuple[DiscoveryRecord, ...]:
    """Read only the documented App Paths default values, never PATH itself."""

    if os.name != "nt":
        return ()
    try:
        import winreg  # type: ignore[attr-defined]
    except ImportError:  # pragma: no cover - only meaningful on Windows
        return ()

    records: list[DiscoveryRecord] = []
    for hive, registry_scope in (
        (winreg.HKEY_CURRENT_USER, "user"),
        (winreg.HKEY_LOCAL_MACHINE, "machine"),
    ):
        for subkey in _APP_PATHS_SUBKEYS:
            try:
                root = winreg.OpenKey(hive, subkey, 0, winreg.KEY_READ)
            except OSError:
                continue
            with root:
                index = 0
                while True:
                    try:
                        key_name = winreg.EnumKey(root, index)
                    except OSError:
                        break
                    index += 1
                    try:
                        with winreg.OpenKey(root, key_name, 0, winreg.KEY_READ) as item:
                            value, _kind = winreg.QueryValueEx(item, None)
                    except OSError:
                        continue
                    if not isinstance(value, str):
                        continue
                    display = _safe_display_name(key_name)
                    if display is None:
                        continue
                    records.append(
                        DiscoveryRecord(
                            display_name=display,
                            path=value,
                            source=ProgramSource.APP_PATHS,
                            aliases=(display, Path(key_name).stem),
                            registry_scope=registry_scope,
                        )
                    )
    return tuple(records)


class ProgramDirectory:
    """Thread-safe, snapshot-style local program identity directory.

    Built-ins retain their existing canonical IDs.  Dynamic records receive
    opaque deterministic IDs derived from the verified target, so two programs
    with the same display name cannot be silently conflated.  Refresh builds a
    complete replacement snapshot before swapping it under the lock.
    """

    def __init__(
        self,
        custom: Mapping[str, object] | None = None,
        *,
        trusted_roots: Iterable[Path] | None = None,
        app_paths_reader: AppPathsReader | None = None,
        cache_path: Path | None = None,
        start_menu_roots: Iterable[Path] = (),
        shortcut_resolver: ShortcutResolver | None = None,
    ) -> None:
        self._lock = RLock()
        roots = tuple(trusted_roots) if trusted_roots is not None else default_trusted_roots()
        normalized_roots: list[Path] = []
        for root in roots:
            try:
                candidate = Path(root).expanduser().resolve(strict=False)
            except (OSError, TypeError, ValueError):
                continue
            if candidate not in normalized_roots:
                normalized_roots.append(candidate)
        self._trusted_roots = tuple(normalized_roots)
        self._custom = dict(custom or {})
        self._app_paths_reader = app_paths_reader or _read_windows_app_paths
        self._cache_path = cache_path
        self._start_menu_roots = tuple(Path(root) for root in start_menu_roots)
        self._shortcut_resolver = shortcut_resolver
        self._entries: dict[str, ProgramEntry] = {}
        self._aliases: dict[str, tuple[str, ...]] = {}
        self._safe_environment_paths: dict[str, Path] | None = None
        # The cache is deliberately not loaded into a live snapshot.  A file
        # left by a previous run is descriptive only; fresh source enumeration
        # must re-establish every executable identity before it can be named or
        # launched.  This makes a syntactically valid forged cache fail closed.
        self._replace_snapshot(self._custom_records())

    @classmethod
    def static(cls) -> "ProgramDirectory":
        """Construct the existing built-in lexical directory without I/O."""

        return cls({}, trusted_roots=(), app_paths_reader=lambda: ())

    def _builtin_entries(self) -> dict[str, ProgramEntry]:
        entries: dict[str, ProgramEntry] = {}
        for identifier, aliases in PROGRAM_ALIASES.items():
            display = _BUILTIN_DISPLAY_NAMES.get(identifier, _display_name(identifier))
            normalized = _normal_aliases((identifier, display, *aliases))
            entries[identifier] = ProgramEntry(
                identifier=identifier,
                display_name=display,
                aliases=normalized,
                source=ProgramSource.BUILTIN,
                sources=frozenset({ProgramSource.BUILTIN}),
            )
        return entries

    def _parse_target_path(self, raw_path: str) -> Path | None:
        if "%" in raw_path and self._safe_environment_paths is None:
            self._safe_environment_paths = _known_windows_environment_paths()
        return _parse_executable_path(raw_path, variables=self._safe_environment_paths)

    def _validate_target(self, raw_path: str, *, machine_app_path_target: bool = False) -> Path | None:
        candidate = self._parse_target_path(raw_path)
        if candidate is None:
            return None
        try:
            resolved = candidate.resolve(strict=True)
        except OSError:
            return None
        if resolved.suffix.casefold() != ".exe" or not resolved.is_file():
            return None
        if any(_path_within(resolved, root) for root in self._trusted_roots):
            return resolved
        # A computer-wide App Paths registration is a trusted Windows source
        # for software installed outside the conventional roots (for example a
        # managed game library).  It is still an exact existing .exe and never
        # authorizes user-profile launch locations or any unregistered path.
        if machine_app_path_target and not _is_rejected_machine_app_path(resolved):
            return resolved
        return None

    def _custom_records(self) -> tuple[DiscoveryRecord, ...]:
        records: list[DiscoveryRecord] = []
        for raw_name, raw_value in self._custom.items():
            name = str(raw_name).strip()
            if not _is_safe_public_text(name):
                continue
            if isinstance(raw_value, str):
                records.append(
                    DiscoveryRecord(
                        display_name=_display_name(name),
                        path=raw_value,
                        source=ProgramSource.CUSTOM_CONFIG,
                        aliases=(name,),
                        identifier_hint=name,
                    )
                )
                continue
            if not isinstance(raw_value, Mapping):
                continue
            path = raw_value.get("path")
            if not isinstance(path, str):
                continue
            raw_display = raw_value.get("display_name") or name
            display = _safe_display_name(raw_display)
            if display is None:
                continue
            aliases = raw_value.get("aliases", ())
            alias_values = tuple(str(item) for item in aliases) if isinstance(aliases, (list, tuple)) else ()
            records.append(
                DiscoveryRecord(
                    display_name=display,
                    path=path,
                    source=ProgramSource.CUSTOM_CONFIG,
                    aliases=(name, *alias_values),
                    identifier_hint=name,
                )
            )
        return tuple(records)

    def _records_from_start_menu(self) -> tuple[DiscoveryRecord, ...]:
        """Use a supplied non-executing resolver only; no shell is invoked.

        The standard build does not ship a shortcut parser.  Keeping this hook
        explicit lets a future native resolver be added without accepting raw
        ``.lnk`` files or command-line arguments in the semantic layer.
        """

        if self._shortcut_resolver is None:
            return ()
        records: list[DiscoveryRecord] = []
        for root in self._start_menu_roots:
            try:
                shortcuts = tuple(root.rglob("*.lnk")) if root.is_dir() else ()
            except OSError:
                continue
            for shortcut in shortcuts:
                try:
                    resolved = self._shortcut_resolver(shortcut)
                except Exception:
                    continue
                if resolved is None or resolved.arguments.strip():
                    continue
                display = _safe_display_name(shortcut.stem)
                if display is None:
                    continue
                records.append(
                    DiscoveryRecord(
                        display_name=display,
                        path=resolved.executable,
                        source=ProgramSource.START_MENU,
                        aliases=(display,),
                    )
                )
        return tuple(records)

    @staticmethod
    def _dynamic_identifier(display: str, target: Path) -> str:
        digest = hashlib.sha256(str(target).casefold().encode("utf-8")).hexdigest()[:10]
        return f"program-{_slug(display)}-{digest}"

    @staticmethod
    def _merge_entry(existing: ProgramEntry, incoming: ProgramEntry) -> ProgramEntry:
        aliases = _normal_aliases((*existing.aliases, *incoming.aliases))
        launch_target = existing.launch_target or incoming.launch_target
        source = ProgramSource.BUILTIN if ProgramSource.BUILTIN in (*existing.all_sources, *incoming.all_sources) else existing.source
        return replace(
            existing,
            aliases=aliases,
            source=source,
            launch_target=launch_target,
            sources=existing.all_sources | incoming.all_sources,
            close_process_names=existing.close_process_names | incoming.close_process_names,
            machine_app_path_target=existing.machine_app_path_target or incoming.machine_app_path_target,
        )

    def _add_record(self, entries: dict[str, ProgramEntry], record: DiscoveryRecord) -> None:
        if record.source not in {
            ProgramSource.CUSTOM_CONFIG,
            ProgramSource.APP_PATHS,
            ProgramSource.START_MENU,
        }:
            return
        display = _safe_display_name(record.display_name)
        if display is None:
            return
        if record.identifier_hint is not None and not _is_safe_public_text(record.identifier_hint):
            return
        if any(not _is_safe_public_text(alias) for alias in record.aliases):
            return
        machine_app_path_target = record.source is ProgramSource.APP_PATHS and record.registry_scope == "machine"
        target = self._validate_target(record.path, machine_app_path_target=machine_app_path_target)
        if target is None:
            return
        aliases = _normal_aliases((display, *record.aliases))
        if not aliases:
            return

        # An App Paths/custom discovery for an established Foundation program
        # enriches its launch target instead of making "Spotify" ambiguous with
        # the existing safe canonical identity.
        static_matches = [
            entry
            for entry in entries.values()
            if entry.source is ProgramSource.BUILTIN
            and (normalized_words(entry.display_name) in aliases or entry.identifier in aliases)
        ]
        if len(static_matches) == 1:
            existing = static_matches[0]
            incoming = ProgramEntry(
                identifier=existing.identifier,
                display_name=existing.display_name,
                aliases=aliases,
                source=record.source,
                launch_target=target,
                sources=frozenset({record.source}),
                machine_app_path_target=machine_app_path_target,
            )
            entries[existing.identifier] = self._merge_entry(existing, incoming)
            return

        # Identical targets from two trusted sources are the same program;
        # merge metadata rather than presenting duplicate choices.
        for identifier, existing in tuple(entries.items()):
            if _same_path(existing.launch_target, target):
                incoming = ProgramEntry(
                    identifier=identifier,
                    display_name=existing.display_name,
                    aliases=aliases,
                    source=record.source,
                launch_target=target,
                sources=frozenset({record.source}),
                machine_app_path_target=machine_app_path_target,
                )
                entries[identifier] = self._merge_entry(existing, incoming)
                return

        identifier = self._dynamic_identifier(record.identifier_hint or display, target)
        entries[identifier] = ProgramEntry(
            identifier=identifier,
            display_name=display,
            aliases=aliases,
            source=record.source,
            launch_target=target,
            sources=frozenset({record.source}),
            machine_app_path_target=machine_app_path_target,
        )

    @staticmethod
    def _index(entries: Mapping[str, ProgramEntry]) -> dict[str, tuple[str, ...]]:
        aliases: dict[str, list[str]] = {}
        for identifier, entry in entries.items():
            for alias in _normal_aliases((identifier, *entry.aliases)):
                aliases.setdefault(alias, []).append(identifier)
        return {alias: tuple(sorted(set(values))) for alias, values in aliases.items()}

    def _replace_snapshot(self, records: Iterable[DiscoveryRecord]) -> None:
        entries = self._builtin_entries()
        for record in records:
            self._add_record(entries, record)
        aliases = self._index(entries)
        with self._lock:
            self._entries = entries
            self._aliases = aliases

    def _write_cache(self, records: Iterable[DiscoveryRecord]) -> None:
        path = self._cache_path
        if path is None:
            return
        rows: list[dict[str, object]] = []
        for record in records:
            if record.source not in {ProgramSource.APP_PATHS, ProgramSource.START_MENU}:
                continue
            display = _safe_display_name(record.display_name)
            aliases = _normal_aliases(record.aliases)
            machine_app_path_target = record.source is ProgramSource.APP_PATHS and record.registry_scope == "machine"
            target = self._validate_target(record.path, machine_app_path_target=machine_app_path_target)
            if display is None or not aliases or target is None:
                continue
            rows.append(
                {
                    "display_name": display,
                    "path": str(target),
                    "source": record.source.value,
                    "aliases": list(aliases),
                    "registry_scope": record.registry_scope,
                }
            )
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            temporary = path.with_suffix(path.suffix + ".tmp")
            temporary.write_text(
                json.dumps({"version": _CACHE_VERSION, "entries": rows}, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            temporary.replace(path)
        except OSError:
            # A cache is never authority. Failure to write it only means the
            # next startup performs the small local refresh again.
            return

    def refresh(self) -> int:
        """Rebuild the dynamic snapshot from trusted local sources.

        Registry/shortcut failures are isolated.  A partially failing source
        cannot keep stale entries alive because the completed validated snapshot
        is swapped atomically only after all available records are processed.
        """

        try:
            app_paths = tuple(self._app_paths_reader())
        except Exception:
            app_paths = ()
        start_menu = self._records_from_start_menu()
        discovered = (*app_paths, *start_menu)
        self._replace_snapshot((*self._custom_records(), *discovered))
        self._write_cache(discovered)
        return len(discovered)

    def entries(self) -> tuple[ProgramEntry, ...]:
        with self._lock:
            return tuple(self._entries[key] for key in sorted(self._entries))

    def entry(self, identifier: str) -> ProgramEntry | None:
        clean = normalized_words(identifier)
        with self._lock:
            return self._entries.get(clean)

    def has_valid_launch_target(self, entry: ProgramEntry) -> bool:
        """Revalidate a snapshot target immediately before a launch.

        A cache/snapshot is descriptive rather than authority.  This catches a
        removed, retargeted or now-outside-root executable between refresh and
        ``subprocess.Popen``; normal process-level TOCTOU protection remains a
        Windows responsibility, but NESK never intentionally launches a stale
        directory record.
        """

        if entry.launch_target is None:
            return False
        validated = self._validate_target(
            str(entry.launch_target),
            machine_app_path_target=entry.machine_app_path_target,
        )
        return _same_path(validated, entry.launch_target)

    def allowed_programs(self) -> tuple[str, ...]:
        """Return opaque IDs only; never expose local executable paths."""

        with self._lock:
            return tuple(sorted(self._entries))

    def resolve(self, value: str) -> ProgramResolution:
        raw = str(value or "").strip()
        if not raw or _PATH_LIKE.search(raw):
            return ProgramResolution(ProgramResolutionKind.MISSING)
        clean = normalized_words(raw)
        with self._lock:
            direct = self._entries.get(clean)
            if direct is not None:
                return ProgramResolution(ProgramResolutionKind.UNIQUE, (direct,))
            identifiers = self._aliases.get(clean, ())
            entries = tuple(self._entries[item] for item in identifiers if item in self._entries)
        if not entries:
            return ProgramResolution(ProgramResolutionKind.MISSING)
        if len(entries) == 1:
            return ProgramResolution(ProgramResolutionKind.UNIQUE, entries)
        return ProgramResolution(ProgramResolutionKind.AMBIGUOUS, entries)

    def mentions(self, text: str) -> tuple[ProgramEntry, ...]:
        """Return program mentions in first-occurrence order in the user text.

        Long aliases are tried first *only* when they overlap at the same text
        position.  The returned entity sequence itself follows the text order,
        preventing alias-length matching from reversing clarification choices.
        """

        clean = normalized_words(text)
        if not clean:
            return ()
        with self._lock:
            aliases = dict(self._aliases)
            entries = dict(self._entries)
        candidates: list[tuple[int, int, str, tuple[str, ...]]] = []
        for alias, identifiers in aliases.items():
            if not alias:
                continue
            pattern = rf"(?<![a-z0-9]){re.escape(alias)}(?![a-z0-9])"
            for match in re.finditer(pattern, clean):
                candidates.append((match.start(), match.end(), alias, identifiers))
        candidates.sort(key=lambda item: (item[0], -(item[1] - item[0]), item[2]))
        accepted_spans: list[tuple[int, int]] = []
        output: list[ProgramEntry] = []
        seen: set[str] = set()
        for start, end, _alias, identifiers in candidates:
            if any(start < old_end and end > old_start for old_start, old_end in accepted_spans):
                continue
            accepted_spans.append((start, end))
            for identifier in identifiers:
                if identifier in seen or identifier not in entries:
                    continue
                seen.add(identifier)
                output.append(entries[identifier])
        return tuple(output)

    @staticmethod
    def option_labels(entries: Iterable[ProgramEntry]) -> dict[str, str]:
        values = tuple(entries)
        counts: dict[str, int] = {}
        for entry in values:
            key = entry.display_name.casefold()
            counts[key] = counts.get(key, 0) + 1
        labels: dict[str, str] = {}
        for entry in values:
            label = entry.display_name
            if counts[entry.display_name.casefold()] > 1:
                source = next(iter(sorted(source.value for source in entry.all_sources if source is not ProgramSource.BUILTIN)), "local")
                # Two trusted records with the same display/source still need
                # distinguishable deterministic choices.  The short opaque
                # identity suffix reveals neither a path nor an executable.
                suffix = entry.identifier.rsplit("-", 1)[-1][:6]
                label = f"{label} ({source}, {suffix})"
            labels[entry.identifier] = label
        return labels


__all__ = [
    "AppPathsReader",
    "DiscoveryRecord",
    "ProgramDirectory",
    "ProgramEntry",
    "ProgramResolution",
    "ProgramResolutionKind",
    "ProgramSource",
    "ShortcutResolver",
    "ShortcutTarget",
    "default_trusted_roots",
]
