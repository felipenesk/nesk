from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

import psutil
from PySide6.QtCore import QObject, Qt, QTimer, Signal, Slot
from PySide6.QtGui import QAction, QCloseEvent, QFont
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QPushButton,
    QSizePolicy,
    QStyle,
    QSystemTrayIcon,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from nesk.core.assistant import NeskCore
from nesk.tools.system_status import system_disk_root
from nesk.version import __version__
from nesk.voice.controller import VoiceTurnResult
from nesk.voice.service import VoiceService


class Bridge(QObject):
    reply_ready = Signal(str)
    error = Signal(str)
    voice_turn_ready = Signal(object)
    voice_error = Signal(str)


class StatCard(QFrame):
    """Small, low-cost system metric card used by the desktop shell."""

    def __init__(self, label: str, value: str = "--", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("statCard")
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 11, 14, 11)
        layout.setSpacing(3)

        self.label = QLabel(label.upper())
        self.label.setObjectName("statLabel")
        self.value = QLabel(value)
        self.value.setObjectName("statValue")

        layout.addWidget(self.label)
        layout.addWidget(self.value)

    def set_value(self, value: str) -> None:
        self.value.setText(value)


class MainWindow(QMainWindow):
    """Lightweight desktop shell for the NESK Foundation.

    The UI intentionally avoids blur, particles, continuous animation and
    high-frequency repaint loops so it remains friendly to modest Windows 10
    hardware while the NESK Core runs independently underneath it.
    """

    def __init__(self, core: NeskCore, config: dict, voice_service: VoiceService | None = None) -> None:
        super().__init__()
        self.core = core
        self.config = config
        self.voice_service = voice_service
        self.executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="nesk")
        self.bridge = Bridge()
        self.bridge.reply_ready.connect(self._show_nesk)
        self.bridge.error.connect(self._show_nesk)
        self.bridge.voice_turn_ready.connect(self._show_voice_turn)
        self.bridge.voice_error.connect(self._show_voice_error)
        self._really_close = False
        self._shutdown_done = False

        self.setWindowTitle(f"NESK — First Listen {__version__}")
        self.setMinimumSize(760, 560)
        self.resize(960, 700)

        self._build_ui()
        self._build_tray()
        self._apply_style()
        self._set_state("IDLE", "Pronto para receber uma solicitação")

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._refresh_system)
        self.timer.start(int(config.get("ui", {}).get("system_refresh_ms", 2500)))
        self._refresh_system()

    def _build_ui(self) -> None:
        root = QWidget(self)
        root.setObjectName("appRoot")
        outer = QVBoxLayout(root)
        outer.setContentsMargins(24, 22, 24, 20)
        outer.setSpacing(16)

        # Header -----------------------------------------------------------------
        header = QHBoxLayout()
        header.setSpacing(12)

        mark = QLabel("N")
        mark.setObjectName("brandMark")
        mark.setAlignment(Qt.AlignmentFlag.AlignCenter)
        mark.setFixedSize(42, 42)

        brand = QVBoxLayout()
        brand.setSpacing(0)
        title = QLabel("NESK")
        title.setObjectName("title")
        subtitle = QLabel("PERSONAL INTELLIGENCE SYSTEM")
        subtitle.setObjectName("subtitle")
        brand.addWidget(title)
        brand.addWidget(subtitle)

        header.addWidget(mark)
        header.addLayout(brand)
        header.addStretch()

        self.state_pill = QFrame()
        self.state_pill.setObjectName("statePill")
        state_layout = QHBoxLayout(self.state_pill)
        state_layout.setContentsMargins(11, 7, 11, 7)
        state_layout.setSpacing(7)
        self.state_dot = QLabel("●")
        self.state_dot.setObjectName("stateDot")
        self.state = QLabel("IDLE")
        self.state.setObjectName("stateText")
        state_layout.addWidget(self.state_dot)
        state_layout.addWidget(self.state)
        header.addWidget(self.state_pill)
        outer.addLayout(header)

        # Core card ---------------------------------------------------------------
        core_card = QFrame()
        core_card.setObjectName("coreCard")
        core_layout = QHBoxLayout(core_card)
        core_layout.setContentsMargins(18, 15, 18, 15)
        core_layout.setSpacing(14)

        core_indicator = QLabel("◉")
        core_indicator.setObjectName("coreIndicator")
        core_indicator.setAlignment(Qt.AlignmentFlag.AlignCenter)
        core_indicator.setFixedWidth(34)

        core_text = QVBoxLayout()
        core_text.setSpacing(2)
        core_name = QLabel("NESK CORE")
        core_name.setObjectName("coreName")
        self.core_status = QLabel("Inicializando...")
        self.core_status.setObjectName("coreStatus")
        core_text.addWidget(core_name)
        core_text.addWidget(self.core_status)

        provider = str(self.config.get("ai", {}).get("provider", "local")).upper()
        provider_label = QLabel(f"PROVIDER  {provider}")
        provider_label.setObjectName("providerBadge")

        core_layout.addWidget(core_indicator)
        core_layout.addLayout(core_text, 1)
        core_layout.addWidget(provider_label)
        outer.addWidget(core_card)

        # Lightweight stats -------------------------------------------------------
        stats = QGridLayout()
        stats.setHorizontalSpacing(10)
        stats.setVerticalSpacing(10)
        self.cpu = StatCard("CPU", "--%")
        self.ram = StatCard("RAM", "--%")
        self.disk = StatCard("DISK", "--%")
        self.nesk_ram = StatCard("NESK", "-- MB")
        stats.addWidget(self.cpu, 0, 0)
        stats.addWidget(self.ram, 0, 1)
        stats.addWidget(self.disk, 0, 2)
        stats.addWidget(self.nesk_ram, 0, 3)
        for column in range(4):
            stats.setColumnStretch(column, 1)
        outer.addLayout(stats)

        # Conversation ------------------------------------------------------------
        conversation = QFrame()
        conversation.setObjectName("conversationCard")
        conversation_layout = QVBoxLayout(conversation)
        conversation_layout.setContentsMargins(0, 0, 0, 0)
        conversation_layout.setSpacing(0)

        conversation_header = QHBoxLayout()
        conversation_header.setContentsMargins(16, 13, 16, 10)
        section_title = QLabel("CONVERSA")
        section_title.setObjectName("sectionTitle")
        self.session_hint = QLabel("Sessão local")
        self.session_hint.setObjectName("sessionHint")
        conversation_header.addWidget(section_title)
        conversation_header.addStretch()
        conversation_header.addWidget(self.session_hint)
        conversation_layout.addLayout(conversation_header)

        self.chat = QTextBrowser()
        self.chat.setObjectName("chat")
        self.chat.setOpenExternalLinks(False)
        self.chat.setPlaceholderText("NESK está pronto para o primeiro ciclo de testes.")
        self.chat.document().setDefaultStyleSheet(
            "p { margin: 5px 0 10px 0; } "
            ".who { color: #8a8a8a; font-size: 10px; font-weight: 700; } "
            ".message { color: #eaeaea; font-size: 13px; line-height: 1.35; } "
            ".nesk { color: #e6e6e6; }"
        )
        conversation_layout.addWidget(self.chat, 1)
        outer.addWidget(conversation, 1)

        # Composer ----------------------------------------------------------------
        composer = QFrame()
        composer.setObjectName("composer")
        composer_layout = QHBoxLayout(composer)
        composer_layout.setContentsMargins(10, 9, 10, 9)
        composer_layout.setSpacing(8)

        self.input = QLineEdit()
        self.input.setObjectName("messageInput")
        self.input.setPlaceholderText("Fale com o NESK...")
        self.input.returnPressed.connect(self._send)

        self.voice_button = QPushButton("SEGURE")
        self.voice_button.setObjectName("voiceButton")
        self.voice_button.setToolTip("Segure para falar com o NESK; solte para transcrever.")
        self.voice_button.setEnabled(bool(self.voice_service and self.voice_service.enabled))
        self.voice_button.pressed.connect(self._voice_press)
        self.voice_button.released.connect(self._voice_release)
        self.voice_button.setFixedWidth(78)

        self.send = QPushButton("Enviar")
        self.send.setObjectName("sendButton")
        self.send.clicked.connect(self._send)
        self.send.setFixedWidth(92)

        composer_layout.addWidget(self.input, 1)
        composer_layout.addWidget(self.voice_button)
        composer_layout.addWidget(self.send)
        outer.addWidget(composer)

        footer = QHBoxLayout()
        footer.setContentsMargins(2, 0, 2, 0)
        version = QLabel(f"FIRST LISTEN {__version__}")
        version.setObjectName("footerText")
        provider = "OFF"
        if self.voice_service is not None and self.voice_service.enabled:
            status = getattr(self.voice_service, "status", None)
            provider = str(getattr(status, "stt_provider", "local")).upper()
        self._voice_idle_label = f"VOICE · PUSH-TO-TALK / STT {provider}"
        self.voice_footer = QLabel(self._voice_idle_label)
        self.voice_footer.setObjectName("footerText")
        footer.addWidget(version)
        footer.addStretch()
        footer.addWidget(self.voice_footer)
        outer.addLayout(footer)

        self.setCentralWidget(root)

    def _build_tray(self) -> None:
        self.tray = QSystemTrayIcon(self)
        icon = QApplication.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon)
        self.tray.setIcon(icon)
        self.setWindowIcon(icon)
        menu = QMenu()
        show_action = QAction("Abrir NESK", self)
        show_action.triggered.connect(self._restore)
        exit_action = QAction("Sair", self)
        exit_action.triggered.connect(self._exit)
        menu.addAction(show_action)
        menu.addSeparator()
        menu.addAction(exit_action)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(
            lambda reason: self._restore()
            if reason == QSystemTrayIcon.ActivationReason.Trigger
            else None
        )
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray.show()

    def _apply_style(self) -> None:
        # Deliberately static stylesheet: no blur, shadows, particle layers or
        # high-frequency animation. The visual identity is mostly spacing,
        # hierarchy, borders and restrained accent colors.
        self.setStyleSheet(
            """
            QMainWindow, QWidget#appRoot {
                background: #090909;
                color: #eaeaea;
                font-family: 'Segoe UI';
            }
            QLabel#brandMark {
                background: #141414;
                color: #f2f2f2;
                border: 1px solid #303030;
                border-radius: 12px;
                font-size: 18px;
                font-weight: 800;
            }
            QLabel#title {
                color: #f5f5f5;
                font-size: 24px;
                font-weight: 800;
                letter-spacing: 3px;
            }
            QLabel#subtitle {
                color: #7a7a7a;
                font-size: 9px;
                font-weight: 700;
                letter-spacing: 1px;
            }
            QFrame#statePill {
                background: #151515;
                border: 1px solid #303030;
                border-radius: 13px;
            }
            QLabel#stateDot { color: #f2f2f2; font-size: 10px; }
            QLabel#stateText {
                color: #d0d0d0;
                font-size: 10px;
                font-weight: 800;
                letter-spacing: 1px;
            }
            QFrame#coreCard {
                background: #101010;
                border: 1px solid #2a2a2a;
                border-radius: 13px;
            }
            QLabel#coreIndicator {
                color: #ededed;
                font-size: 25px;
            }
            QLabel#coreName {
                color: #dddddd;
                font-size: 11px;
                font-weight: 800;
                letter-spacing: 1px;
            }
            QLabel#coreStatus { color: #888888; font-size: 11px; }
            QLabel#providerBadge {
                background: #171717;
                color: #a0a0a0;
                border: 1px solid #303030;
                border-radius: 8px;
                padding: 6px 9px;
                font-size: 9px;
                font-weight: 700;
            }
            QFrame#statCard {
                background: #111111;
                border: 1px solid #282828;
                border-radius: 11px;
            }
            QLabel#statLabel {
                color: #777777;
                font-size: 9px;
                font-weight: 800;
                letter-spacing: 1px;
            }
            QLabel#statValue {
                color: #eeeeee;
                font-size: 16px;
                font-weight: 700;
            }
            QFrame#conversationCard {
                background: #0f0f0f;
                border: 1px solid #292929;
                border-radius: 13px;
            }
            QLabel#sectionTitle {
                color: #9a9a9a;
                font-size: 9px;
                font-weight: 800;
                letter-spacing: 1px;
            }
            QLabel#sessionHint { color: #6d6d6d; font-size: 9px; }
            QTextBrowser#chat {
                background: transparent;
                border: none;
                border-top: 1px solid #222222;
                padding: 15px 16px;
                color: #eaeaea;
                selection-background-color: #555555;
                font-size: 13px;
            }
            QFrame#composer {
                background: #111111;
                border: 1px solid #303030;
                border-radius: 13px;
            }
            QLineEdit#messageInput {
                background: transparent;
                border: none;
                color: #f0f0f0;
                padding: 8px 6px;
                font-size: 13px;
                selection-background-color: #555555;
            }
            QLineEdit#messageInput:disabled { color: #707070; }
            QPushButton#sendButton {
                background: #f2f2f2;
                color: #111111;
                border: none;
                border-radius: 9px;
                padding: 9px 15px;
                font-size: 11px;
                font-weight: 800;
            }
            QPushButton#sendButton:hover { background: #ffffff; }
            QPushButton#sendButton:pressed { background: #d8d8d8; }
            QPushButton#sendButton:disabled {
                background: #303030;
                color: #747474;
            }
            QPushButton#voiceButton {
                background: #141414;
                color: #d7d7d7;
                border: 1px solid #3a3a3a;
                border-radius: 9px;
                padding: 9px 10px;
                font-size: 9px;
                font-weight: 800;
            }
            QPushButton#voiceButton:hover { background: #1b1b1b; }
            QPushButton#voiceButton:pressed {
                background: #eeeeee;
                color: #111111;
            }
            QPushButton#voiceButton:disabled {
                background: #151515;
                color: #555555;
                border-color: #272727;
            }
            QLabel#footerText {
                color: #5e5e5e;
                font-size: 8px;
                font-weight: 700;
                letter-spacing: 1px;
            }
            QToolTip {
                background: #1a1a1a;
                color: #dedede;
                border: 1px solid #333333;
                padding: 5px;
            }
            QMenu {
                background: #151515;
                color: #dedede;
                border: 1px solid #303030;
            }
            QMenu::item:selected { background: #252525; }
            """
        )

    def _set_state(self, state: str, detail: str) -> None:
        state = state.upper()
        self.state.setText(state)
        self.core_status.setText(detail)
        if state in {"IDLE", "ONLINE"}:
            color = "#f2f2f2"
        elif state in {"PROCESSING", "THINKING", "SEARCHING", "EXECUTING"}:
            color = "#d8d8d8"
        elif state in {"ERROR", "OFFLINE"}:
            color = "#8a8a8a"
        else:
            color = "#bcbcbc"
        self.state_dot.setStyleSheet(f"color: {color};")

    @Slot()
    def _send(self) -> None:
        text = self.input.text().strip()
        if not text:
            return
        self.input.clear()
        escaped = self._escape(text)
        self.chat.append(
            f'<p><span class="who">VOCÊ</span><br>'
            f'<span class="message">{escaped}</span></p>'
        )
        self.input.setEnabled(False)
        self.send.setEnabled(False)
        if hasattr(self, "voice_button"):
            self.voice_button.setEnabled(False)
        self._set_state("PROCESSING", "Interpretando sua solicitação")

        future = self.executor.submit(self.core.handle, text)
        future.add_done_callback(self._future_done)

    def _future_done(self, future) -> None:
        try:
            result = future.result()
            self.bridge.reply_ready.emit(result.text)
        except Exception as exc:
            self.core.logger.exception("ui_worker_error type=%s", type(exc).__name__)
            self.bridge.error.emit(
                f"Erro interno: {type(exc).__name__}. Detalhes foram salvos no log do NESK."
            )

    @Slot(str)
    def _show_nesk(self, text: str) -> None:
        escaped = self._escape(text)
        self.chat.append(
            f'<p><span class="who nesk">NESK</span><br>'
            f'<span class="message">{escaped}</span></p>'
        )
        self.input.setEnabled(True)
        self.send.setEnabled(True)
        if hasattr(self, "voice_button"):
            self.voice_button.setEnabled(bool(self.voice_service and self.voice_service.enabled))
            self.voice_button.setText("SEGURE")
        self.input.setFocus()
        self._set_state("IDLE", "Pronto para receber uma solicitação")

    @Slot()
    def _voice_press(self) -> None:
        if self.voice_service is None or not self.voice_service.enabled:
            return
        if not self.input.isEnabled():
            return
        try:
            self.voice_service.start_listening()
        except Exception as exc:
            self.core.logger.exception("voice_capture_start_error type=%s", type(exc).__name__)
            self._show_voice_error(str(exc))
            return
        self.input.setEnabled(False)
        self.send.setEnabled(False)
        self.voice_button.setText("SOLTE")
        self.voice_footer.setText("VOICE · OUVINDO")
        self._set_state("LISTENING", "Ouvindo enquanto você segura o botão")

    @Slot()
    def _voice_release(self) -> None:
        if self.voice_service is None or not self.voice_service.recording:
            return
        self.voice_button.setEnabled(False)
        self.voice_button.setText("...")
        self.voice_footer.setText("VOICE · TRANSCREVENDO")
        self._set_state("TRANSCRIBING", "Transcrevendo; o primeiro uso pode preparar o modelo local")
        future = self.executor.submit(self.voice_service.finish_turn)
        future.add_done_callback(self._voice_future_done)

    def _voice_future_done(self, future) -> None:
        try:
            result = future.result()
            self.bridge.voice_turn_ready.emit(result)
        except Exception as exc:
            self.core.logger.exception("voice_worker_error type=%s", type(exc).__name__)
            message = str(exc).strip() or f"Erro de voz: {type(exc).__name__}"
            self.bridge.voice_error.emit(message)

    @Slot(object)
    def _show_voice_turn(self, result: VoiceTurnResult) -> None:
        if result.accepted:
            transcript = self._escape(result.transcript)
            response = self._escape(result.response)
            self.chat.append(
                f'<p><span class="who">VOCÊ · VOZ</span><br>'
                f'<span class="message">{transcript}</span></p>'
            )
            self.chat.append(
                f'<p><span class="who nesk">NESK</span><br>'
                f'<span class="message">{response}</span></p>'
            )
        else:
            reason = self._escape(result.reason or "não consegui reconhecer essa fala")
            self.chat.append(
                f'<p><span class="who nesk">NESK · VOICE</span><br>'
                f'<span class="message">Não processei esse áudio: {reason}.</span></p>'
            )
        self._reset_voice_ui()

    @Slot(str)
    def _show_voice_error(self, message: str) -> None:
        escaped = self._escape(message)
        self.chat.append(
            f'<p><span class="who nesk">NESK · VOICE</span><br>'
            f'<span class="message">{escaped}</span></p>'
        )
        self._set_state("ERROR", "Falha no ciclo de voz")
        self._reset_voice_ui(keep_state=False)

    def _reset_voice_ui(self, *, keep_state: bool = True) -> None:
        self.input.setEnabled(True)
        self.send.setEnabled(True)
        self.voice_button.setEnabled(bool(self.voice_service and self.voice_service.enabled))
        self.voice_button.setText("SEGURE")
        self.voice_footer.setText(self._voice_idle_label)
        self.input.setFocus()
        if keep_state:
            self._set_state("IDLE", "Pronto para receber uma solicitação")

    @Slot()
    def _refresh_system(self) -> None:
        self.cpu.set_value(f"{psutil.cpu_percent(interval=None):.0f}%")
        self.ram.set_value(f"{psutil.virtual_memory().percent:.0f}%")
        try:
            self.disk.set_value(f"{psutil.disk_usage(system_disk_root()).percent:.0f}%")
        except OSError:
            self.disk.set_value("--%")
        try:
            own_mb = psutil.Process().memory_info().rss / (1024**2)
            self.nesk_ram.set_value(f"{own_mb:.0f} MB")
        except (psutil.Error, OSError):
            self.nesk_ram.set_value("-- MB")

    @staticmethod
    def _escape(text: str) -> str:
        import html

        return html.escape(text).replace("\n", "<br>")

    def _restore(self) -> None:
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def shutdown(self) -> None:
        """Idempotent UI shutdown called from QApplication.aboutToQuit."""
        if self._shutdown_done:
            return
        self._shutdown_done = True
        try:
            self.timer.stop()
        except RuntimeError:
            pass
        if hasattr(self, "tray"):
            self.tray.hide()
        if self.voice_service is not None:
            self.voice_service.close()
        self.executor.shutdown(wait=False, cancel_futures=True)

    def _exit(self) -> None:
        self._really_close = True
        QApplication.quit()

    def closeEvent(self, event: QCloseEvent) -> None:
        minimize = bool(self.config.get("ui", {}).get("minimize_to_tray", True))
        if minimize and not self._really_close and QSystemTrayIcon.isSystemTrayAvailable():
            event.ignore()
            self.hide()
            self.tray.showMessage(
                "NESK",
                "Continuo rodando em segundo plano.",
                QSystemTrayIcon.MessageIcon.Information,
                1500,
            )
            return
        event.accept()
        QApplication.quit()
