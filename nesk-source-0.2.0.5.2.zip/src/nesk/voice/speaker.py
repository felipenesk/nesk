from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True, slots=True)
class SpeakerDecision:
    accepted: bool
    confidence: float
    speaker_id: str | None = None
    reason: str = ""


class SpeakerVerifier(Protocol):
    """Future speaker-verification boundary.

    Implementations may use a local voiceprint model later. The Foundation stores
    no raw audio and ships with no biometric enrollment enabled.
    """

    def verify(self, audio: bytes) -> SpeakerDecision: ...


class DisabledSpeakerVerifier:
    def verify(self, audio: bytes) -> SpeakerDecision:
        return SpeakerDecision(False, 0.0, reason="speaker verification desativada")
