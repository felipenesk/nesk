from __future__ import annotations

from dataclasses import dataclass

from nesk.core.assistant import NeskCore
from nesk.core.models import AssistantResult
from nesk.voice.audio import CapturedAudio
from nesk.voice.contracts import SpeechToTextProvider, TextToSpeechProvider
from nesk.voice.session import VoiceSession, VoiceState
from nesk.voice.speaker import SpeakerVerifier


@dataclass(frozen=True, slots=True)
class VoiceTurnResult:
    accepted: bool
    transcript: str = ""
    response: str = ""
    reason: str = ""
    audio_seconds: float | None = None
    stt_seconds: float | None = None
    realtime_factor: float | None = None


class VoiceController:
    """The narrow adapter from a verified transcript into the existing Core."""

    def __init__(
        self,
        *,
        core: NeskCore,
        stt: SpeechToTextProvider | None = None,
        tts: TextToSpeechProvider | None = None,
        speaker_verifier: SpeakerVerifier | None = None,
        require_speaker: bool = False,
        speaker_threshold: float = 0.82,
        owns_stt: bool = True,
    ) -> None:
        self.core = core
        # ``stt`` remains optional only for the legacy process_audio adapter.
        # Runtime First Listen uses SpeechPipeline below this controller.
        self.stt = stt
        self.owns_stt = bool(owns_stt)
        self.tts = tts
        self.speaker_verifier = speaker_verifier
        self.require_speaker = require_speaker
        self.speaker_threshold = speaker_threshold
        self.session = VoiceSession(VoiceState.IDLE)
        self._closed = False

    def begin_listening(self) -> None:
        if self._closed:
            raise RuntimeError("Voice Controller já foi encerrado")
        if self.session.state == VoiceState.ERROR:
            self.session.transition(VoiceState.IDLE)
        if self.session.state != VoiceState.IDLE:
            raise RuntimeError(f"Voice ocupada: {self.session.state.value}")
        self.session.transition(VoiceState.LISTENING)

    def cancel_listening(self) -> None:
        if self.session.state in {
            VoiceState.LISTENING,
            VoiceState.TRANSCRIBING,
            VoiceState.PROCESSING,
            VoiceState.SPEAKING,
            VoiceState.ERROR,
        }:
            try:
                self.session.transition(VoiceState.IDLE)
            except ValueError:
                self.session.state = VoiceState.IDLE

    def _ensure_listening(self) -> None:
        if self.session.state == VoiceState.IDLE:
            self.begin_listening()
        elif self.session.state != VoiceState.LISTENING:
            raise RuntimeError(f"Voice não pode processar no estado {self.session.state.value}")

    def _reject_speaker(self, audio: CapturedAudio) -> VoiceTurnResult | None:
        if not self.require_speaker:
            return None
        if self.speaker_verifier is None:
            self.session.transition(VoiceState.ERROR)
            return VoiceTurnResult(False, reason="speaker verification indisponível")
        decision = self.speaker_verifier.verify(audio)
        if not decision.accepted or decision.confidence < self.speaker_threshold:
            self.session.transition(VoiceState.IDLE)
            return VoiceTurnResult(False, reason=decision.reason or "voz não reconhecida")
        return None

    def pre_transcription_rejection(self, audio: CapturedAudio) -> str | None:
        """Return a fail-closed speaker reason before the shared STT decode.

        The pipeline remains independent from Core and speaker classes.
        VoiceService supplies this callback only for the existing Foundation
        speaker-verification option.
        """
        rejected = self._reject_speaker(audio)
        return rejected.reason if rejected is not None else None

    def _complete_transcript(
        self,
        transcript: str,
        *,
        audio_seconds: float | None,
        stt_seconds: float | None,
        realtime_factor: float | None,
    ) -> VoiceTurnResult:
        self.session.transition(VoiceState.PROCESSING)
        result: AssistantResult = self.core.handle(transcript)
        if self.tts is not None:
            self.session.transition(VoiceState.SPEAKING)
            self.tts.speak(result.text)
        self.session.transition(VoiceState.IDLE)
        self.core.events.publish(
            "voice.turn.completed",
            accepted=True,
            audio_seconds=audio_seconds,
            stt_seconds=stt_seconds,
            realtime_factor=realtime_factor,
        )
        return VoiceTurnResult(
            True,
            transcript=transcript,
            response=result.text,
            audio_seconds=audio_seconds,
            stt_seconds=stt_seconds,
            realtime_factor=realtime_factor,
        )

    def process_transcript(
        self,
        transcript: str,
        *,
        audio_seconds: float | None = None,
        stt_seconds: float | None = None,
        realtime_factor: float | None = None,
    ) -> VoiceTurnResult:
        """Route one already-verified transcript through the only NESK Core."""
        clean = transcript.strip()
        if not clean:
            self.cancel_listening()
            return VoiceTurnResult(False, reason="nenhuma fala reconhecida")
        self._ensure_listening()
        try:
            self.session.transition(VoiceState.TRANSCRIBING)
            return self._complete_transcript(
                clean,
                audio_seconds=audio_seconds,
                stt_seconds=stt_seconds,
                realtime_factor=realtime_factor,
            )
        except Exception:
            try:
                if self.session.state != VoiceState.ERROR:
                    self.session.transition(VoiceState.ERROR)
            except ValueError:
                self.session.state = VoiceState.ERROR
            raise

    def process_audio(self, audio: CapturedAudio) -> VoiceTurnResult:
        """Compatibility adapter; new runtime callers use SpeechPipeline instead."""
        if audio.empty:
            self.cancel_listening()
            return VoiceTurnResult(False, reason="audio vazio")
        if self.stt is None:
            raise RuntimeError("VoiceController sem STT legado")
        self._ensure_listening()
        try:
            rejected = self._reject_speaker(audio)
            if rejected is not None:
                return rejected
            self.session.transition(VoiceState.TRANSCRIBING)
            transcript = self.stt.transcribe(audio).strip()
            diagnostics = getattr(self.stt, "last_diagnostics", None)
            if not transcript:
                self.session.transition(VoiceState.IDLE)
                if bool(getattr(diagnostics, "quality_rejected", False)):
                    return VoiceTurnResult(False, reason="fala descartada porque o reconhecimento ficou com baixa confiança")
                return VoiceTurnResult(False, reason="nenhuma fala reconhecida")
            return self._complete_transcript(
                transcript,
                audio_seconds=getattr(diagnostics, "audio_seconds", audio.duration_seconds),
                stt_seconds=getattr(diagnostics, "inference_seconds", None),
                realtime_factor=getattr(diagnostics, "realtime_factor", None),
            )
        except Exception:
            try:
                if self.session.state != VoiceState.ERROR:
                    self.session.transition(VoiceState.ERROR)
            except ValueError:
                self.session.state = VoiceState.ERROR
            raise

    def close(self) -> None:
        """Close providers this adapter owns, preserving the legacy contract."""
        if self._closed:
            return
        self.cancel_listening()
        self._closed = True
        providers = (self.stt if self.owns_stt else None, self.tts)
        for provider in providers:
            if provider is None:
                continue
            close = getattr(provider, "close", None)
            if callable(close):
                try:
                    close()
                except Exception:
                    pass
