from __future__ import annotations

import io
import os
import re
import threading
import time
import wave
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable

from nesk.voice.audio import CapturedAudio
from nesk.voice.contracts import SpeechToTextProvider
from nesk.voice.frontend import AudioFrontendError, prepare_speech


class SpeechToTextError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class STTDiagnostics:
    """Content-free telemetry for one local transcription attempt."""

    audio_seconds: float
    prepared_audio_seconds: float
    preprocessing_seconds: float
    inference_seconds: float
    realtime_factor: float
    language: str
    segment_count: int
    average_logprob: float | None
    max_no_speech_probability: float | None = None
    max_compression_ratio: float | None = None
    quality_rejected: bool = False
    rejection_reason: str | None = None
    model_load_count: int = 0


DEFAULT_PTBR_INITIAL_PROMPT = "Português brasileiro. Transcreva apenas a fala ou retorne vazio."
DEFAULT_PTBR_HOTWORDS = "NESK Discord YouTube Google Minecraft Valorant"


def _pcm16_to_mono_float32(audio: CapturedAudio, *, target_rate: int = 16000):
    """Compatibility helper for diagnostics and tests; preparation happens once."""
    return prepare_speech(audio, target_rate=target_rate).waveform


def _mean_optional(values: Iterable[float | None]) -> float | None:
    usable = [float(value) for value in values if value is not None]
    return (sum(usable) / len(usable)) if usable else None


def _max_optional(values: Iterable[float | None]) -> float | None:
    usable = [float(value) for value in values if value is not None]
    return max(usable) if usable else None


def _has_repeated_phrase(text: str) -> bool:
    """Recognize pathological adjacent phrase repetition without changing text."""
    tokens = re.findall(r"[\wÀ-ÿ]+", text.casefold(), flags=re.UNICODE)
    # One-word emphasis ("não, não") is ordinary speech. Repeated phrases of
    # two or more words are a common silent-audio decode failure and are safely
    # rejected rather than routed into Core.
    for width in range(2, min(8, len(tokens) // 2) + 1):
        for start in range(0, len(tokens) - (2 * width) + 1):
            if tokens[start : start + width] == tokens[start + width : start + (2 * width)]:
                return True
    return False


@dataclass(frozen=True, slots=True)
class _DecodeResult:
    text: str
    language: str
    segment_count: int
    average_logprob: float | None
    max_no_speech_probability: float | None
    max_compression_ratio: float | None
    inference_seconds: float


class FasterWhisperSTTProvider(SpeechToTextProvider):
    """Lazy CPU-first local STT with exactly one decode per captured turn.

    The model may receive a small language/vocabulary hint, but no command
    retry, transcript rewrite, or alternate prompt is allowed. A transcript is
    either the single acoustic decode or a safe rejection.
    """

    def __init__(
        self,
        *,
        model_size: str = "small",
        language: str = "pt",
        device: str = "cpu",
        compute_type: str = "int8",
        download_root: Path | None = None,
        cpu_threads: int = 0,
        beam_size: int = 5,
        patience: float = 1.0,
        initial_prompt: str | None = DEFAULT_PTBR_INITIAL_PROMPT,
        hotwords: str | None = DEFAULT_PTBR_HOTWORDS,
        vad_filter: bool = True,
        vad_threshold: float = 0.5,
        vad_min_speech_ms: int = 100,
        vad_min_silence_ms: int = 500,
        vad_speech_pad_ms: int = 180,
        max_new_tokens: int | None = 64,
        log_prob_threshold: float | None = -1.0,
        no_speech_threshold: float | None = 0.80,
        compression_ratio_threshold: float | None = 2.6,
        model_factory: Callable[..., Any] | None = None,
        **_legacy: Any,
    ) -> None:
        if beam_size < 1:
            raise ValueError("beam_size deve ser >= 1")
        if patience <= 0:
            raise ValueError("patience deve ser positivo")
        if not 0 < vad_threshold < 1:
            raise ValueError("vad_threshold deve estar entre 0 e 1")
        if min(vad_min_speech_ms, vad_min_silence_ms, vad_speech_pad_ms) < 0:
            raise ValueError("parâmetros VAD em milissegundos não podem ser negativos")
        if max_new_tokens is not None and max_new_tokens < 1:
            raise ValueError("max_new_tokens deve ser positivo")
        if no_speech_threshold is not None and not 0 <= no_speech_threshold <= 1:
            raise ValueError("no_speech_threshold deve estar entre 0 e 1")
        if compression_ratio_threshold is not None and compression_ratio_threshold <= 0:
            raise ValueError("compression_ratio_threshold deve ser positivo")

        self.model_size = model_size
        self.language = language
        self.device = device
        self.compute_type = compute_type
        self.download_root = download_root
        self.cpu_threads = int(cpu_threads)
        self.beam_size = int(beam_size)
        self.patience = float(patience)
        self.initial_prompt = initial_prompt.strip() if initial_prompt else None
        self.hotwords = hotwords.strip() if hotwords else None
        self.vad_filter = bool(vad_filter)
        self.vad_threshold = float(vad_threshold)
        self.vad_min_speech_ms = int(vad_min_speech_ms)
        self.vad_min_silence_ms = int(vad_min_silence_ms)
        self.vad_speech_pad_ms = int(vad_speech_pad_ms)
        self.max_new_tokens = max_new_tokens
        self.log_prob_threshold = None if log_prob_threshold is None else float(log_prob_threshold)
        self.no_speech_threshold = None if no_speech_threshold is None else float(no_speech_threshold)
        self.compression_ratio_threshold = (
            None if compression_ratio_threshold is None else float(compression_ratio_threshold)
        )
        self._model_factory = model_factory
        self._model: Any | None = None
        self._load_lock = threading.Lock()
        self._model_load_count = 0
        self.last_diagnostics: STTDiagnostics | None = None

    def _factory(self) -> Callable[..., Any]:
        if self._model_factory is not None:
            return self._model_factory
        try:
            from faster_whisper import WhisperModel  # type: ignore
        except ImportError as exc:  # pragma: no cover - field dependency failure
            raise SpeechToTextError(
                "faster-whisper não está instalado. Rode a instalação da versão 0.2 novamente."
            ) from exc
        return WhisperModel

    def _get_model(self) -> Any:
        if self._model is not None:
            return self._model
        with self._load_lock:
            if self._model is not None:
                return self._model
            kwargs: dict[str, Any] = {"device": self.device, "compute_type": self.compute_type}
            if self.download_root is not None:
                self.download_root.mkdir(parents=True, exist_ok=True)
                kwargs["download_root"] = str(self.download_root)
            if self.cpu_threads > 0:
                kwargs["cpu_threads"] = self.cpu_threads
            try:
                self._model = self._factory()(self.model_size, **kwargs)
            except Exception as exc:
                raise SpeechToTextError(
                    "Não consegui carregar o modelo local de voz. Na primeira execução ele pode precisar de internet para baixar o modelo."
                ) from exc
            self._model_load_count += 1
            return self._model

    def _transcribe_kwargs(self) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "language": self.language,
            "task": "transcribe",
            "beam_size": self.beam_size,
            "patience": self.patience,
            "temperature": 0.0,
            "condition_on_previous_text": False,
            "without_timestamps": True,
            "word_timestamps": False,
            "initial_prompt": self.initial_prompt,
            "hotwords": self.hotwords,
            "max_new_tokens": self.max_new_tokens,
            "vad_filter": self.vad_filter,
            "log_prob_threshold": self.log_prob_threshold,
            "no_speech_threshold": self.no_speech_threshold,
            "compression_ratio_threshold": self.compression_ratio_threshold,
        }
        if self.vad_filter:
            kwargs["vad_parameters"] = {
                "threshold": self.vad_threshold,
                "min_speech_duration_ms": self.vad_min_speech_ms,
                "min_silence_duration_ms": self.vad_min_silence_ms,
                "speech_pad_ms": self.vad_speech_pad_ms,
            }
        return kwargs

    def _decode(self, waveform: object) -> _DecodeResult:
        started = time.perf_counter()
        segments_iter, info = self._get_model().transcribe(waveform, **self._transcribe_kwargs())
        segments = list(segments_iter)
        elapsed = max(0.0, time.perf_counter() - started)
        text = " ".join(str(segment.text).strip() for segment in segments if str(segment.text).strip()).strip()
        return _DecodeResult(
            text=text,
            language=str(getattr(info, "language", self.language) or self.language),
            segment_count=len(segments),
            average_logprob=_mean_optional(getattr(segment, "avg_logprob", None) for segment in segments),
            max_no_speech_probability=_max_optional(
                getattr(segment, "no_speech_prob", None) for segment in segments
            ),
            max_compression_ratio=_max_optional(
                getattr(segment, "compression_ratio", None) for segment in segments
            ),
            inference_seconds=elapsed,
        )

    def _quality_rejection_reason(self, decoded: _DecodeResult) -> str | None:
        """Mirror the decoder's confidence semantics instead of adding a rival gate."""
        if not decoded.text:
            return None
        if _has_repeated_phrase(decoded.text):
            return "repetitive_decode"
        if (
            self.no_speech_threshold is not None
            and decoded.max_no_speech_probability is not None
            and decoded.max_no_speech_probability > self.no_speech_threshold
            and (
                self.log_prob_threshold is None
                or decoded.average_logprob is None
                or decoded.average_logprob < self.log_prob_threshold
            )
        ):
            return "likely_silence"
        if (
            self.log_prob_threshold is not None
            and decoded.average_logprob is not None
            and decoded.average_logprob < self.log_prob_threshold
        ):
            return "low_confidence"
        if (
            self.compression_ratio_threshold is not None
            and decoded.max_compression_ratio is not None
            and decoded.max_compression_ratio > self.compression_ratio_threshold
        ):
            return "repetitive_decode"
        return None

    def transcribe(self, audio: CapturedAudio) -> str:
        if audio.empty:
            self.last_diagnostics = STTDiagnostics(
                audio_seconds=0.0,
                prepared_audio_seconds=0.0,
                preprocessing_seconds=0.0,
                inference_seconds=0.0,
                realtime_factor=0.0,
                language=self.language,
                segment_count=0,
                average_logprob=None,
                rejection_reason="empty_audio",
                model_load_count=self._model_load_count,
            )
            return ""

        try:
            preprocessing_started = time.perf_counter()
            prepared = prepare_speech(audio)
            preprocessing_seconds = max(0.0, time.perf_counter() - preprocessing_started)
        except (AudioFrontendError, ValueError) as exc:
            self.last_diagnostics = None
            raise SpeechToTextError(f"Falha ao preparar áudio local: {type(exc).__name__}") from exc

        try:
            decoded = self._decode(prepared.waveform)
        except Exception as exc:
            self.last_diagnostics = None
            if isinstance(exc, SpeechToTextError):
                raise
            raise SpeechToTextError(f"Falha ao transcrever áudio local: {type(exc).__name__}") from exc

        rejection_reason = self._quality_rejection_reason(decoded)
        self.last_diagnostics = STTDiagnostics(
            audio_seconds=audio.duration_seconds,
            prepared_audio_seconds=prepared.output_seconds,
            preprocessing_seconds=preprocessing_seconds,
            inference_seconds=decoded.inference_seconds,
            realtime_factor=(decoded.inference_seconds / audio.duration_seconds) if audio.duration_seconds else 0.0,
            language=decoded.language,
            segment_count=decoded.segment_count,
            average_logprob=decoded.average_logprob,
            max_no_speech_probability=decoded.max_no_speech_probability,
            max_compression_ratio=decoded.max_compression_ratio,
            quality_rejected=rejection_reason is not None,
            rejection_reason=rejection_reason,
            model_load_count=self._model_load_count,
        )
        return "" if rejection_reason else decoded.text

    def close(self) -> None:
        with self._load_lock:
            self._model = None
        self.last_diagnostics = None


class OpenAITranscriptionSTTProvider(SpeechToTextProvider):
    """Optional cloud STT. The WAV lives in memory and is never written to disk."""

    def __init__(self, *, model: str = "gpt-4o-mini-transcribe", language: str = "pt", client: Any | None = None) -> None:
        self.model = model
        self.language = language
        self._client = client

    def _get_client(self) -> Any:
        if self._client is not None:
            return self._client
        if not os.getenv("OPENAI_API_KEY"):
            raise SpeechToTextError("OPENAI_API_KEY não configurada para STT em nuvem")
        try:
            from openai import OpenAI  # type: ignore
        except ImportError as exc:  # pragma: no cover
            raise SpeechToTextError("Pacote openai não instalado") from exc
        self._client = OpenAI()
        return self._client

    @staticmethod
    def _wav_buffer(audio: CapturedAudio) -> io.BytesIO:
        buffer = io.BytesIO()
        with wave.open(buffer, "wb") as wav:
            wav.setnchannels(audio.channels)
            wav.setsampwidth(2)
            wav.setframerate(audio.sample_rate)
            wav.writeframes(audio.pcm16)
        buffer.seek(0)
        buffer.name = "nesk_voice.wav"  # type: ignore[attr-defined]
        return buffer

    def transcribe(self, audio: CapturedAudio) -> str:
        if audio.empty:
            return ""
        try:
            result = self._get_client().audio.transcriptions.create(
                model=self.model,
                file=self._wav_buffer(audio),
                language=self.language,
            )
        except Exception as exc:
            raise SpeechToTextError(f"Falha no STT em nuvem: {type(exc).__name__}") from exc
        return str(getattr(result, "text", "")).strip()

    def close(self) -> None:
        client = self._client
        self._client = None
        close = getattr(client, "close", None) if client is not None else None
        if callable(close):
            close()


def _config_text(value: Any, default: str | None) -> str | None:
    if value is None:
        return default
    if isinstance(value, (list, tuple)):
        joined = " ".join(str(item).strip() for item in value if str(item).strip())
        return joined or None
    text = str(value).strip()
    return text or None


def create_stt_provider(config: dict[str, Any], *, data_root: Path) -> SpeechToTextProvider:
    voice = config.get("voice", {})
    stt = voice.get("stt", {})
    provider = str(stt.get("provider", "local")).strip().lower()
    language = str(stt.get("language", "pt")).strip() or "pt"
    if provider == "openai":
        return OpenAITranscriptionSTTProvider(
            model=str(stt.get("cloud_model", "gpt-4o-mini-transcribe")),
            language=language,
        )
    if provider != "local":
        raise SpeechToTextError(f"Provider STT desconhecido: {provider}")

    cache = Path(os.getenv("NESK_MODEL_DIR", str(data_root / "models"))) / "faster-whisper"
    return FasterWhisperSTTProvider(
        model_size=str(stt.get("local_model", "small")),
        language=language,
        device=str(stt.get("device", "cpu")),
        compute_type=str(stt.get("compute_type", "int8")),
        download_root=cache,
        cpu_threads=int(stt.get("cpu_threads", 0) or 0),
        beam_size=int(stt.get("beam_size", 5) or 5),
        patience=float(stt.get("patience", 1.0) or 1.0),
        initial_prompt=_config_text(stt.get("initial_prompt"), DEFAULT_PTBR_INITIAL_PROMPT),
        hotwords=_config_text(stt.get("hotwords"), DEFAULT_PTBR_HOTWORDS),
        vad_filter=bool(stt.get("vad_filter", True)),
        vad_threshold=float(stt.get("vad_threshold", 0.5)),
        vad_min_speech_ms=int(stt.get("vad_min_speech_ms", 100)),
        vad_min_silence_ms=int(stt.get("vad_min_silence_ms", 500)),
        vad_speech_pad_ms=int(stt.get("vad_speech_pad_ms", 180)),
        max_new_tokens=None if stt.get("max_new_tokens", 64) is None else int(stt.get("max_new_tokens", 64)),
        log_prob_threshold=(
            None if stt.get("log_prob_threshold", -1.0) is None else float(stt.get("log_prob_threshold", -1.0))
        ),
        no_speech_threshold=(
            None if stt.get("no_speech_threshold", 0.80) is None else float(stt.get("no_speech_threshold", 0.80))
        ),
        compression_ratio_threshold=(
            None
            if stt.get("compression_ratio_threshold", 2.6) is None
            else float(stt.get("compression_ratio_threshold", 2.6))
        ),
    )


__all__ = [
    "DEFAULT_PTBR_HOTWORDS",
    "DEFAULT_PTBR_INITIAL_PROMPT",
    "FasterWhisperSTTProvider",
    "OpenAITranscriptionSTTProvider",
    "STTDiagnostics",
    "SpeechToTextError",
    "create_stt_provider",
]
