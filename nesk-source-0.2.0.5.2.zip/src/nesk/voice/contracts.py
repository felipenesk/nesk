from __future__ import annotations

from abc import ABC, abstractmethod

from nesk.voice.audio import CapturedAudio


class SpeechToTextProvider(ABC):
    @abstractmethod
    def transcribe(self, audio: CapturedAudio) -> str:
        """Convert one in-memory capture into text without executing actions."""
        raise NotImplementedError

    def close(self) -> None:
        """Release optional model/client resources. Must be safe to call twice."""
        return None


class TextToSpeechProvider(ABC):
    @abstractmethod
    def speak(self, text: str) -> None:
        """Speak NESK output. Implementations must not mutate conversation state."""
        raise NotImplementedError

    def close(self) -> None:
        return None


class WakeWordDetector(ABC):
    @abstractmethod
    def detected(self, audio: CapturedAudio) -> bool:
        """Return whether the configured wake word is present in a capture."""
        raise NotImplementedError
