from __future__ import annotations

import math
import threading
import time
from dataclasses import dataclass
from typing import Any

from nesk.voice.audio import CapturedAudio


class MicrophoneError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class MicrophoneDevice:
    index: int
    name: str
    default_sample_rate: int
    max_input_channels: int


@dataclass(frozen=True, slots=True)
class CaptureResult:
    """One completed capture plus the integrity facts observed by PortAudio.

    Returning the bytes and flags together prevents a caller from checking a
    stale overflow/warning value before the post-roll callback has finished.
    The audio itself remains RAM-only.
    """

    audio: CapturedAudio
    overflowed: bool
    backend_warning: bool
    first_frame_latency_ms: float | None
    endpoint_detected: bool


class MicrophoneCapture:
    """Low-overhead push-to-talk capture backed by sounddevice/PortAudio.

    No audio file is created. Raw PCM16 frames stay in RAM until stop/cancel.
    The sounddevice import is lazy so the Foundation can still start and report
    a useful error if voice dependencies are missing.
    """

    def __init__(
        self,
        *,
        device: int | str | None = None,
        sample_rate: int | None = None,
        channels: int = 1,
        max_seconds: float = 20.0,
        startup_timeout_ms: int = 750,
        post_roll_ms: int = 180,
        block_ms: int = 20,
        latency: str | float | None = "low",
        endpoint_speech_rms_dbfs: float = -60.0,
        endpoint_silence_ms: int = 650,
        endpoint_min_speech_ms: int = 120,
        sounddevice_module: Any | None = None,
    ) -> None:
        if channels != 1:
            raise ValueError("First Listen suporta captura mono nesta fase")
        if max_seconds <= 0:
            raise ValueError("max_seconds deve ser positivo")
        if startup_timeout_ms < 0:
            raise ValueError("startup_timeout_ms não pode ser negativo")
        if post_roll_ms < 0:
            raise ValueError("post_roll_ms não pode ser negativo")
        if block_ms < 0:
            raise ValueError("block_ms não pode ser negativo")
        if endpoint_silence_ms < 0 or endpoint_min_speech_ms < 0:
            raise ValueError("parâmetros de endpoint não podem ser negativos")
        self.device = device
        self.requested_sample_rate = sample_rate
        self.channels = channels
        self.max_seconds = float(max_seconds)
        self.startup_timeout_ms = int(startup_timeout_ms)
        self.post_roll_ms = int(post_roll_ms)
        self.block_ms = int(block_ms)
        self.latency = latency
        self.endpoint_speech_rms_dbfs = float(endpoint_speech_rms_dbfs)
        self.endpoint_silence_ms = int(endpoint_silence_ms)
        self.endpoint_min_speech_ms = int(endpoint_min_speech_ms)
        self._sd = sounddevice_module
        self._stream: Any | None = None
        self._sample_rate = 0
        self._buffer = bytearray()
        self._lock = threading.Lock()
        self._state_lock = threading.RLock()
        self._recording = False
        self._overflowed = False
        self._backend_warning = False
        self._first_frame = threading.Event()
        self._endpoint = threading.Event()
        self._started_at: float | None = None
        self._first_frame_at: float | None = None
        self._speech_started_at: float | None = None
        self._last_voiced_at: float | None = None
        # Every stream callback carries this token.  PortAudio may deliver a
        # final callback while an old stream is being aborted, so accepting
        # bytes based only on a shared buffer can contaminate the next turn.
        self._generation = 0

    @staticmethod
    def _load_sounddevice() -> Any:
        try:
            import sounddevice as sd  # type: ignore
        except ImportError as exc:  # pragma: no cover - exercised on field machine
            raise MicrophoneError(
                "Dependência de microfone ausente. Rode a instalação da versão 0.2 novamente."
            ) from exc
        return sd

    @property
    def recording(self) -> bool:
        with self._state_lock:
            return self._recording

    @property
    def overflowed(self) -> bool:
        with self._state_lock:
            return self._overflowed

    @property
    def backend_warning(self) -> bool:
        with self._state_lock:
            return self._backend_warning

    @staticmethod
    def _block_rms_dbfs(raw: bytes) -> float:
        """Compute a small callback-safe level estimate without NumPy allocation."""
        if not raw:
            return float("-inf")
        samples = memoryview(raw).cast("h")
        if not samples:
            return float("-inf")
        mean_square = sum(int(sample) * int(sample) for sample in samples) / len(samples)
        amplitude = math.sqrt(mean_square)
        if amplitude <= 0:
            return float("-inf")
        return 20.0 * math.log10(min(amplitude, 32768.0) / 32768.0)

    def _observe_endpoint(self, raw: bytes, observed_at: float) -> None:
        """Set a best-effort endpoint signal; it never rejects a turn itself.

        The threshold is intentionally used only to end benchmark capture after
        detected speech. Quiet speech simply reaches the maximum guard instead
        of being discarded by a second silence gate.
        """
        level = self._block_rms_dbfs(raw)
        with self._state_lock:
            if level >= self.endpoint_speech_rms_dbfs:
                if self._speech_started_at is None:
                    self._speech_started_at = observed_at
                self._last_voiced_at = observed_at
                return
            if self._speech_started_at is None or self._last_voiced_at is None:
                return
            speech_age_ms = (observed_at - self._speech_started_at) * 1000.0
            silence_ms = (observed_at - self._last_voiced_at) * 1000.0
            if speech_age_ms >= self.endpoint_min_speech_ms and silence_ms >= self.endpoint_silence_ms:
                self._endpoint.set()

    def _module(self) -> Any:
        if self._sd is None:
            self._sd = self._load_sounddevice()
        return self._sd

    def devices(self) -> list[MicrophoneDevice]:
        sd = self._module()
        result: list[MicrophoneDevice] = []
        try:
            devices = sd.query_devices()
        except Exception as exc:  # sounddevice raises backend-specific errors
            raise MicrophoneError(f"Não consegui listar os microfones: {type(exc).__name__}") from exc
        for index, item in enumerate(devices):
            try:
                inputs = int(item.get("max_input_channels", 0))
            except AttributeError:
                inputs = int(item["max_input_channels"])
            if inputs <= 0:
                continue
            try:
                name = str(item.get("name", f"Microfone {index}"))
                rate = int(round(float(item.get("default_samplerate", 48000.0))))
            except AttributeError:
                name = str(item["name"])
                rate = int(round(float(item["default_samplerate"])))
            result.append(MicrophoneDevice(index, name, rate, inputs))
        return result

    def _resolve_sample_rate(self) -> int:
        if self.requested_sample_rate:
            return int(self.requested_sample_rate)
        sd = self._module()
        try:
            info = sd.query_devices(self.device, "input")
            return int(round(float(info["default_samplerate"])))
        except Exception as exc:
            raise MicrophoneError(
                "Não consegui acessar o microfone padrão do Windows. Verifique a permissão de microfone."
            ) from exc

    def start(self) -> None:
        with self._state_lock:
            if self._recording or self._stream is not None:
                raise MicrophoneError("O microfone já está gravando")
            self._generation += 1
            generation = self._generation
        sd = self._module()
        sample_rate = self._resolve_sample_rate()
        max_bytes = int(sample_rate * self.channels * 2 * self.max_seconds)
        self._buffer = bytearray()
        self._overflowed = False
        self._backend_warning = False
        self._first_frame.clear()
        self._endpoint.clear()
        self._started_at = time.monotonic()
        self._first_frame_at = None
        self._speech_started_at = None
        self._last_voiced_at = None

        def callback(indata, frames, time_info, status) -> None:  # noqa: ARG001
            raw = bytes(indata)
            observed_at = time.monotonic()
            # Keep state validation and the buffer update under the same lock
            # ordering used by cancel()/stop_result().  This makes a stale
            # callback harmless even if it arrives after a new turn begins.
            with self._state_lock:
                if generation != self._generation or self._stream is not stream:
                    return
                if status:
                    # PortAudio callback flags (especially input overflow) mean
                    # the waveform may have a gap. Rejecting that turn is safer
                    # than asking Whisper to invent the missing phoneme.
                    self._backend_warning = True
                if self._first_frame_at is None:
                    self._first_frame_at = observed_at
                self._first_frame.set()
                with self._lock:
                    remaining = max_bytes - len(self._buffer)
                    if remaining <= 0:
                        self._overflowed = True
                        self._endpoint.set()
                        return
                    if len(raw) > remaining:
                        self._buffer.extend(raw[:remaining])
                        self._overflowed = True
                        self._endpoint.set()
                    else:
                        self._buffer.extend(raw)
                self._observe_endpoint(raw, observed_at)

        stream = None
        try:
            blocksize = (
                max(1, int(round(sample_rate * self.block_ms / 1000.0)))
                if self.block_ms > 0
                else 0
            )
            stream = sd.RawInputStream(
                samplerate=sample_rate,
                blocksize=blocksize,
                device=self.device,
                channels=self.channels,
                dtype="int16",
                latency=self.latency,
                callback=callback,
            )
            # Do not wait for the first callback on the Qt thread. stop_result()
            # verifies readiness in the worker that already owns end-of-turn work.
            with self._state_lock:
                self._sample_rate = sample_rate
                self._stream = stream
                self._recording = True
            stream.start()
        except Exception as exc:
            with self._state_lock:
                if self._stream is stream:
                    self._stream = None
                    self._recording = False
                    self._generation += 1
            if stream is not None:
                try:
                    stream.abort()
                except Exception:
                    pass
                try:
                    stream.close()
                except Exception:
                    pass
            if isinstance(exc, MicrophoneError):
                raise
            raise MicrophoneError(
                "Não consegui iniciar o microfone. Verifique se outro aplicativo está bloqueando o dispositivo."
            ) from exc

        return None

    def wait_for_endpoint(self, *, timeout_seconds: float | None = None) -> bool:
        """Wait until speech ends or the maximum capture duration is reached.

        This is used by the non-executing benchmark. UI push-to-talk remains
        user-ended, but both paths use this exact capture object and format.
        """
        with self._state_lock:
            if not self._recording:
                raise MicrophoneError("O microfone não está gravando")
        timeout = self.max_seconds if timeout_seconds is None else max(0.0, float(timeout_seconds))
        return self._endpoint.wait(timeout)

    def stop_result(self) -> CaptureResult:
        with self._state_lock:
            if not self._recording or self._stream is None:
                raise MicrophoneError("O microfone não está gravando")
            stream = self._stream
            self._recording = False

        # The stream is still live here. A start on the UI thread returns fast,
        # while the worker finishing the turn waits for actual audio if needed.
        if self.startup_timeout_ms > 0 and not self._first_frame.is_set():
            ready = self._first_frame.wait(self.startup_timeout_ms / 1000.0)
            if not ready:
                with self._state_lock:
                    if self._stream is stream:
                        self._stream = None
                        self._generation += 1
                    with self._lock:
                        self._buffer.clear()
                try:
                    stream.abort()
                finally:
                    stream.close()
                raise MicrophoneError(
                    "O microfone abriu, mas não entregou áudio a tempo. Tente novamente ou selecione outro dispositivo."
                )

        # Keep the native stream alive for a tiny tail after button release.
        # This runs in the voice worker thread, so it does not freeze the UI,
        # and helps preserve final phonemes when humans release the button a
        # little too enthusiastically.
        if self.post_roll_ms > 0:
            time.sleep(self.post_roll_ms / 1000.0)
        stop_error: Exception | None = None
        try:
            stream.stop()
        except Exception as exc:
            stop_error = exc
        try:
            stream.close()
        except Exception as exc:
            if stop_error is None:
                stop_error = exc
        with self._state_lock:
            if self._stream is stream:
                self._stream = None
                self._generation += 1
            # The callback takes state_lock before the buffer lock, so
            # invalidating the generation before this snapshot excludes a
            # late callback from either this result or the next turn.
            with self._lock:
                payload = bytes(self._buffer)
                self._buffer.clear()
            first_frame_latency_ms = None
            if self._started_at is not None and self._first_frame_at is not None:
                first_frame_latency_ms = (self._first_frame_at - self._started_at) * 1000.0
            result = CaptureResult(
                audio=CapturedAudio(payload, self._sample_rate, self.channels),
                overflowed=self._overflowed,
                backend_warning=self._backend_warning,
                first_frame_latency_ms=first_frame_latency_ms,
                endpoint_detected=self._endpoint.is_set(),
            )
        if stop_error is not None:
            raise MicrophoneError(
                "O microfone falhou ao encerrar a captura; tente novamente."
            ) from stop_error
        return result

    def stop(self) -> CapturedAudio:
        """Compatibility helper for callers that only need the audio bytes."""
        return self.stop_result().audio

    def cancel(self) -> None:
        with self._state_lock:
            stream = self._stream
            self._stream = None
            self._recording = False
            self._generation += 1
            # Wake a benchmark thread blocked in wait_for_endpoint(). A
            # cancelled turn cannot be mistaken for an accepted endpoint:
            # SpeechPipeline's cancellation token rejects it before STT/Core.
            self._endpoint.set()
            # The callback uses state_lock before this lock, so a callback
            # admitted before cancellation is cleared before cancel returns.
            with self._lock:
                self._buffer.clear()
        if stream is not None:
            try:
                stream.abort()
            except Exception:
                pass
            try:
                stream.close()
            except Exception:
                pass
