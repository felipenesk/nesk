from __future__ import annotations

"""Shared pre-Core speech pipeline for every First Listen consumer.

This module deliberately stops before intent routing. UI can send a verified
transcript to ``VoiceController``; probes and benchmarks can use exactly the
same capture, preparation, STT and quality policy without ever executing a
command.
"""

from dataclasses import dataclass
from pathlib import Path
from threading import RLock
from typing import Any, Callable

from nesk.voice.audio import CapturedAudio
from nesk.voice.capture import CaptureResult, MicrophoneCapture, MicrophoneError
from nesk.voice.contracts import SpeechToTextProvider
from nesk.voice.stt import STTDiagnostics, SpeechToTextError, create_stt_provider


@dataclass(frozen=True, slots=True)
class SpeechTurnOutcome:
    """Non-persistent result of one capture and transcription attempt."""

    accepted: bool
    transcript: str = ""
    reason_code: str = ""
    reason: str = ""
    capture: CaptureResult | None = None
    diagnostics: STTDiagnostics | None = None


class SpeechPipeline:
    """One canonical capture -> STT -> quality boundary for First Listen.

    ``SpeechPipeline`` owns no Core reference and never interprets text. That
    separation lets diagnostics remain safe and means voice is still only an
    adapter into the existing NESK Core rather than a second brain.
    """

    def __init__(
        self,
        *,
        capture: MicrophoneCapture,
        stt: SpeechToTextProvider,
        min_seconds: float = 0.12,
    ) -> None:
        if min_seconds < 0:
            raise ValueError("min_seconds não pode ser negativo")
        self.capture = capture
        self.stt = stt
        self.min_seconds = float(min_seconds)
        self._lock = RLock()
        self._closed = False
        self._active_turns = 0
        self._provider_closed = False
        self._cancel_generation = 0

    @classmethod
    def from_config(cls, config: dict[str, Any], *, data_root: Path) -> "SpeechPipeline":
        voice = config.get("voice", {})
        capture_cfg = voice.get("capture", {})
        capture = MicrophoneCapture(
            device=capture_cfg.get("device"),
            sample_rate=capture_cfg.get("sample_rate"),
            max_seconds=float(capture_cfg.get("max_seconds", 12.0)),
            startup_timeout_ms=int(capture_cfg.get("startup_timeout_ms", 750)),
            post_roll_ms=int(capture_cfg.get("post_roll_ms", 180)),
            block_ms=int(capture_cfg.get("block_ms", 20)),
            latency=capture_cfg.get("latency", "low"),
            endpoint_speech_rms_dbfs=float(capture_cfg.get("endpoint_speech_rms_dbfs", -60.0)),
            endpoint_silence_ms=int(capture_cfg.get("endpoint_silence_ms", 650)),
            endpoint_min_speech_ms=int(capture_cfg.get("endpoint_min_speech_ms", 120)),
        )
        return cls(
            capture=capture,
            stt=create_stt_provider(config, data_root=data_root),
            min_seconds=float(capture_cfg.get("min_seconds", 0.12)),
        )

    @property
    def recording(self) -> bool:
        return bool(getattr(self.capture, "recording", False))

    def start_capture(self) -> None:
        with self._lock:
            if self._closed:
                raise MicrophoneError("Entrada de voz já foi encerrada")
            self.capture.start()

    def wait_for_endpoint(self, *, timeout_seconds: float | None = None) -> bool:
        with self._lock:
            if self._closed:
                raise MicrophoneError("Entrada de voz já foi encerrada")
        waiter = getattr(self.capture, "wait_for_endpoint", None)
        if not callable(waiter):
            raise MicrophoneError("A captura configurada não oferece endpointing")
        return bool(waiter(timeout_seconds=timeout_seconds))

    def _stop_capture(self) -> CaptureResult:
        """Read health flags only after capture has fully stopped.

        Test doubles from prior releases may only implement ``stop``. Keeping
        that compatibility still fixes the old race because flags are read
        after the call rather than before it.
        """
        stop_result = getattr(self.capture, "stop_result", None)
        if callable(stop_result):
            return stop_result()
        audio: CapturedAudio = self.capture.stop()
        return CaptureResult(
            audio=audio,
            overflowed=bool(getattr(self.capture, "overflowed", False)),
            backend_warning=bool(getattr(self.capture, "backend_warning", False)),
            first_frame_latency_ms=None,
            endpoint_detected=False,
        )

    def _reject(
        self,
        capture: CaptureResult | None,
        code: str,
        reason: str,
        *,
        diagnostics: STTDiagnostics | None = None,
    ) -> SpeechTurnOutcome:
        return SpeechTurnOutcome(
            accepted=False,
            reason_code=code,
            reason=reason,
            capture=capture,
            diagnostics=diagnostics,
        )

    def _input_rejection(self, capture: CaptureResult) -> SpeechTurnOutcome | None:
        """Reject only capture facts, never an arbitrary speech-level guess."""
        audio = capture.audio
        if capture.overflowed:
            return self._reject(capture, "capture_truncated", "a captura atingiu o limite de duração")
        if capture.backend_warning:
            return self._reject(
                capture,
                "capture_backend_warning",
                "o driver do microfone perdeu um bloco de áudio; tente novamente",
            )
        if audio.empty:
            return self._reject(capture, "empty_audio", "nenhum áudio foi capturado")
        if audio.duration_seconds < self.min_seconds:
            return self._reject(capture, "too_short", "fala curta demais")
        # An exact all-zero buffer is a dead input, not a quiet speaker. Any
        # non-zero recording proceeds to the single decoder/VAD quality policy,
        # avoiding a second arbitrary full-window RMS/peak classifier.
        if audio.peak_dbfs == float("-inf"):
            return self._reject(capture, "no_signal", "nenhum sinal de fala foi detectado")
        return None

    def process_capture(
        self,
        capture: CaptureResult,
        *,
        pre_transcription_check: Callable[[CapturedAudio], str | None] | None = None,
    ) -> SpeechTurnOutcome:
        """Apply the one shared input policy without touching the NESK Core."""
        rejected = self._input_rejection(capture)
        if rejected is not None:
            return rejected
        audio = capture.audio
        if pre_transcription_check is not None:
            try:
                reason = pre_transcription_check(audio)
            except Exception:
                return self._reject(
                    capture,
                    "pre_transcription_check_failed",
                    "a verificação de entrada de voz falhou; tente novamente",
                )
            if reason:
                return self._reject(capture, "speaker_rejected", reason)

        try:
            transcript = self.stt.transcribe(audio).strip()
        except SpeechToTextError:
            return self._reject(capture, "stt_failure", "o reconhecimento local falhou; tente novamente")
        except Exception:
            return self._reject(capture, "stt_failure", "o reconhecimento local falhou; tente novamente")

        diagnostics = getattr(self.stt, "last_diagnostics", None)
        if transcript:
            return SpeechTurnOutcome(
                accepted=True,
                transcript=transcript,
                capture=capture,
                diagnostics=diagnostics,
            )

        reason_code = str(getattr(diagnostics, "rejection_reason", "") or "no_transcript")
        reason = {
            "low_confidence": "não entendi com confiança suficiente; tente de novo",
            "likely_silence": "nenhuma fala reconhecida",
            "repetitive_decode": "o reconhecimento retornou um resultado inconsistente; tente de novo",
        }.get(reason_code, "nenhuma fala reconhecida")
        return self._reject(capture, reason_code, reason, diagnostics=diagnostics)

    def _turn_was_cancelled(self, generation: int) -> bool:
        with self._lock:
            return self._closed or generation != self._cancel_generation

    def finish_capture(
        self,
        *,
        pre_transcription_check: Callable[[CapturedAudio], str | None] | None = None,
    ) -> SpeechTurnOutcome:
        with self._lock:
            if self._closed:
                return self._reject(None, "pipeline_closed", "entrada de voz encerrada")
            # The service serializes user turns. Mark an active turn before
            # releasing the lock so close() can defer native model teardown
            # rather than freezing the Qt thread behind a long inference.
            self._active_turns += 1
            cancellation_generation = self._cancel_generation
        try:
            try:
                capture = self._stop_capture()
            except MicrophoneError:
                if self._turn_was_cancelled(cancellation_generation):
                    return self._reject(None, "turn_cancelled", "entrada de voz cancelada")
                raise
            if self._turn_was_cancelled(cancellation_generation):
                return self._reject(capture, "turn_cancelled", "entrada de voz cancelada")
            outcome = self.process_capture(capture, pre_transcription_check=pre_transcription_check)
            if self._turn_was_cancelled(cancellation_generation):
                return self._reject(capture, "turn_cancelled", "entrada de voz cancelada")
            return outcome
        finally:
            close_provider = False
            with self._lock:
                self._active_turns -= 1
                close_provider = self._closed and self._active_turns == 0 and not self._provider_closed
            if close_provider:
                self._close_provider()

    def capture_until_endpoint(self, *, timeout_seconds: float | None = None) -> SpeechTurnOutcome:
        """Capture one benchmark turn until detected endpoint or safety timeout."""
        self.start_capture()
        try:
            self.wait_for_endpoint(timeout_seconds=timeout_seconds)
            return self.finish_capture()
        except Exception:
            self.cancel()
            raise

    def cancel(self) -> None:
        with self._lock:
            self._cancel_generation += 1
        self.capture.cancel()

    def _close_provider(self) -> None:
        with self._lock:
            if self._provider_closed:
                return
            self._provider_closed = True
        close = getattr(self.stt, "close", None)
        if callable(close):
            try:
                close()
            except Exception:
                # Closing native model resources is best-effort only.
                pass

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
            self._cancel_generation += 1
            active = self._active_turns
        self.capture.cancel()
        if active == 0:
            self._close_provider()


__all__ = ["SpeechPipeline", "SpeechTurnOutcome"]
