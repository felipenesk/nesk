from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class VoiceState(str, Enum):
    DISABLED = "disabled"
    IDLE = "idle"
    LISTENING = "listening"
    TRANSCRIBING = "transcribing"
    PROCESSING = "processing"
    SPEAKING = "speaking"
    ERROR = "error"


_ALLOWED: dict[VoiceState, set[VoiceState]] = {
    VoiceState.DISABLED: {VoiceState.IDLE},
    VoiceState.IDLE: {VoiceState.DISABLED, VoiceState.LISTENING, VoiceState.ERROR},
    VoiceState.LISTENING: {VoiceState.IDLE, VoiceState.TRANSCRIBING, VoiceState.ERROR},
    VoiceState.TRANSCRIBING: {VoiceState.IDLE, VoiceState.PROCESSING, VoiceState.ERROR},
    VoiceState.PROCESSING: {VoiceState.IDLE, VoiceState.SPEAKING, VoiceState.ERROR},
    VoiceState.SPEAKING: {VoiceState.IDLE, VoiceState.LISTENING, VoiceState.ERROR},
    VoiceState.ERROR: {VoiceState.IDLE, VoiceState.DISABLED},
}


@dataclass(slots=True)
class VoiceSession:
    """Small deterministic state machine used by the voice controller.

    Keeping state transitions explicit now prevents microphone/STT/TTS callbacks
    from turning into ad-hoc flags once Voice lands.
    """

    state: VoiceState = VoiceState.DISABLED

    def transition(self, target: VoiceState) -> None:
        if target == self.state:
            return
        if target not in _ALLOWED[self.state]:
            raise ValueError(f"Transição de voz inválida: {self.state.value} -> {target.value}")
        self.state = target

    @property
    def active(self) -> bool:
        return self.state not in {VoiceState.DISABLED, VoiceState.ERROR}
