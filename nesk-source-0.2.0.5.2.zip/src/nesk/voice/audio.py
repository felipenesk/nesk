from __future__ import annotations

import math
import sys
from array import array
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CapturedAudio:
    """One in-memory PCM16 capture.

    Audio is deliberately represented as bytes plus format metadata so the Core
    and storage layers never need to know about a particular microphone/STT
    library. First Listen does not persist this object to disk.
    """

    pcm16: bytes
    sample_rate: int
    channels: int = 1

    def __post_init__(self) -> None:
        if self.sample_rate <= 0:
            raise ValueError("sample_rate deve ser positivo")
        if self.channels <= 0:
            raise ValueError("channels deve ser positivo")
        if len(self.pcm16) % 2:
            raise ValueError("PCM16 precisa ter quantidade par de bytes")

    @property
    def frames(self) -> int:
        return len(self.pcm16) // (2 * self.channels)

    @property
    def duration_seconds(self) -> float:
        return self.frames / float(self.sample_rate)

    @property
    def empty(self) -> bool:
        return not self.pcm16

    def _samples(self) -> array:
        samples = array("h")
        samples.frombytes(self.pcm16)
        # Captured PCM from PortAudio is little-endian. Keep the helper correct
        # on non-Windows developer/test hosts too.
        if sys.byteorder != "little":
            samples.byteswap()
        return samples

    @staticmethod
    def _to_dbfs(amplitude: float) -> float:
        if amplitude <= 0:
            return float("-inf")
        return 20.0 * math.log10(min(amplitude, 32768.0) / 32768.0)

    @property
    def rms_dbfs(self) -> float:
        """Return RMS level in dBFS without persisting or copying audio to disk."""
        if self.empty:
            return float("-inf")
        samples = self._samples()
        if not samples:
            return float("-inf")
        mean_square = sum(int(sample) * int(sample) for sample in samples) / len(samples)
        return self._to_dbfs(math.sqrt(mean_square))

    @property
    def peak_dbfs(self) -> float:
        if self.empty:
            return float("-inf")
        samples = self._samples()
        if not samples:
            return float("-inf")
        peak = max(abs(int(sample)) for sample in samples)
        return self._to_dbfs(float(peak))

    def is_effectively_silent(
        self,
        *,
        rms_threshold_dbfs: float = -55.0,
        peak_threshold_dbfs: float = -40.0,
    ) -> bool:
        """Conservative pre-STT silence gate for accidental taps / dead input.

        Both RMS and peak must be below threshold. This deliberately avoids a
        single aggressive level threshold that could reject a quiet user.
        """
        return self.rms_dbfs < rms_threshold_dbfs and self.peak_dbfs < peak_threshold_dbfs
