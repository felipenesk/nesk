from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from threading import Event, RLock

from nesk.core.assistant import NeskCore
from nesk.voice.capture import MicrophoneCapture, MicrophoneError
from nesk.voice.controller import VoiceController, VoiceTurnResult
from nesk.voice.pipeline import SpeechPipeline
from nesk.voice.stt import SpeechToTextError


@dataclass(frozen=True, slots=True)
class VoiceStatus:
    enabled: bool
    mode: str
    stt_provider: str
    local_model: str


class VoiceService:
    """UI-facing adapter from the shared speech pipeline into NESK Core."""

    def __init__(
        self,
        *,
        core: NeskCore,
        config: dict,
        data_root: Path,
        capture: MicrophoneCapture | None = None,
        controller: VoiceController | None = None,
        pipeline: SpeechPipeline | None = None,
    ) -> None:
        voice = config.get("voice", {})
        self.enabled = bool(voice.get("enabled", True))
        self._lock = RLock()
        self._closed = False
        self._in_flight = False
        self._turn_generation = 0
        # Set before cancel/close waits on the service lock.  This gives the
        # final Core handoff a non-blocking cancellation signal without
        # changing capture, VAD or STT ownership.
        self._turn_cancel = Event()

        if pipeline is None:
            if capture is None and controller is None:
                pipeline = SpeechPipeline.from_config(config, data_root=data_root)
            else:
                # Compatibility injection seam used by deterministic tests. It
                # still creates the same pre-Core boundary rather than letting
                # VoiceService duplicate gates or STT work.
                if capture is None:
                    capture = SpeechPipeline.from_config(config, data_root=data_root).capture
                if controller is None or controller.stt is None:
                    raise ValueError("capture/controller injetados exigem um STT para o pipeline")
                capture_cfg = voice.get("capture", {})
                pipeline = SpeechPipeline(
                    capture=capture,
                    stt=controller.stt,
                    min_seconds=float(capture_cfg.get("min_seconds", 0.12)),
                )
        self.pipeline = pipeline
        self.capture = pipeline.capture  # stable read-only compatibility attribute
        self.controller = controller or VoiceController(core=core)
        # The shared pipeline is the sole owner of the provider in the UI
        # runtime.  Direct legacy VoiceController users retain owns_stt=True.
        if self.controller.stt is self.pipeline.stt:
            self.controller.owns_stt = False

        stt_cfg = voice.get("stt", {})
        self.status = VoiceStatus(
            enabled=self.enabled,
            mode=str(voice.get("mode", "push_to_talk")),
            stt_provider=str(stt_cfg.get("provider", "local")),
            local_model=str(stt_cfg.get("local_model", "small")),
        )

    @property
    def recording(self) -> bool:
        return self.pipeline.recording

    def start_listening(self) -> None:
        with self._lock:
            if self._closed:
                raise MicrophoneError("Entrada de voz já foi encerrada")
            if not self.enabled:
                raise MicrophoneError("Entrada de voz está desativada na configuração")
            if self._in_flight:
                raise MicrophoneError("Entrada de voz ocupada")
            self.controller.begin_listening()
            try:
                self.pipeline.start_capture()
            except Exception:
                self.controller.cancel_listening()
                raise
            self._turn_generation += 1
            self._turn_cancel = Event()

    def finish_turn(self) -> VoiceTurnResult:
        # Never hold the service lock through capture or STT.  The final,
        # short Core handoff is deliberately linearized under the lock so a
        # cancel/close cannot slip between validation and command routing.
        with self._lock:
            if self._closed:
                return VoiceTurnResult(False, reason="entrada de voz encerrada")
            if self._in_flight:
                return VoiceTurnResult(False, reason="entrada de voz ocupada")
            self._in_flight = True
            turn_generation = self._turn_generation
            turn_cancel = self._turn_cancel

        try:
            outcome = self.pipeline.finish_capture(
                pre_transcription_check=self.controller.pre_transcription_rejection,
            )
            with self._lock:
                if self._closed:
                    self.controller.cancel_listening()
                    return VoiceTurnResult(False, reason="entrada de voz encerrada")
                if turn_generation != self._turn_generation:
                    self.controller.cancel_listening()
                    return VoiceTurnResult(False, reason="entrada de voz cancelada")
                if turn_cancel.is_set():
                    self.controller.cancel_listening()
                    return VoiceTurnResult(False, reason="entrada de voz cancelada")
                if not outcome.accepted:
                    self.controller.cancel_listening()
                    return VoiceTurnResult(False, reason=outcome.reason)

                # A cancellation that arrives during STT increments the turn
                # generation above and is rejected here.  Holding this small
                # dispatch section makes the check and handoff to Core one
                # linearized operation: cancel cannot slip between them.
                diagnostics = outcome.diagnostics
                result = self.controller.process_transcript(
                    outcome.transcript,
                    audio_seconds=getattr(
                        diagnostics,
                        "audio_seconds",
                        outcome.capture.audio.duration_seconds if outcome.capture else None,
                    ),
                    stt_seconds=getattr(diagnostics, "inference_seconds", None),
                    realtime_factor=getattr(diagnostics, "realtime_factor", None),
                )
                # cancel()/close() set this Event before waiting on _lock, so
                # a bounded semantic request cannot surface a stale response
                # after the voice turn was invalidated.
                if turn_cancel.is_set():
                    self.controller.cancel_listening()
                    return VoiceTurnResult(False, reason="entrada de voz cancelada")
                return result
        except Exception:
            self.controller.cancel_listening()
            raise
        finally:
            close_now = False
            with self._lock:
                self._in_flight = False
                close_now = self._closed
            if close_now:
                self.controller.close()

    def cancel(self) -> None:
        self._turn_cancel.set()
        # Semantic interpretation happens after the shared speech pipeline has
        # already finished.  Invalidate it before waiting on this service lock
        # so cancellation remains responsive without changing capture/STT.
        self.controller.core.cancel_inflight_semantic()
        with self._lock:
            self._turn_generation += 1
        self.pipeline.cancel()
        self.controller.cancel_listening()

    def close(self) -> None:
        """Idempotent; non-blocking during capture/STT and safe at Core handoff."""
        self._turn_cancel.set()
        self.controller.core.cancel_inflight_semantic()
        with self._lock:
            if self._closed:
                return
            self._closed = True
            self._turn_generation += 1
            in_flight = self._in_flight
        self.pipeline.close()
        self.controller.cancel_listening()
        if not in_flight:
            self.controller.close()


__all__ = ["VoiceService", "VoiceStatus", "MicrophoneError", "SpeechToTextError"]
