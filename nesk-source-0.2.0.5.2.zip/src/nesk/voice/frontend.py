from __future__ import annotations

"""Canonical, intentionally small audio preparation for local STT.

Endpointing happens at capture time and faster-whisper owns the one VAD pass.
This module therefore only performs format conversion that the decoder requires:
PCM16 -> mono float32 -> 16 kHz, plus conservative DC-offset removal. It does
not energy-trim or normalize a user's speech.
"""

from dataclasses import dataclass

from nesk.voice.audio import CapturedAudio


class AudioFrontendError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class PreparedSpeech:
    waveform: object
    input_seconds: float
    output_seconds: float
    gain_db: float = 0.0
    trimmed: bool = False
    noise_floor_dbfs: float | None = None
    speech_threshold_dbfs: float | None = None


def _pcm16_to_float32(audio: CapturedAudio, *, target_rate: int):
    try:
        import numpy as np
    except ImportError as exc:  # pragma: no cover - field dependency failure
        raise AudioFrontendError("NumPy não está instalado para o módulo de voz") from exc

    samples = np.frombuffer(audio.pcm16, dtype=np.int16)
    if audio.channels > 1:
        usable = samples[: (samples.size // audio.channels) * audio.channels]
        samples = usable.reshape(-1, audio.channels).mean(axis=1)
    waveform = samples.astype(np.float32) / np.float32(32768.0)
    if waveform.size == 0:
        return waveform

    # DC removal is signal hygiene, not a speech heuristic. Avoid altering tiny
    # capture fragments where an estimated mean is inherently unhelpful.
    if waveform.size >= max(16, audio.sample_rate // 100):
        offset = float(waveform.mean(dtype=np.float64))
        if abs(offset) >= 1e-4:
            waveform = waveform - np.float32(offset)

    if audio.sample_rate == target_rate:
        return waveform.astype(np.float32, copy=False)

    # NumPy interpolation is deterministic, fast on the target CPU and keeps
    # the project dependency set small. The actual input rate is retained by
    # CaptureResult; no code assumes that a 16 kHz request was honored.
    output_size = max(1, int(round(waveform.size * target_rate / audio.sample_rate)))
    source_positions = np.arange(waveform.size, dtype=np.float64)
    target_positions = np.linspace(0, waveform.size - 1, num=output_size, dtype=np.float64)
    return np.interp(target_positions, source_positions, waveform).astype(np.float32)


def prepare_speech(
    audio: CapturedAudio,
    *,
    target_rate: int = 16000,
    # Kept as no-op compatibility arguments for diagnostic callers from the
    # previous hotfix. Signal trimming/gain are intentionally gone.
    trim_enabled: bool | None = None,
    normalize_enabled: bool | None = None,
    **_legacy: object,
) -> PreparedSpeech:
    if target_rate <= 0:
        raise ValueError("target_rate deve ser positivo")
    waveform = _pcm16_to_float32(audio, target_rate=target_rate)
    return PreparedSpeech(
        waveform=waveform,
        input_seconds=audio.duration_seconds,
        output_seconds=(waveform.size / float(target_rate)) if waveform.size else 0.0,
    )


__all__ = ["AudioFrontendError", "PreparedSpeech", "prepare_speech"]
