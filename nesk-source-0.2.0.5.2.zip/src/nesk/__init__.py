"""NESK package."""

from nesk.version import __version__

__all__ = ["__version__"]
