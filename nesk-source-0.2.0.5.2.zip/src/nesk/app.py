from __future__ import annotations

import argparse
import sys


def _self_check() -> int:
    """Headless sanity check used by release engineering and bundled EXEs."""
    from nesk.core.bootstrap import bootstrap

    runtime = None
    try:
        # Validate import-time native voice dependencies without opening a
        # microphone or downloading/loading a model. This catches an
        # incomplete frozen bundle while keeping self-check deterministic.
        import ctranslate2  # noqa: F401
        import faster_whisper  # noqa: F401
        import sounddevice  # noqa: F401
        runtime = bootstrap()
        if not runtime.tools.names():
            return 10
        if not runtime.core.store.integrity_check():
            return 11
        if runtime.core.store.schema_version() < 1:
            return 12
        return 0
    except Exception:
        return 13
    finally:
        if runtime is not None:
            runtime.shutdown()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--self-check", action="store_true")
    args, _unknown = parser.parse_known_args(argv if argv is not None else sys.argv[1:])
    if args.self_check:
        return _self_check()

    try:
        from PySide6.QtWidgets import QApplication, QMessageBox
    except ImportError:
        print("PySide6 não está instalado. Rode: pip install -e .")
        return 2

    from nesk.core.bootstrap import bootstrap
    from nesk.ui.main_window import MainWindow

    app = QApplication(sys.argv)
    app.setApplicationName("NESK")
    app.setQuitOnLastWindowClosed(False)

    runtime = None
    try:
        runtime = bootstrap()
    except Exception as exc:
        QMessageBox.critical(None, "NESK — erro de inicialização", str(exc))
        return 1

    window = MainWindow(runtime.core, runtime.config, runtime.voice)

    def shutdown() -> None:
        window.shutdown()
        runtime.shutdown()

    app.aboutToQuit.connect(shutdown)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
