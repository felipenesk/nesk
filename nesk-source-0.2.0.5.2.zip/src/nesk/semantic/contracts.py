from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from threading import Event
from typing import Mapping, Protocol


class SemanticSource(str, Enum):
    """Origin of a structured semantic candidate.

    The value is metadata only.  It grants no execution authority; the Core
    independently validates the candidate and always routes the final Intent
    through the ToolRegistry.
    """

    LOCAL = "semantic_local"
    PROVIDER = "semantic_provider"


@dataclass(frozen=True, slots=True)
class SemanticContextView:
    """Small, typed view that may be supplied to an optional remote provider.

    This view never contains messages, SQLite history, memories, filesystem
    paths, credentials, logs or audio.  Empty fields are omitted by
    :meth:`provider_payload`, so callers can minimize it further per request.
    """

    last_program: str | None = None
    active_topic: str | None = None
    last_search_engine: str | None = None

    def provider_payload(self) -> dict[str, str]:
        return {
            key: value
            for key, value in {
                "last_program": self.last_program,
                "active_topic": self.active_topic,
                "last_search_engine": self.last_search_engine,
            }.items()
            if value
        }


@dataclass(frozen=True, slots=True)
class SemanticRequest:
    """Non-executable request sent to a semantic provider.

    ``allowed_*`` are descriptive constraints, not tool objects.  A provider
    therefore cannot obtain a registry, callable, shell, URL or path through
    this contract.
    """

    text: str
    context: SemanticContextView = field(default_factory=SemanticContextView)
    allowed_actions: tuple[str, ...] = ()
    allowed_programs: tuple[str, ...] = ()
    allowed_sites: tuple[str, ...] = ()
    allowed_search_engines: tuple[str, ...] = ()
    locale: str = "pt-BR"

    def provider_payload(self) -> dict[str, object]:
        return {
            "text": self.text,
            "locale": self.locale,
            "allowed_actions": list(self.allowed_actions),
            "allowed_targets": {
                "programs": list(self.allowed_programs),
                "sites": list(self.allowed_sites),
                "search_engines": list(self.allowed_search_engines),
            },
            "context": self.context.provider_payload(),
        }


@dataclass(frozen=True, slots=True)
class SemanticCandidate:
    """A compact, non-executable interpretation proposed by a resolver.

    ``target`` is intentionally a scalar.  It prevents an external provider
    from smuggling arbitrary argument dictionaries toward a Tool.  The Core
    maps it to the narrow argument shape allowed for each action.
    """

    action: str | None
    target: str | None = None
    confidence: float = 0.0
    source: SemanticSource = SemanticSource.PROVIDER
    entities: Mapping[str, str] = field(default_factory=dict)
    options: tuple[str, ...] = ()
    clarification_required: bool = False

    def __post_init__(self) -> None:
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence deve estar entre 0.0 e 1.0")
        if self.action is not None and not isinstance(self.action, str):
            raise TypeError("action deve ser texto ou None")
        if self.target is not None and not isinstance(self.target, str):
            raise TypeError("target deve ser texto ou None")
        if not all(isinstance(key, str) and isinstance(value, str) for key, value in self.entities.items()):
            raise TypeError("entities deve conter somente pares texto/texto")
        if not all(isinstance(value, str) for value in self.options):
            raise TypeError("options deve conter somente texto")


class SemanticProvider(Protocol):
    """Substitutable, structured semantic provider.

    Implementations must honor ``cancel`` when their client allows it.  The
    Core also has a deadline and ignores late results, so a provider never gets
    a path from interpretation to execution by itself.
    """

    def interpret(self, request: SemanticRequest, *, cancel: Event) -> SemanticCandidate | None:
        ...

    def close(self) -> None:
        ...
