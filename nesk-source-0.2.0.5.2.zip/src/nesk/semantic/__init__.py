"""Structured, privacy-minimized semantic interpretation boundaries.

The package deliberately contains no tool execution code.  Every candidate it
produces is validated by the Core before it can become an ``Intent``.
"""

from nesk.semantic.contracts import (
    SemanticCandidate,
    SemanticContextView,
    SemanticProvider,
    SemanticRequest,
    SemanticSource,
)

__all__ = [
    "SemanticCandidate",
    "SemanticContextView",
    "SemanticProvider",
    "SemanticRequest",
    "SemanticSource",
]
