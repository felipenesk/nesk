from __future__ import annotations

import json
import os
from threading import Event
from typing import Any

from nesk.semantic.contracts import SemanticCandidate, SemanticProvider, SemanticRequest, SemanticSource


class NullSemanticProvider:
    """Offline default.  It is cheap and intentionally cannot make requests."""

    def interpret(self, request: SemanticRequest, *, cancel: Event) -> SemanticCandidate | None:
        return None

    def close(self) -> None:
        return None


class OpenAISemanticProvider:
    """Optional strict-JSON semantic adapter for the OpenAI Responses API.

    This class is deliberately separate from ``OpenAIProvider``: it receives a
    tiny structured request, never a conversation transcript, and returns a
    candidate rather than a natural-language answer or a callable tool.
    """

    _ALLOWED_KEYS = {
        "action",
        "target",
        "confidence",
        "entities",
        "options",
        "clarification_required",
    }
    _ALLOWED_ENTITY_KEYS = {"engine", "program", "site"}

    def __init__(self, *, model: str, timeout_seconds: float) -> None:
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError('Provider semântico OpenAI não instalado. Rode: pip install -e ".[openai]"') from exc
        if not os.getenv("OPENAI_API_KEY"):
            raise RuntimeError("OPENAI_API_KEY não configurada.")
        self.model = model
        self.client = OpenAI(timeout=max(0.1, float(timeout_seconds)), max_retries=0)

    @classmethod
    def parse_candidate(cls, payload: str) -> SemanticCandidate | None:
        """Parse a provider response as a closed schema, failing safely."""

        try:
            data: Any = json.loads(payload)
        except (TypeError, json.JSONDecodeError):
            return None
        if not isinstance(data, dict) or set(data) - cls._ALLOWED_KEYS:
            return None
        required = {"action", "target", "confidence", "clarification_required"}
        if not required <= set(data):
            return None
        action = data["action"]
        target = data["target"]
        confidence = data["confidence"]
        clarification = data["clarification_required"]
        entities = data.get("entities", {})
        options = data.get("options", [])
        if action is not None and (not isinstance(action, str) or len(action) > 80):
            return None
        if target is not None and (not isinstance(target, str) or not target.strip() or len(target) > 500):
            return None
        if isinstance(confidence, bool) or not isinstance(confidence, (int, float)):
            return None
        if not isinstance(clarification, bool):
            return None
        if not isinstance(entities, dict) or set(entities) - cls._ALLOWED_ENTITY_KEYS:
            return None
        if not all(isinstance(key, str) and isinstance(value, str) and len(value) <= 100 for key, value in entities.items()):
            return None
        if not isinstance(options, list) or len(options) > 4:
            return None
        if not all(isinstance(value, str) and value.strip() and len(value) <= 100 for value in options):
            return None
        try:
            return SemanticCandidate(
                action=action,
                target=target.strip() if isinstance(target, str) else None,
                confidence=float(confidence),
                source=SemanticSource.PROVIDER,
                entities=entities,
                options=tuple(value.strip() for value in options),
                clarification_required=clarification,
            )
        except (TypeError, ValueError):
            return None

    def interpret(self, request: SemanticRequest, *, cancel: Event) -> SemanticCandidate | None:
        if cancel.is_set():
            return None
        instructions = (
            "Você classifica uma única solicitação curta em português brasileiro. "
            "Nunca execute nada, nunca proponha shell, URL, caminho ou ferramenta fora da lista. "
            "Responda somente JSON estrito com action, target, confidence, entities, options e "
            "clarification_required. action precisa estar em allowed_actions ou null. "
            "target deve ser um alvo da lista permitida, uma consulta curta ou null. "
            "Se houver negação, pergunta explicativa, hipótese ou dúvida, use clarification_required "
            "ou action null; não invente uma ação."
        )
        response = self.client.responses.create(
            model=self.model,
            instructions=instructions,
            input=json.dumps(request.provider_payload(), ensure_ascii=False, separators=(",", ":")),
        )
        if cancel.is_set():
            return None
        return self.parse_candidate((response.output_text or "").strip())

    def close(self) -> None:
        close = getattr(self.client, "close", None)
        if callable(close):
            close()


__all__ = ["NullSemanticProvider", "OpenAISemanticProvider", "SemanticProvider"]
