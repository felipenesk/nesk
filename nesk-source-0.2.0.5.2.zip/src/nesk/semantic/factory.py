from __future__ import annotations

import logging
from typing import Any

from nesk.semantic.contracts import SemanticProvider
from nesk.semantic.provider import NullSemanticProvider, OpenAISemanticProvider


def create_semantic_provider(config: dict[str, Any]) -> SemanticProvider:
    """Create an opt-in semantic provider without making cloud a dependency."""

    name = str(config.get("provider", "none")).strip().lower()
    # A hand-edited JSON string such as "false" must not opt a user into a
    # remote semantic provider.  Remote interpretation is opt-in only for the
    # boolean literal ``true``.
    allow_remote = config.get("allow_remote", False) is True
    if name in {"", "none", "local", "disabled"} or not allow_remote:
        return NullSemanticProvider()
    if name == "openai":
        try:
            return OpenAISemanticProvider(
                model=str(config.get("model", "gpt-5.6")),
                timeout_seconds=float(config.get("timeout_seconds", 4.0)),
            )
        except Exception as exc:
            logging.getLogger("nesk").warning("semantic_provider_init_fallback type=%s", type(exc).__name__)
            return NullSemanticProvider()
    logging.getLogger("nesk").warning("semantic_provider_unknown name=%s", name)
    return NullSemanticProvider()


__all__ = ["create_semantic_provider"]
