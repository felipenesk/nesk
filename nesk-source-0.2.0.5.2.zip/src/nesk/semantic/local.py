from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum

from nesk.nlu.lexicon import BROWSER_ALIASES, CLOSE_VERBS, OPEN_VERBS, SEARCH_VERBS, SITE_LOOKUP
from nesk.nlu.ptbr import (
    cleanup_command_target,
    extract_close_target,
    extract_open_platform_search,
    extract_open_target,
    extract_search_request,
    is_context_reference,
    is_plural_program_reference,
    normalized_words,
    strip_discourse_preamble,
    strip_request_prefixes,
    strip_wake_name,
)
from nesk.platform.windows.program_directory import ProgramDirectory, ProgramEntry, ProgramResolutionKind
from nesk.semantic.contracts import SemanticCandidate, SemanticRequest, SemanticSource


_REFERENCE_WORDS = {
    "ele",
    "ela",
    "isso",
    "isto",
    "esse",
    "essa",
    "aquele",
    "aquela",
    "aquilo",
}
_OPEN_WORDS = {normalized_words(word) for word in OPEN_VERBS if " " not in normalized_words(word)} | {"boto"}
_CLOSE_WORDS = {normalized_words(word) for word in CLOSE_VERBS if " " not in normalized_words(word)}
_SEARCH_WORDS = {normalized_words(word) for word in SEARCH_VERBS if " " not in normalized_words(word)} | {"ve", "olha"}
_PUBLIC_PROGRAM_TARGET_MAX = 100
_PATH_OR_URL = re.compile(r"(?:^[a-z]:[\\/]|://|[\\/])", re.IGNORECASE)
_SHELLISH_TARGETS = frozenset({"cmd", "cmd.exe", "powershell", "pwsh", "bash", "sh", "terminal"})


class ExplicitProgramTargetKind(str, Enum):
    """Local-only classification of an explicitly named program target."""

    KNOWN = "known"
    UNKNOWN = "unknown"
    MISSING = "missing"
    AMBIGUOUS = "ambiguous"
    INVALID = "invalid"


@dataclass(frozen=True, slots=True)
class ExplicitProgramTarget:
    """One non-executable target classification before final Intent selection."""

    kind: ExplicitProgramTargetKind
    entry: ProgramEntry | None = None
    entries: tuple[ProgramEntry, ...] = ()
    label: str | None = None


@dataclass(frozen=True, slots=True)
class ExplicitProgramOpenTargets:
    """A direct ``abre`` request split only across explicit ``e`` conjunctions.

    It is intentionally a local parser result, not a semantic-provider
    contract.  Unknown labels remain descriptive data until the Core renders a
    response; only known entries can later become canonical ``Intent`` values.
    """

    targets: tuple[ExplicitProgramTarget, ...]


def _action_text(text: str) -> str:
    """Normalize a request while preserving the post-preamble modality."""

    return normalized_words(strip_discourse_preamble(strip_wake_name(text)))


def action_safety_reason(text: str) -> str | None:
    """Return why an utterance must never be treated as an action request.

    This conservative check is deliberately run after the narrowly-scoped
    discourse preamble helper.  It does not remove text up to a verb, so a
    negation, question, hypothesis or first-person statement following a
    colloquial marker remains visible to the guard.
    """

    clean = _action_text(text)
    if not clean:
        return "empty"
    if re.search(r"\bnao\b", clean):
        return "negation"
    if (
        re.search(r"\bcomo\b", clean)
        or "me explica" in clean
        or clean.startswith(("me fale como", "me fala como"))
    ):
        return "how_to"
    if any(
        phrase in clean
        for phrase in (
            "talvez",
            "seria legal",
            "eu gosto",
            "gosto de",
            "eu estava pensando",
            "eu tava pensando",
            "estava pensando",
            "tava pensando",
            "pensando em",
            "eu pensei",
            "eu pensava",
            "quero aprender",
            "queria saber",
            "eu queria saber",
            "se eu ",
            "quando eu ",
        )
    ):
        return "discussion_or_hypothesis"
    # A first-person statement is not an imperative.  It also protects normal
    # past-tense mentions such as "eu abri o Discord ontem".
    if clean.startswith("eu "):
        return "first_person_statement"
    if clean.startswith(("ele ", "ela ", "alguem ")):
        return "third_person_statement"
    return None


def is_reference_target(value: str) -> bool:
    return is_context_reference(value)


def _find_aliases(text: str, lookup: dict[str, str]) -> tuple[str, ...]:
    """Find known sites in first-occurrence order.

    The longer alias wins only when two aliases overlap at the same location;
    it never reorders independent entities mentioned by the user.
    """

    clean = normalized_words(text)
    candidates: list[tuple[int, int, str]] = []
    for alias, canonical in lookup.items():
        normalized = normalized_words(alias)
        if not normalized:
            continue
        pattern = rf"(?<![a-z0-9]){re.escape(normalized)}(?![a-z0-9])"
        for match in re.finditer(pattern, clean):
            candidates.append((match.start(), match.end(), canonical))
    candidates.sort(key=lambda item: (item[0], -(item[1] - item[0]), item[2]))
    spans: list[tuple[int, int]] = []
    output: list[str] = []
    for start, end, canonical in candidates:
        if any(start < old_end and end > old_start for old_start, old_end in spans):
            continue
        spans.append((start, end))
        if canonical not in output:
            output.append(canonical)
    return tuple(output)


def _safe_unknown_program_label(value: str) -> str | None:
    """Return displayable unknown text, never a path/shell-like payload."""

    clean = " ".join(str(value).split()).strip(" .,:;!?")
    normalized = normalized_words(clean)
    if (
        not clean
        or len(clean) > _PUBLIC_PROGRAM_TARGET_MAX
        or not normalized
        or _PATH_OR_URL.search(clean)
        or any(ord(character) < 32 for character in clean)
    ):
        return None
    if normalized.split(maxsplit=1)[0] in _SHELLISH_TARGETS:
        return None
    return clean


def _target_from_resolution(value: str, directory: ProgramDirectory) -> ExplicitProgramTarget:
    """Classify one syntactically isolated program target without execution."""

    clean = cleanup_command_target(value)
    if not clean:
        return ExplicitProgramTarget(ExplicitProgramTargetKind.MISSING)

    # A deictic wrapper is normally MISSING, but the pre-existing local
    # grammar accepts one *known* alias embedded after it (``essa parada, o
    # Discord``).  Resolve that limited form before falling back to the normal
    # clarification path; it never turns an unknown wrapper into an Intent.
    if is_context_reference(clean):
        mentions = directory.mentions(clean)
        if len(mentions) == 1:
            return ExplicitProgramTarget(ExplicitProgramTargetKind.KNOWN, entry=mentions[0])
        if len(mentions) > 1:
            return ExplicitProgramTarget(ExplicitProgramTargetKind.AMBIGUOUS, entries=mentions)
        return ExplicitProgramTarget(ExplicitProgramTargetKind.MISSING)

    resolution = directory.resolve(clean)
    if resolution.kind is ProgramResolutionKind.UNIQUE and resolution.entry is not None:
        return ExplicitProgramTarget(ExplicitProgramTargetKind.KNOWN, entry=resolution.entry)
    if resolution.kind is ProgramResolutionKind.AMBIGUOUS:
        return ExplicitProgramTarget(ExplicitProgramTargetKind.AMBIGUOUS, entries=resolution.entries)

    # Reject an unsafe whole phrase before looking for a known alias inside
    # it.  Otherwise ``cmd /c calc`` could accidentally inherit the safe
    # ``calc`` alias even though the user supplied a shell-shaped target.
    label = _safe_unknown_program_label(clean)
    if label is None:
        return ExplicitProgramTarget(ExplicitProgramTargetKind.INVALID)

    # Do not perform a broad mention fallback here.  A full, explicit target
    # such as ``Discord falso`` is not the trusted program ``Discord`` merely
    # because it contains that alias.  The sole supported wrapper form was
    # handled above under ``is_context_reference`` before exact lookup.
    return ExplicitProgramTarget(ExplicitProgramTargetKind.UNKNOWN, label=label)


def _conjoined_program_parts(target: str) -> tuple[str, ...]:
    """Split only the direct Portuguese enumeration form needed by this scope."""

    # Keep the original spelling for a truthful unknown-target response; each
    # part is normalized later by ProgramDirectory during exact resolution.
    parts = tuple(cleanup_command_target(part) for part in re.split(r"\s+e\s+", target, flags=re.IGNORECASE))
    return parts if len(parts) >= 2 and all(parts) else ()


def classify_explicit_program_open_targets(
    text: str,
    directory: ProgramDirectory,
) -> ExplicitProgramOpenTargets | None:
    """Classify direct program-opening targets before a Tool is selected.

    A complete target is always resolved first.  This preserves a legitimate
    installed display name containing ``e``.  Only an unresolved complete
    target is split into a small, explicit conjunction, which lets
    ``Discord e Riot Client`` retain the unknown segment rather than silently
    discarding it through ``ProgramDirectory.mentions``.
    """

    target = extract_open_target(text)
    if target is None:
        return None
    whole = cleanup_command_target(target)
    if not whole:
        return ExplicitProgramOpenTargets((ExplicitProgramTarget(ExplicitProgramTargetKind.MISSING),))

    # Exact lookup comes first so a trusted display name such as ``Pesquisa e
    # Jogos`` remains one entity if the local directory knows it.
    exact = directory.resolve(whole)
    if exact.kind is ProgramResolutionKind.UNIQUE and exact.entry is not None:
        return ExplicitProgramOpenTargets((ExplicitProgramTarget(ExplicitProgramTargetKind.KNOWN, entry=exact.entry),))
    if exact.kind is ProgramResolutionKind.AMBIGUOUS:
        return ExplicitProgramOpenTargets((ExplicitProgramTarget(ExplicitProgramTargetKind.AMBIGUOUS, entries=exact.entries),))

    parts = _conjoined_program_parts(whole)
    if parts:
        return ExplicitProgramOpenTargets(tuple(_target_from_resolution(part, directory) for part in parts))
    return ExplicitProgramOpenTargets((_target_from_resolution(whole, directory),))


def classify_program_name_reply(value: str, directory: ProgramDirectory) -> ExplicitProgramTarget:
    """Classify a short reply to an already-pending program clarification."""

    return _target_from_resolution(value, directory)


def looks_like_action_request(text: str, directory: ProgramDirectory | None = None) -> bool:
    """Cheap local gate before an optional remote semantic provider.

    A known entity by itself is not a request.  The remote provider may help
    only after an explicit action-shaped utterance passed the local parser;
    bare ``Discord``/``YouTube`` remain ordinary conversation except while a
    Core-owned clarification is pending.
    """

    clean = _action_text(text)
    words = set(clean.split())
    return bool(words & (_OPEN_WORDS | _CLOSE_WORDS | _SEARCH_WORDS))


def _starts_action(clean: str, words: set[str], *, allow_manda: bool = False) -> bool:
    direct = strip_request_prefixes(clean)
    if allow_manda:
        direct = re.sub(r"^manda\s+(?:me\s+)?", "", direct).strip()
    first = direct.split(maxsplit=1)[0] if direct else ""
    return first in words


def _search_request(clean: str) -> tuple[str | None, str] | None:
    """Recognize explicit and engine-only local search continuations."""

    direct = strip_request_prefixes(clean)
    parsed = extract_search_request(direct)
    if parsed is not None:
        return parsed.query, parsed.engine

    # ``agora no YouTube`` is deliberately a targetless local continuation.
    # SessionContext will either substitute a recent search topic or ask for
    # one; it is never sent to a provider with hidden context.
    engine_only = re.fullmatch(r"(?:no|na)\s+(youtube|you\s*tube|google)", direct)
    if engine_only:
        return None, "youtube" if "tube" in engine_only.group(1) or engine_only.group(1) == "youtube" else "google"

    # "vê isso no YouTube" and "agora vê no YouTube" use the same typed,
    # targetless continuation.  They are not generic conversational guesses.
    match = re.match(
        r"^(?:ve|olha)\s*(?:isso|isto|ai|aqui)?\s*(?:no|na)\s+(youtube|you\s*tube|google)\s*$",
        direct,
    )
    if match:
        return None, "youtube" if "tube" in match.group(1) or match.group(1) == "youtube" else "google"
    return None


class LocalSemanticInterpreter:
    """Small compositional resolver for phrasing the strict router cannot parse.

    It works from existing action families and a shared, validated Program
    Directory instead of attempting fuzzy correction or a growing list of full
    sentences.  It does not inspect tools and cannot execute anything.
    """

    def __init__(self, *, directory: ProgramDirectory | None = None) -> None:
        self.directory = directory or ProgramDirectory.static()

    def interpret(self, request: SemanticRequest) -> SemanticCandidate | None:
        clean = _action_text(request.text)
        if not clean or action_safety_reason(clean) is not None:
            return None

        search = _search_request(clean)
        if search is not None:
            query, engine = search
            return SemanticCandidate(
                action="browser.search",
                target=query,
                confidence=0.95 if query and not is_reference_target(query) else 0.82,
                source=SemanticSource.LOCAL,
                entities={"engine": engine},
            )

        # Target classification happens before program selection.  A textual
        # entity placed on YouTube/Google is a search at the current capability
        # level, never an unknown local program or a fabricated URL.
        platform_search = extract_open_platform_search(clean)
        if platform_search is not None and _starts_action(clean, _OPEN_WORDS, allow_manda=True):
            return SemanticCandidate(
                action="browser.search",
                target=platform_search.query,
                confidence=0.95,
                source=SemanticSource.LOCAL,
                entities={"engine": platform_search.engine},
            )

        if _starts_action(clean, _CLOSE_WORDS):
            # Keep plural references distinct from the singular-pronoun path.
            # The SessionContext group resolver will later rebuild fresh,
            # canonical close Intents locally; this candidate carries no path
            # and gives no provider any authority over the group.
            close_target = extract_close_target(clean)
            if close_target is not None and is_plural_program_reference(close_target):
                return SemanticCandidate(
                    action="programs.close",
                    target=close_target,
                    confidence=0.82,
                    source=SemanticSource.LOCAL,
                )
            programs = self.directory.mentions(clean)
            if len(programs) == 1:
                entry = programs[0]
                return SemanticCandidate(
                    action="programs.close",
                    target=entry.identifier,
                    confidence=0.95,
                    source=SemanticSource.LOCAL,
                    entities={"program": entry.identifier},
                )
            if len(programs) > 1:
                return SemanticCandidate(
                    action="programs.close",
                    confidence=0.55,
                    source=SemanticSource.LOCAL,
                    options=tuple(entry.identifier for entry in programs),
                    clarification_required=True,
                )
            # Keep the reference token structured so the Context layer, not a
            # tool, decides whether it has a valid antecedent.
            target = next((word for word in clean.split() if word in _REFERENCE_WORDS), None)
            return SemanticCandidate(
                action="programs.close",
                target=target,
                confidence=0.82 if target else 0.52,
                source=SemanticSource.LOCAL,
                clarification_required=target is None,
            )

        if _starts_action(clean, _OPEN_WORDS, allow_manda=True):
            programs = self.directory.mentions(clean)
            if len(programs) == 1:
                entry = programs[0]
                return SemanticCandidate(
                    action="programs.open",
                    target=entry.identifier,
                    confidence=0.95,
                    source=SemanticSource.LOCAL,
                    entities={"program": entry.identifier},
                )
            if len(programs) > 1:
                return SemanticCandidate(
                    action="programs.open",
                    confidence=0.55,
                    source=SemanticSource.LOCAL,
                    options=tuple(entry.identifier for entry in programs),
                    clarification_required=True,
                )

            sites = _find_aliases(clean, SITE_LOOKUP)
            if len(sites) == 1:
                return SemanticCandidate(
                    action="browser.open_named",
                    target=sites[0],
                    confidence=0.95,
                    source=SemanticSource.LOCAL,
                    entities={"site": sites[0]},
                )
            if len(sites) > 1:
                return SemanticCandidate(
                    action="browser.open_named",
                    confidence=0.55,
                    source=SemanticSource.LOCAL,
                    options=sites,
                    clarification_required=True,
                )

            if any(alias in clean for alias in (normalized_words(item) for item in BROWSER_ALIASES)):
                return SemanticCandidate(
                    action="browser.open_default",
                    confidence=0.95,
                    source=SemanticSource.LOCAL,
                )

            # A narrow semantic hint, not a general phrase table: NESK knows
            # Discord as its supported desktop conversation app.  It remains a
            # clarification instead of a silent assumption.
            if re.search(r"\b(?:conversar|conversa|chat)\b", clean):
                return SemanticCandidate(
                    action="programs.open",
                    target="discord",
                    confidence=0.62,
                    source=SemanticSource.LOCAL,
                    options=("discord",),
                    clarification_required=True,
                )

            return SemanticCandidate(
                action="programs.open",
                confidence=0.50,
                source=SemanticSource.LOCAL,
                clarification_required=True,
            )
        return None


__all__ = [
    "ExplicitProgramOpenTargets",
    "ExplicitProgramTarget",
    "ExplicitProgramTargetKind",
    "LocalSemanticInterpreter",
    "action_safety_reason",
    "classify_explicit_program_open_targets",
    "classify_program_name_reply",
    "is_reference_target",
    "looks_like_action_request",
]
