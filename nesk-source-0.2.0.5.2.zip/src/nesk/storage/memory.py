from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable


class PrivacyLevel(str, Enum):
    LOCAL_ONLY = "local_only"
    PRIVATE = "private"
    NORMAL = "normal"


@dataclass(frozen=True, slots=True)
class MemoryItem:
    id: int
    kind: str
    content: str
    privacy: PrivacyLevel
    cloud_allowed: bool
    importance: float
    created_at: str

    @property
    def may_leave_device(self) -> bool:
        return self.privacy is not PrivacyLevel.LOCAL_ONLY and self.cloud_allowed


class MemoryRepository:
    """Explicit long-term memory access.

    0.1.7 deliberately does not auto-create memories from every conversation.
    """

    def __init__(self, store) -> None:
        self.store = store

    def add(
        self,
        *,
        kind: str,
        content: str,
        privacy: PrivacyLevel = PrivacyLevel.PRIVATE,
        cloud_allowed: bool = False,
        importance: float = 0.5,
    ) -> int:
        if privacy is PrivacyLevel.LOCAL_ONLY:
            cloud_allowed = False
        return self.store.add_memory(
            kind=kind,
            content=content,
            privacy=privacy.value,
            cloud_allowed=cloud_allowed,
            importance=importance,
        )

    def recent(self, limit: int = 20) -> list[MemoryItem]:
        rows: Iterable[dict] = self.store.recent_memories(limit)
        return [
            MemoryItem(
                id=int(row["id"]),
                kind=str(row["kind"]),
                content=str(row["content"]),
                privacy=PrivacyLevel(str(row["privacy"])),
                cloud_allowed=bool(row["cloud_allowed"]),
                importance=float(row["importance"]),
                created_at=str(row["created_at"]),
            )
            for row in rows
        ]
