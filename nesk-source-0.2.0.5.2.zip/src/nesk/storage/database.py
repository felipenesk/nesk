from __future__ import annotations

import sqlite3
from contextlib import closing, contextmanager
from datetime import datetime
from pathlib import Path
from threading import RLock
from typing import Iterator

from nesk.core.models import Message, Role


_SCHEMA_VERSION = 2

_SCHEMA_V1 = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role TEXT NOT NULL CHECK(role IN ('user','assistant','system')),
    content TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_id ON messages(id);
CREATE TABLE IF NOT EXISTS memory_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    content TEXT NOT NULL,
    privacy TEXT NOT NULL DEFAULT 'private',
    cloud_allowed INTEGER NOT NULL DEFAULT 0,
    importance REAL NOT NULL DEFAULT 0.5,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""

_SCHEMA_V2 = """
CREATE INDEX IF NOT EXISTS idx_memory_created_at ON memory_items(created_at);
CREATE INDEX IF NOT EXISTS idx_memory_kind ON memory_items(kind);
"""


class ConversationStore:
    def __init__(self, path: Path, enabled: bool = True) -> None:
        self.path = path
        self.enabled = enabled
        self._lock = RLock()
        self._existed_before_init = path.exists()
        path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=5)
        connection.row_factory = sqlite3.Row
        return connection

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        """Commit/rollback and close every SQLite handle deterministically.

        ``sqlite3.Connection.__exit__`` commits or rolls back but does not
        close the Windows file handle.  Explicit closure matters for temporary
        smoke/release databases, where delayed GC can otherwise keep a WAL
        file locked during cleanup.
        """

        connection = self._connect()
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _backup_before_migration(self, current: int) -> Path | None:
        if not self.path.exists() or current >= _SCHEMA_VERSION:
            return None
        backup_path = self.path.with_name(f"{self.path.stem}.pre_schema_{_SCHEMA_VERSION}.bak.db")
        # SQLite's backup API safely includes WAL state unlike a raw file copy.
        with closing(sqlite3.connect(self.path)) as source, closing(sqlite3.connect(backup_path)) as target:
            source.backup(target)
            target.commit()
        return backup_path

    def _initialize(self) -> None:
        with self._lock:
            with self._connection() as con:
                current = int(con.execute("PRAGMA user_version").fetchone()[0])
                if current > _SCHEMA_VERSION:
                    raise RuntimeError(
                        f"Banco NESK usa schema {current}, mas esta build suporta até {_SCHEMA_VERSION}."
                    )

            if current < _SCHEMA_VERSION and self._existed_before_init and self.path.stat().st_size > 0:
                self._backup_before_migration(current)

            with self._connection() as con:
                if current < 1:
                    con.executescript(_SCHEMA_V1)
                    con.execute("PRAGMA user_version = 1")
                    current = 1
                else:
                    # Keep adoption idempotent for legacy Foundation databases.
                    con.executescript(_SCHEMA_V1)

                if current < 2:
                    con.executescript(_SCHEMA_V2)
                    con.execute("PRAGMA user_version = 2")

    def schema_version(self) -> int:
        with self._lock, self._connection() as con:
            return int(con.execute("PRAGMA user_version").fetchone()[0])

    def integrity_check(self) -> bool:
        """Return True only when SQLite reports a healthy database."""
        with self._lock, self._connection() as con:
            row = con.execute("PRAGMA quick_check").fetchone()
        return bool(row and str(row[0]).lower() == "ok")

    def add(self, message: Message) -> None:
        if not self.enabled:
            return
        with self._lock, self._connection() as con:
            con.execute(
                "INSERT INTO messages(role, content, created_at) VALUES (?, ?, ?)",
                (message.role.value, message.content, message.created_at.isoformat()),
            )

    def recent(self, limit: int = 12) -> list[Message]:
        if not self.enabled or limit <= 0:
            return []
        with self._lock, self._connection() as con:
            rows = con.execute(
                "SELECT role, content, created_at FROM messages ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            Message(Role(row["role"]), row["content"], datetime.fromisoformat(row["created_at"]))
            for row in reversed(rows)
        ]

    def clear_messages(self) -> None:
        with self._lock, self._connection() as con:
            con.execute("DELETE FROM messages")

    def add_memory(
        self,
        *,
        kind: str,
        content: str,
        privacy: str = "private",
        cloud_allowed: bool = False,
        importance: float = 0.5,
    ) -> int:
        importance = min(1.0, max(0.0, float(importance)))
        if privacy == "local_only":
            cloud_allowed = False
        with self._lock, self._connection() as con:
            cursor = con.execute(
                """
                INSERT INTO memory_items(kind, content, privacy, cloud_allowed, importance)
                VALUES (?, ?, ?, ?, ?)
                """,
                (kind, content, privacy, int(bool(cloud_allowed)), importance),
            )
            return int(cursor.lastrowid)

    def recent_memories(self, limit: int = 20) -> list[dict]:
        if limit <= 0:
            return []
        with self._lock, self._connection() as con:
            rows = con.execute(
                """
                SELECT id, kind, content, privacy, cloud_allowed, importance, created_at
                FROM memory_items ORDER BY id DESC LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]
