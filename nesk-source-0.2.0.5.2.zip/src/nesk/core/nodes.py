from __future__ import annotations

from dataclasses import dataclass, field
from threading import RLock


@dataclass(frozen=True, slots=True)
class NeskNode:
    node_id: str
    kind: str
    display_name: str
    capabilities: frozenset[str] = field(default_factory=frozenset)
    local: bool = False

    def supports(self, capability: str) -> bool:
        return capability in self.capabilities


class NodeRegistry:
    def __init__(self) -> None:
        self._nodes: dict[str, NeskNode] = {}
        self._lock = RLock()

    def register(self, node: NeskNode) -> None:
        with self._lock:
            self._nodes[node.node_id] = node

    def get(self, node_id: str) -> NeskNode | None:
        with self._lock:
            return self._nodes.get(node_id)

    def all(self) -> list[NeskNode]:
        with self._lock:
            return list(self._nodes.values())
