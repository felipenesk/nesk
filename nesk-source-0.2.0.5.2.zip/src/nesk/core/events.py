from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from threading import RLock
from typing import Any, Callable


@dataclass(frozen=True, slots=True)
class NeskEvent:
    name: str
    data: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


EventHandler = Callable[[NeskEvent], None]


class EventBus:
    """Tiny in-process event bus used to decouple UI/Voice/future Nodes.

    Events should carry technical metadata by default, not conversation content.
    A broken observer is isolated so it cannot crash the Core.
    """

    def __init__(self) -> None:
        self._handlers: dict[str, list[EventHandler]] = defaultdict(list)
        self._lock = RLock()
        self._logger = logging.getLogger("nesk")

    def subscribe(self, event_name: str, handler: EventHandler) -> None:
        with self._lock:
            self._handlers[event_name].append(handler)

    def unsubscribe(self, event_name: str, handler: EventHandler) -> None:
        with self._lock:
            handlers = self._handlers.get(event_name, [])
            if handler in handlers:
                handlers.remove(handler)

    def publish(self, event_name: str, **data: Any) -> None:
        event = NeskEvent(event_name, data)
        with self._lock:
            handlers = list(self._handlers.get(event_name, ())) + list(self._handlers.get("*", ()))
        for handler in handlers:
            try:
                handler(event)
            except Exception as exc:
                self._logger.exception(
                    "event_handler_error event=%s type=%s", event_name, type(exc).__name__
                )
