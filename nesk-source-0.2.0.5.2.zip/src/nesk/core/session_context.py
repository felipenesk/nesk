from __future__ import annotations

import time
from dataclasses import dataclass
from enum import Enum
from typing import Callable

from nesk.core.intent import Intent
from nesk.nlu.lexicon import SITE_LOOKUP
from nesk.nlu.ptbr import is_plural_program_reference, normalized_words, strip_wake_name
from nesk.platform.windows.program_directory import ProgramDirectory, ProgramResolutionKind
from nesk.semantic.contracts import SemanticContextView
from nesk.semantic.local import is_reference_target
from nesk.tools.base import ToolResult


@dataclass(frozen=True, slots=True)
class ClarificationOption:
    """A prevalidated Intent that can be selected only while pending."""

    label: str
    intent: Intent


@dataclass(frozen=True, slots=True)
class ClarificationRequest:
    """Core-owned question metadata; providers never render executable text."""

    prompt: str
    options: tuple[ClarificationOption, ...] = ()
    action: str | None = None
    target_kind: str | None = None
    allowed_targets: tuple[str, ...] = ()
    # Multi-select is deliberately narrow: only Core-created compatible,
    # prevalidated options can opt in.  It is not a generic tool batch.
    allow_multi_select: bool = False


@dataclass(slots=True)
class PendingClarification:
    request: ClarificationRequest
    created_turn: int
    created_at: float


class ClarificationDecision(str, Enum):
    SELECTED = "selected"
    CANCELLED = "cancelled"
    AMBIGUOUS = "ambiguous"
    UNRELATED = "unrelated"
    EXPIRED = "expired"


@dataclass(frozen=True, slots=True)
class ClarificationReply:
    """A typed selection; multiple intents exist only for an approved request."""

    decision: ClarificationDecision
    intent: Intent | None = None
    intents: tuple[Intent, ...] = ()

    @property
    def selected_intents(self) -> tuple[Intent, ...]:
        if self.intents:
            return self.intents
        return (self.intent,) if self.intent is not None else ()


@dataclass(frozen=True, slots=True)
class ReferenceResolution:
    intent: Intent | None
    requires_clarification: bool = False
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class ProgramGroupReferenceResolution:
    """Canonical program IDs selected from a short-lived plural antecedent."""

    program_ids: tuple[str, ...] = ()
    requires_clarification: bool = False
    reason: str | None = None


_CANCEL_REPLIES = {
    "nao",
    "nao precisa",
    "nao quero",
    "melhor nao",
    "cancela",
    "cancelar",
    "deixa",
    "deixa quieto",
    "pode deixar",
    "esquece",
}
_SINGLE_OPTION_REPLIES = {"sim", "isso", "esse", "essa", "isto", "ok", "okay"}
_FIRST_REPLIES = {"primeiro", "a primeira", "o primeiro", "primeira"}
_SECOND_REPLIES = {"segundo", "a segunda", "o segundo", "segunda"}
_MULTI_SELECT_REPLIES = {
    "ambos",
    "as duas",
    "os dois",
    "pode abrir os dois",
    "abre os dois",
    "pode abrir ambos",
    "abre ambos",
}


class SessionContext:
    """Short-lived semantic state owned by one NeskCore instance.

    It has no database reference and never writes persistent memory.  The
    fields are deliberately small enough to inspect and reason about: the last
    successful action, a canonical program identity, a search topic/engine and
    one pending clarification.
    """

    def __init__(
        self,
        *,
        directory: ProgramDirectory | None = None,
        reference_ttl_turns: int = 3,
        clarification_ttl_turns: int = 2,
        clarification_ttl_seconds: float = 120.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.directory = directory or ProgramDirectory.static()
        self.reference_ttl_turns = max(1, int(reference_ttl_turns))
        self.clarification_ttl_turns = max(1, int(clarification_ttl_turns))
        self.clarification_ttl_seconds = max(1.0, float(clarification_ttl_seconds))
        self._clock = clock
        self._turn = 0
        self.last_successful_intent: Intent | None = None
        self.last_tool: str | None = None
        self.last_success_turn: int | None = None
        self.last_program: str | None = None
        self.last_program_turn: int | None = None
        # This is intentionally only opaque canonical IDs.  It never stores
        # Intents, ToolResults, display text, executable paths or a Tool object.
        self.recent_program_group: tuple[str, ...] = ()
        self.recent_program_group_turn: int | None = None
        self.last_search_query: str | None = None
        self.last_search_engine: str | None = None
        self.last_search_turn: int | None = None
        self.active_topic: str | None = None
        self._pending: PendingClarification | None = None

    @property
    def turn(self) -> int:
        return self._turn

    @property
    def pending_clarification(self) -> PendingClarification | None:
        return self._pending

    def advance_turn(self) -> int:
        self._turn += 1
        return self._turn

    def _is_fresh(self, recorded_turn: int | None) -> bool:
        return recorded_turn is not None and self._turn - recorded_turn <= self.reference_ttl_turns

    def _clarification_expired(self, pending: PendingClarification) -> bool:
        return (
            self._turn - pending.created_turn > self.clarification_ttl_turns
            or self._clock() - pending.created_at > self.clarification_ttl_seconds
        )

    def expire_clarification(self) -> bool:
        if self._pending is not None and self._clarification_expired(self._pending):
            self._pending = None
            return True
        return False

    def begin_clarification(self, request: ClarificationRequest) -> None:
        self._pending = PendingClarification(request, self._turn, self._clock())

    def invalidate_clarification(self) -> None:
        self._pending = None

    def clear_recent_program_group(self) -> None:
        """Forget a plural antecedent without touching persistent storage."""

        self.recent_program_group = ()
        self.recent_program_group_turn = None

    def record_program_group(self, program_ids: tuple[str, ...]) -> bool:
        """Record exactly one successful, canonical two-program open batch.

        The Core calls this only after all members of its prevalidated batch
        completed successfully through ToolRegistry.  This method rechecks the
        IDs defensively, but intentionally cannot infer a group from adjacent
        individual actions.
        """

        clean = tuple(str(identifier).strip().lower() for identifier in program_ids)
        if len(clean) != 2 or len(set(clean)) != 2 or any(self.directory.entry(identifier) is None for identifier in clean):
            self.clear_recent_program_group()
            return False
        self.recent_program_group = clean
        self.recent_program_group_turn = self._turn
        return True

    def semantic_view_for(self, text: str) -> SemanticContextView:
        """Expose only a relevant, typed subset for an optional provider.

        Local reference and implicit-engine continuation resolution happen
        before a remote call.  This fallback keeps context empty unless the
        current text explicitly contains a compatible reference word.
        """

        clean = normalized_words(strip_wake_name(text))
        wants_program = bool(set(clean.split()) & {"ele", "ela", "esse", "essa", "aquele", "aquela"})
        wants_topic = bool(set(clean.split()) & {"isso", "isto", "aquilo", "esse", "essa"})
        return SemanticContextView(
            last_program=self.last_program if wants_program and self._is_fresh(self.last_program_turn) else None,
            active_topic=self.active_topic if wants_topic and self._is_fresh(self.last_search_turn) else None,
            last_search_engine=self.last_search_engine if wants_topic and self._is_fresh(self.last_search_turn) else None,
        )

    def record_success(self, intent: Intent, result: ToolResult) -> None:
        """Record only successful ToolRegistry outcomes for later references."""

        if not result.ok:
            return
        self.last_successful_intent = intent
        self.last_tool = intent.tool_name
        self.last_success_turn = self._turn
        data = result.data or {}

        # A plural antecedent is only current until another successful Tool
        # action takes focus.  A new approved multi-open batch clears it before
        # its individual calls and records a replacement after the batch ends.
        self.clear_recent_program_group()

        if intent.tool_name in {"programs.open", "programs.close"}:
            name = str(data.get("program") or intent.args.get("name") or "").strip().lower()
            if self.directory.entry(name) is not None:
                self.last_program = name
                self.last_program_turn = self._turn
        elif intent.tool_name == "browser.search":
            query = " ".join(str(data.get("query") or intent.args.get("query") or "").split()).strip()
            engine = str(data.get("engine") or intent.args.get("engine") or "google").strip().lower()
            if query:
                self.last_search_query = query
                self.last_search_engine = engine
                self.last_search_turn = self._turn
                self.active_topic = query

    def resolve_program_group_reference(self, intent: Intent) -> ProgramGroupReferenceResolution:
        """Resolve an exact plural program reference only while it is active.

        This does not manufacture Intents.  The coordinator must reread every
        returned ID from the current ProgramDirectory and construct a fresh
        Intent for each action, so a stale/dropped directory entry fails closed.
        """

        if intent.tool_name not in {"programs.open", "programs.close"}:
            return ProgramGroupReferenceResolution()
        raw_target = str(intent.args.get("name") or "")
        if not is_plural_program_reference(raw_target):
            return ProgramGroupReferenceResolution()
        program_is_active = self.last_tool in {"programs.open", "programs.close"}
        group_is_active = (
            bool(self.recent_program_group)
            and self.recent_program_group_turn is not None
            and self.last_success_turn == self.recent_program_group_turn
            and program_is_active
            and self._is_fresh(self.recent_program_group_turn)
        )
        if group_is_active:
            return ProgramGroupReferenceResolution(program_ids=self.recent_program_group)
        return ProgramGroupReferenceResolution(requires_clarification=True, reason="program_group_reference")

    def resolve_reference(self, intent: Intent) -> ReferenceResolution:
        """Resolve only type-compatible, recent contextual references."""

        if intent.tool_name in {"programs.open", "programs.close"}:
            raw_target = str(intent.args.get("name") or "")
            if not is_reference_target(raw_target):
                return ReferenceResolution(intent)
            # A program reference is safe only when the immediately active
            # successful action was itself a program action.  An intervening
            # website/search must not make ``ele`` close an older program.
            program_is_active = self.last_tool in {"programs.open", "programs.close"}
            if self.last_program and program_is_active and self._is_fresh(self.last_program_turn):
                entry = self.directory.entry(self.last_program)
                if entry is not None:
                    args = dict(intent.args)
                    args["name"] = entry.identifier
                    args["display_name"] = entry.display_name
                    return ReferenceResolution(
                        Intent(intent.tool_name, args, confidence=0.98, source=intent.source)
                    )
            return ReferenceResolution(None, requires_clarification=True, reason="program_reference")

        if intent.tool_name == "browser.search":
            raw_query = str(intent.args.get("query") or "")
            if raw_query and not is_reference_target(raw_query):
                return ReferenceResolution(intent)
            if self.last_search_query and self._is_fresh(self.last_search_turn):
                args = dict(intent.args)
                args["query"] = self.last_search_query
                args.setdefault("engine", self.last_search_engine or "google")
                return ReferenceResolution(
                    Intent(intent.tool_name, args, confidence=0.98, source=intent.source)
                )
            return ReferenceResolution(None, requires_clarification=True, reason="search_reference")

        return ReferenceResolution(intent)

    @staticmethod
    def _clean_reply(text: str) -> str:
        clean = normalized_words(strip_wake_name(text)).strip(" .,:;!?-_")
        clean = clean.removeprefix("o ").removeprefix("a ").strip()
        return clean

    def _candidate_from_target(self, request: ClarificationRequest, value: str) -> Intent | None:
        if request.action is None or request.target_kind is None:
            return None
        clean = self._clean_reply(value)
        if request.target_kind == "program":
            resolution = self.directory.resolve(clean)
            entry = resolution.entry
            if (
                resolution.kind is ProgramResolutionKind.UNIQUE
                and entry is not None
                and entry.identifier in request.allowed_targets
            ):
                return Intent(
                    request.action,
                    {"name": entry.identifier, "display_name": entry.display_name},
                    confidence=0.98,
                )
        if request.target_kind == "site":
            canonical = SITE_LOOKUP.get(clean, clean)
            if canonical in request.allowed_targets:
                return Intent(request.action, {"name": canonical}, confidence=0.98)
        return None

    @staticmethod
    def _may_select_all(request: ClarificationRequest) -> bool:
        return (
            request.allow_multi_select
            and len(request.options) == 2
            and all(option.intent.tool_name == "programs.open" for option in request.options)
        )

    def consume_clarification(self, text: str) -> ClarificationReply:
        pending = self._pending
        if pending is None:
            return ClarificationReply(ClarificationDecision.UNRELATED)
        if self._clarification_expired(pending):
            self._pending = None
            return ClarificationReply(ClarificationDecision.EXPIRED)

        request = pending.request
        clean = self._clean_reply(text)
        if clean in _CANCEL_REPLIES:
            self._pending = None
            return ClarificationReply(ClarificationDecision.CANCELLED)

        options = request.options
        if clean in _MULTI_SELECT_REPLIES:
            if self._may_select_all(request):
                self._pending = None
                return ClarificationReply(
                    ClarificationDecision.SELECTED,
                    intents=tuple(option.intent for option in options),
                )
            return ClarificationReply(ClarificationDecision.AMBIGUOUS)
        if clean in _FIRST_REPLIES and len(options) >= 1:
            self._pending = None
            return ClarificationReply(ClarificationDecision.SELECTED, options[0].intent)
        if clean in _SECOND_REPLIES and len(options) >= 2:
            self._pending = None
            return ClarificationReply(ClarificationDecision.SELECTED, options[1].intent)

        for option in options:
            label = self._clean_reply(option.label)
            if clean == label:
                self._pending = None
                return ClarificationReply(ClarificationDecision.SELECTED, option.intent)

        target_intent = self._candidate_from_target(request, clean)
        if target_intent is not None:
            self._pending = None
            return ClarificationReply(ClarificationDecision.SELECTED, target_intent)

        if clean in _SINGLE_OPTION_REPLIES:
            if len(options) == 1:
                self._pending = None
                return ClarificationReply(ClarificationDecision.SELECTED, options[0].intent)
            return ClarificationReply(ClarificationDecision.AMBIGUOUS)

        # A non-selection is deliberately treated as a new topic by Core.  It
        # invalidates this clarification rather than allowing it to be answered
        # accidentally many turns later.
        self._pending = None
        return ClarificationReply(ClarificationDecision.UNRELATED)


__all__ = [
    "ClarificationDecision",
    "ClarificationOption",
    "ClarificationReply",
    "ClarificationRequest",
    "PendingClarification",
    "ProgramGroupReferenceResolution",
    "ReferenceResolution",
    "SessionContext",
]
