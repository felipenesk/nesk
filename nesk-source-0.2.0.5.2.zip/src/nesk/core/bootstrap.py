from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from nesk.core.assistant import NeskCore
from nesk.core.config import load_config
from nesk.core.events import EventBus
from nesk.core.logging_setup import configure_logging
from nesk.core.nodes import NeskNode, NodeRegistry
from nesk.core.permissions import PermissionPolicy
from nesk.platform.windows.programs import WindowsProgramCatalog
from nesk.providers.factory import create_provider
from nesk.semantic.factory import create_semantic_provider
from nesk.storage.database import ConversationStore
from nesk.storage.memory import MemoryRepository
from nesk.tools.browser import OpenDefaultBrowserTool, OpenNamedSiteTool, OpenUrlTool, SearchWebTool
from nesk.tools.capabilities import CapabilitiesTool
from nesk.tools.programs import CloseProgramTool, OpenProgramTool
from nesk.tools.registry import ToolRegistry
from nesk.tools.system_status import SystemStatusTool
from nesk.version import __version__
from nesk.voice.service import VoiceService


@dataclass(slots=True)
class NeskRuntime:
    core: NeskCore
    config: dict
    data_root: Path
    tools: ToolRegistry
    memory: MemoryRepository
    nodes: NodeRegistry
    events: EventBus
    voice: VoiceService
    _closed: bool = field(default=False, init=False, repr=False)

    def shutdown(self) -> None:
        """Idempotent runtime shutdown boundary used by GUI/CLI/nodes/voice."""
        if self._closed:
            return
        self._closed = True
        self.events.publish("runtime.stopping", version=__version__)
        try:
            self.voice.close()
        finally:
            try:
                self.core.close()
            finally:
                self.events.publish("runtime.stopped", version=__version__)


def bootstrap() -> NeskRuntime:
    config, root = load_config()
    logger = configure_logging(root)
    logger.info("NESK %s starting", __version__)

    store = ConversationStore(
        root / "nesk.db",
        enabled=bool(config["privacy"].get("store_conversations", True)),
    )
    memory = MemoryRepository(store)
    events = EventBus()

    registry = ToolRegistry(PermissionPolicy())
    # Discovery runs once at bootstrap, outside the text/voice request path.
    # The cache is local to the runtime data root and is revalidated before it
    # can contribute any launch target.
    catalog = WindowsProgramCatalog(
        config.get("programs", {}),
        cache_path=root / "program_directory_cache.json",
    )
    discovered = catalog.refresh()
    logger.info("program_directory_refreshed discovered=%d", discovered)
    registry.register(SystemStatusTool())
    registry.register(OpenUrlTool())
    registry.register(OpenDefaultBrowserTool())
    registry.register(OpenNamedSiteTool())
    registry.register(SearchWebTool())
    registry.register(OpenProgramTool(catalog))
    registry.register(CloseProgramTool(catalog))
    registry.register(CapabilitiesTool(registry))

    nodes = NodeRegistry()
    nodes.register(
        NeskNode(
            node_id="local-windows",
            kind="windows",
            display_name="Windows local",
            capabilities=frozenset(registry.names()),
            local=True,
        )
    )

    provider = create_provider(config["ai"])
    semantic_config = config["semantic"]
    semantic_provider = create_semantic_provider(semantic_config)
    core = NeskCore(
        provider=provider,
        store=store,
        tools=registry,
        context_limit=int(config["ai"].get("recent_context_messages", 12)),
        logger=logger,
        events=events,
        semantic_provider=semantic_provider,
        semantic_timeout_seconds=float(semantic_config.get("timeout_seconds", 4.0)),
        reference_ttl_turns=int(semantic_config.get("reference_ttl_turns", 3)),
        clarification_ttl_turns=int(semantic_config.get("clarification_ttl_turns", 2)),
        program_directory=catalog.directory,
    )
    voice = VoiceService(core=core, config=config, data_root=root)
    return NeskRuntime(
        core=core,
        config=config,
        data_root=root,
        tools=registry,
        memory=memory,
        nodes=nodes,
        events=events,
        voice=voice,
    )
