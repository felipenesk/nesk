from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class IntentSource(str, Enum):
    LOCAL_NLU = "local_nlu"
    SEMANTIC_LOCAL = "semantic_local"
    SEMANTIC_PROVIDER = "semantic_provider"
    MODEL = "model"
    SYSTEM = "system"


@dataclass(frozen=True, slots=True)
class Intent:
    """Structured action request produced by any future resolver.

    The Core consumes this format regardless of whether the intent came from the
    deterministic Portuguese router, a future LLM, voice, or another NESK node.
    """

    tool_name: str
    args: dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0
    source: IntentSource = IntentSource.LOCAL_NLU

    def __post_init__(self) -> None:
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence deve estar entre 0.0 e 1.0")

    @property
    def name(self) -> str:
        """Backward-compatible alias used by the 0.1.x test suite."""
        return self.tool_name
