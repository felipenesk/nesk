from __future__ import annotations

import logging
import re
from collections import deque
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
from dataclasses import dataclass
from threading import Event, RLock

from nesk.core.events import EventBus
from nesk.core.intent import Intent
from nesk.core.intent_resolution import IntentResolution, IntentResolutionCoordinator, ProgramOpenResolution
from nesk.core.intent_router import LocalIntentRouter
from nesk.core.models import AssistantResult, Message, Role
from nesk.core.session_context import ClarificationDecision, SessionContext
from nesk.nlu.confirmation import ConfirmationDecision, classify_confirmation
from nesk.platform.windows.program_directory import ProgramDirectory
from nesk.providers.base import AIProvider
from nesk.semantic.contracts import SemanticCandidate, SemanticProvider, SemanticRequest
from nesk.semantic.provider import NullSemanticProvider
from nesk.storage.database import ConversationStore
from nesk.tools.registry import ToolRegistry


@dataclass(slots=True)
class PendingAction:
    intent: Intent
    prompt: str


@dataclass(frozen=True, slots=True)
class PendingBatch:
    """Completed/remaining state for one narrowly-approved clarification batch."""

    selected_total: int
    completed: tuple[AssistantResult, ...]
    remaining: tuple[Intent, ...]
    # Present only for the two canonical program-open Intents selected from a
    # pending clarification.  It never contains a path or free-form target.
    program_group_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class PendingProgramGroup:
    """Permission pause for a locally reconstructed plural program reference."""

    completed: tuple[AssistantResult, ...]
    remaining: tuple[Intent, ...]


@dataclass(frozen=True, slots=True)
class PendingProgramOpenResolution:
    """Permission pause for a closed explicit-known/unknown opening plan."""

    resolution: ProgramOpenResolution
    completed: tuple[tuple[int, AssistantResult], ...]
    active_index: int
    remaining: tuple[tuple[int, Intent], ...]


class NeskCore:
    def __init__(
        self,
        *,
        provider: AIProvider,
        store: ConversationStore,
        tools: ToolRegistry,
        context_limit: int = 12,
        logger: logging.Logger | None = None,
        events: EventBus | None = None,
        semantic_provider: SemanticProvider | None = None,
        semantic_timeout_seconds: float = 4.0,
        reference_ttl_turns: int = 3,
        clarification_ttl_turns: int = 2,
        program_directory: ProgramDirectory | None = None,
    ) -> None:
        self.provider = provider
        self.store = store
        self.tools = tools
        self.context_limit = max(2, context_limit)
        self.program_directory = program_directory or ProgramDirectory.static()
        self.router = LocalIntentRouter(directory=self.program_directory)
        self.logger = logger or logging.getLogger("nesk")
        self.events = events or EventBus()
        self._lock = RLock()
        self._pending: PendingAction | None = None
        # Remaining selections from a narrowly-approved clarification batch.
        # This is never populated from provider text or arbitrary tool lists.
        self._pending_batch: PendingBatch | None = None
        self._pending_program_group: PendingProgramGroup | None = None
        self._pending_program_open: PendingProgramOpenResolution | None = None
        self.session_context = SessionContext(
            directory=self.program_directory,
            reference_ttl_turns=reference_ttl_turns,
            clarification_ttl_turns=clarification_ttl_turns,
        )
        self.resolver = IntentResolutionCoordinator(
            tools=tools,
            context=self.session_context,
            directory=self.program_directory,
        )
        self.semantic_provider = semantic_provider or NullSemanticProvider()
        self.semantic_timeout_seconds = max(0.1, float(semantic_timeout_seconds))
        self._semantic_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="nesk-semantic")
        self._semantic_cancellations: dict[int, Event] = {}
        self._turn_generation = 0
        self._closed = False
        # Session conversation is independent from semantic references.  It is
        # retained for the pre-existing conversational provider behavior only;
        # SessionContext above is never loaded from or stored in SQLite.
        self._session: deque[Message] = deque(maxlen=self.context_limit)
        for message in self.store.recent(self.context_limit):
            self._session.append(message)

    def _remember_session(self, message: Message) -> None:
        self._session.append(message)
        self.store.add(message)

    def _run_intent(self, intent: Intent, *, confirmed: bool = False) -> AssistantResult:
        # Confidence becomes important once model-based resolvers are added.
        # Semantic candidates in the intermediate band become clarifications in
        # IntentResolutionCoordinator and therefore never arrive here.
        if not confirmed and intent.confidence < 0.70:
            return AssistantResult(
                "Não tenho confiança suficiente para executar isso. Pode reformular o pedido?",
                action="intent.rejected",
                metadata={"confidence": intent.confidence},
            )
        if not confirmed and intent.confidence < 0.90:
            label = str(intent.args.get("display_name") or intent.args.get("name") or intent.tool_name)
            prompt = f"Acho que entendi, mas quero confirmar: você quer que eu execute isso em {label}?"
            self._pending = PendingAction(intent=intent, prompt=prompt)
            return AssistantResult(
                prompt,
                action="confirmation.requested",
                metadata={"pending_tool": intent.tool_name, "reason": "confidence"},
            )

        self.logger.info(
            "intent_resolved tool=%s source=%s confidence=%.2f",
            intent.tool_name,
            intent.source.value,
            intent.confidence,
        )
        self.events.publish(
            "intent.resolved",
            tool=intent.tool_name,
            source=intent.source.value,
            confidence=intent.confidence,
        )
        tool_result = self.tools.execute(intent.tool_name, confirmed=confirmed, **intent.args)
        data = tool_result.data or {}
        if data.get("needs_confirmation") and not confirmed:
            label = str(intent.args.get("display_name") or intent.args.get("name") or "essa ação")
            if intent.tool_name == "programs.close":
                prompt = f"Você quer mesmo que eu feche {label}?"
            else:
                prompt = f"Essa ação pode alterar o estado do computador. Quer confirmar a ação em {label}?"
            self._pending = PendingAction(intent=intent, prompt=prompt)
            self.events.publish("action.confirmation_requested", tool=intent.tool_name)
            return AssistantResult(prompt, action="confirmation.requested", metadata={"pending_tool": intent.tool_name})

        if tool_result.ok:
            self.session_context.record_success(intent, tool_result)
        self.events.publish("tool.completed", tool=intent.tool_name, ok=tool_result.ok)
        return AssistantResult(
            tool_result.message,
            action=intent.tool_name,
            metadata={**data, "tool_ok": tool_result.ok},
        )

    def _canonical_program_group_ids(
        self,
        intents: tuple[Intent, ...],
        *,
        allowed_tools: frozenset[str],
    ) -> tuple[str, ...]:
        """Validate the one narrow two-program batch shape used by Core.

        This is not a generic Tool batch validator.  It accepts exactly two
        current ProgramDirectory identities and only the specific program
        action families passed by the trusted caller.
        """

        if len(intents) != 2 or any(intent.tool_name not in allowed_tools for intent in intents):
            return ()
        identifiers: list[str] = []
        for intent in intents:
            identifier = str(intent.args.get("name") or "").strip().lower()
            entry = self.program_directory.entry(identifier)
            if entry is None or entry.identifier != identifier or identifier in identifiers:
                return ()
            identifiers.append(identifier)
        return tuple(identifiers)

    @staticmethod
    def _batch_result(results: list[AssistantResult], total: int) -> AssistantResult:
        """Aggregate individual tool outcomes without claiming all succeeded."""

        succeeded = [result for result in results if result.metadata.get("tool_ok") is True]
        # A result that did not reach a successful ToolRegistry completion
        # (for example a confidence rejection) must not disappear from a
        # multi-select report as though it had neither succeeded nor failed.
        failed = [result for result in results if result.metadata.get("tool_ok") is not True]
        messages = " ".join(result.text for result in results)
        metadata = {
            "selected": total,
            "completed": len(results),
            "succeeded": len(succeeded),
            "failed": len(failed),
        }
        if len(succeeded) == total:
            return AssistantResult(
                f"Concluí as {total} ações selecionadas. {messages}",
                action="clarification.batch.completed",
                metadata=metadata,
            )
        if succeeded:
            return AssistantResult(
                f"Concluí {len(succeeded)} de {total} ações; as demais não foram concluídas. {messages}",
                action="clarification.batch.partial",
                metadata=metadata,
            )
        return AssistantResult(
            f"Não consegui concluir as {total} ações selecionadas. {messages}",
            action="clarification.batch.failed",
            metadata=metadata,
        )

    def _run_clarification_batch(
        self,
        intents: tuple[Intent, ...],
        *,
        selected_total: int | None = None,
        prior_results: tuple[AssistantResult, ...] = (),
        program_group_ids: tuple[str, ...] | None = None,
    ) -> AssistantResult:
        """Run each prevalidated Intent via the normal Core/Registry boundary.

        The method accepts only the tuple produced by a pending clarification.
        It intentionally stops at an individual confirmation request; selection
        of multiple safe options is not global permission for a later action.
        """

        results = list(prior_results)
        total = selected_total if selected_total is not None else len(results) + len(intents)
        if program_group_ids is None:
            program_group_ids = self._canonical_program_group_ids(
                intents,
                allowed_tools=frozenset({"programs.open"}),
            )
            # An incoming approved multi-open selection supersedes an older
            # plural antecedent even if one member later fails or is cancelled.
            if program_group_ids:
                self.session_context.clear_recent_program_group()
        for index, intent in enumerate(intents):
            result = self._run_intent(intent)
            if result.action == "confirmation.requested":
                self._pending_batch = PendingBatch(
                    selected_total=total,
                    completed=tuple(results),
                    remaining=intents[index + 1 :],
                    program_group_ids=program_group_ids,
                )
                if not results:
                    return result
                succeeded = sum(item.metadata.get("tool_ok") is True for item in results)
                prefix = f"Já processei {len(results)} de {total} ações ({succeeded} concluídas); "
                return AssistantResult(
                    prefix + result.text,
                    action="confirmation.requested",
                    metadata={
                        **result.metadata,
                        "selected": total,
                        "completed_before_confirmation": len(results),
                        "succeeded_before_confirmation": succeeded,
                    },
                )
            results.append(result)
        self._pending_batch = None
        complete = self._batch_result(results, total)
        if program_group_ids:
            if len(results) == total and all(result.metadata.get("tool_ok") is True for result in results):
                self.session_context.record_program_group(program_group_ids)
            else:
                self.session_context.clear_recent_program_group()
        return complete

    @staticmethod
    def _program_group_result(results: list[AssistantResult], total: int) -> AssistantResult:
        """Report a locally reconstructed plural reference without overclaiming."""

        succeeded = [result for result in results if result.metadata.get("tool_ok") is True]
        failed = [result for result in results if result.metadata.get("tool_ok") is not True]
        messages = " ".join(result.text for result in results)
        metadata = {
            "selected": total,
            "completed": len(results),
            "succeeded": len(succeeded),
            "failed": len(failed),
        }
        if len(succeeded) == total:
            return AssistantResult(
                f"Concluí as {total} ações solicitadas. {messages}",
                action="program_group.completed",
                metadata=metadata,
            )
        if succeeded:
            return AssistantResult(
                f"Concluí {len(succeeded)} de {total} ações solicitadas; as demais não foram concluídas. {messages}",
                action="program_group.partial",
                metadata=metadata,
            )
        return AssistantResult(
            f"Não consegui concluir as {total} ações solicitadas. {messages}",
            action="program_group.failed",
            metadata=metadata,
        )

    def _run_program_group(
        self,
        intents: tuple[Intent, ...],
        *,
        prior_results: tuple[AssistantResult, ...] = (),
        total: int = 2,
    ) -> AssistantResult:
        """Execute exactly the Core-rebuilt two-program plural reference.

        The resolver is the only producer of this tuple.  This method verifies
        the narrow shape again and invokes ``_run_intent`` per member, keeping
        registry and permission checks independent for every close/open.
        """

        if not prior_results:
            identifiers = self._canonical_program_group_ids(
                intents,
                allowed_tools=frozenset({"programs.open", "programs.close"}),
            )
            if not identifiers or len({intent.tool_name for intent in intents}) != 1:
                return AssistantResult(
                    "Não tenho mais um grupo de programas válido para essa ação.",
                    action="program_group.invalid",
                )
            # This is a one-shot antecedent.  Consume it as soon as the
            # narrowly validated plural operation starts, rather than relying
            # on a later successful ToolResult to clear it.  The reconstructed
            # canonical Intents remain in this local stack/pending state, but a
            # failed or cancelled group can never be blindly replayed.
            self.session_context.clear_recent_program_group()

        results = list(prior_results)
        for index, intent in enumerate(intents):
            result = self._run_intent(intent)
            if result.action == "confirmation.requested":
                self._pending_program_group = PendingProgramGroup(
                    completed=tuple(results),
                    remaining=intents[index + 1 :],
                )
                if not results:
                    return result
                succeeded = sum(item.metadata.get("tool_ok") is True for item in results)
                return AssistantResult(
                    f"Já processei {len(results)} de {total} ações ({succeeded} concluídas); {result.text}",
                    action="confirmation.requested",
                    metadata={
                        **result.metadata,
                        "selected": total,
                        "completed_before_confirmation": len(results),
                        "succeeded_before_confirmation": succeeded,
                    },
                )
            results.append(result)
        self._pending_program_group = None
        return self._program_group_result(results, total)

    @staticmethod
    def _unknown_program_item_text(label: str | None) -> str:
        if label:
            return f"Não reconheço o programa '{label}' neste computador."
        return "Não reconheci um programa seguro nesse pedido."

    def _program_open_resolution_result(
        self,
        resolution: ProgramOpenResolution,
        completed: tuple[tuple[int, AssistantResult], ...],
    ) -> AssistantResult:
        """Compose ordered, honest output for a closed local open resolution."""

        by_index = dict(completed)
        messages: list[str] = []
        for index, item in enumerate(resolution.items):
            if item.intent is not None:
                result = by_index.get(index)
                if result is not None:
                    messages.append(result.text)
            elif item.unknown is not None:
                messages.append(self._unknown_program_item_text(item.unknown.label))
            elif item.invalid:
                messages.append(self._unknown_program_item_text(None))

        known_total = len(resolution.known_intents)
        tool_results = tuple(result for _index, result in completed)
        succeeded = sum(result.metadata.get("tool_ok") is True for result in tool_results)
        failed = len(tool_results) - succeeded
        metadata = {
            "known": known_total,
            "completed": len(tool_results),
            "succeeded": succeeded,
            "failed": failed,
            "unrecognized": len(resolution.unknown_targets),
            "invalid": resolution.invalid_count,
        }
        text = " ".join(messages) or self._unknown_program_item_text(None)
        if known_total == 0:
            return AssistantResult(text, action="programs.open.unrecognized", metadata=metadata)
        if succeeded == known_total and failed == 0:
            if metadata["unrecognized"] or metadata["invalid"]:
                return AssistantResult(text, action="programs.open.partial", metadata=metadata)
            return AssistantResult(text, action="programs.open.completed", metadata=metadata)
        if succeeded:
            return AssistantResult(
                f"Abri {succeeded} de {known_total} programas reconhecidos; os demais não foram concluídos. {text}",
                action="programs.open.partial",
                metadata=metadata,
            )
        return AssistantResult(
            f"Não consegui abrir os programas reconhecidos. {text}",
            action="programs.open.failed",
            metadata=metadata,
        )

    def _run_program_open_resolution(
        self,
        resolution: ProgramOpenResolution,
        *,
        completed: tuple[tuple[int, AssistantResult], ...] = (),
        remaining: tuple[tuple[int, Intent], ...] | None = None,
    ) -> AssistantResult:
        """Run only canonical entries in a local known/unknown opening plan."""

        work = remaining
        if work is None:
            work = tuple(
                (index, item.intent)
                for index, item in enumerate(resolution.items)
                if item.intent is not None
            )
        results = list(completed)
        for position, intent in work:
            result = self._run_intent(intent)
            if result.action == "confirmation.requested":
                self._pending_program_open = PendingProgramOpenResolution(
                    resolution=resolution,
                    completed=tuple(results),
                    active_index=position,
                    remaining=tuple((index, value) for index, value in work if index > position),
                )
                if not results:
                    return result
                succeeded = sum(item.metadata.get("tool_ok") is True for _index, item in results)
                return AssistantResult(
                    f"Já processei {len(results)} abertura(s) reconhecida(s) ({succeeded} concluída(s)); {result.text}",
                    action="confirmation.requested",
                    metadata={
                        **result.metadata,
                        "completed_before_confirmation": len(results),
                        "succeeded_before_confirmation": succeeded,
                    },
                )
            results.append((position, result))
        self._pending_program_open = None
        return self._program_open_resolution_result(resolution, tuple(results))

    def _cancel_program_open_resolution(self, pending: PendingProgramOpenResolution) -> AssistantResult:
        completed = pending.completed
        completed_messages = [result.text for _index, result in completed]
        unknown_messages = [
            self._unknown_program_item_text(item.unknown.label)
            for item in pending.resolution.items
            if item.unknown is not None
        ]
        if pending.resolution.invalid_count:
            unknown_messages.append(self._unknown_program_item_text(None))
        messages = " ".join((*completed_messages, *unknown_messages))
        succeeded = sum(result.metadata.get("tool_ok") is True for _index, result in completed)
        failed = len(completed) - succeeded
        prefix = "Cancelei a abertura pendente e as restantes."
        if messages:
            prefix += f" {messages}"
        return AssistantResult(
            prefix,
            action="confirmation.cancelled",
            metadata={
                "known": len(pending.resolution.known_intents),
                "completed": len(completed),
                "succeeded": succeeded,
                "failed": failed,
                "cancelled": len(pending.remaining) + 1,
                "unrecognized": len(pending.resolution.unknown_targets),
                "invalid": pending.resolution.invalid_count,
            },
        )

    @staticmethod
    def _cancel_pending_batch(batch: PendingBatch) -> AssistantResult:
        succeeded = sum(item.metadata.get("tool_ok") is True for item in batch.completed)
        failed = sum(item.metadata.get("tool_ok") is not True for item in batch.completed)
        if not batch.completed:
            text = "Beleza, cancelei as ações selecionadas antes de executar qualquer uma."
        else:
            text = (
                "Beleza, cancelei a ação pendente e as restantes. "
                f"{succeeded} de {batch.selected_total} ações já foram concluídas; "
                f"{failed} falharam e {len(batch.remaining) + 1} não foram executadas."
            )
        return AssistantResult(
            text,
            action="confirmation.cancelled",
            metadata={
                "selected": batch.selected_total,
                "completed": len(batch.completed),
                "succeeded": succeeded,
                "failed": failed,
                "cancelled": len(batch.remaining) + 1,
            },
        )

    @staticmethod
    def _safety_answer(reason: str | None) -> str:
        if reason == "negation":
            return "Beleza. Entendi a negação e não executei nenhuma ação."
        if reason == "how_to":
            return "Entendi isso como uma pergunta, não como um comando, então não executei nada."
        return "Entendi isso como conversa ou hipótese, não como um pedido direto. Não executei nenhuma ação."

    def _remember_result(self, result: AssistantResult) -> AssistantResult:
        self._remember_session(Message(Role.ASSISTANT, result.text))
        return result

    def _apply_resolution(self, resolution: IntentResolution) -> AssistantResult | None:
        if resolution.program_group_intents:
            return self._remember_result(self._run_program_group(resolution.program_group_intents))
        if resolution.program_open is not None:
            return self._remember_result(self._run_program_open_resolution(resolution.program_open))
        if resolution.intent is not None:
            return self._remember_result(self._run_intent(resolution.intent))
        if resolution.clarification is not None:
            self.session_context.begin_clarification(resolution.clarification)
            self.events.publish("clarification.requested", option_count=len(resolution.clarification.options))
            return self._remember_result(
                AssistantResult(
                    resolution.clarification.prompt,
                    action="clarification.requested",
                    metadata={"option_count": len(resolution.clarification.options)},
                )
            )
        if resolution.safety_blocked:
            self.events.publish("intent.blocked", reason=resolution.reason or "unsafe_modality")
            return self._remember_result(AssistantResult(self._safety_answer(resolution.reason)))
        return None

    def _handle_pending_action(self, clean: str) -> AssistantResult | None:
        if self._pending is None:
            return None
        decision = classify_confirmation(clean)
        if decision is ConfirmationDecision.CONFIRM:
            pending = self._pending
            self._pending = None
            confirmed_result = self._run_intent(pending.intent, confirmed=True)
            program_open = self._pending_program_open
            if program_open is not None:
                self._pending_program_open = None
                return self._remember_result(
                    self._run_program_open_resolution(
                        program_open.resolution,
                        completed=(*program_open.completed, (program_open.active_index, confirmed_result)),
                        remaining=program_open.remaining,
                    )
                )
            program_group = self._pending_program_group
            if program_group is not None:
                self._pending_program_group = None
                return self._remember_result(
                    self._run_program_group(
                        program_group.remaining,
                        prior_results=(*program_group.completed, confirmed_result),
                    )
                )
            batch = self._pending_batch
            if batch is not None:
                self._pending_batch = None
                return self._remember_result(
                    self._run_clarification_batch(
                        batch.remaining,
                        selected_total=batch.selected_total,
                        prior_results=(*batch.completed, confirmed_result),
                        program_group_ids=batch.program_group_ids,
                    )
                )
            return self._remember_result(confirmed_result)
        if decision is ConfirmationDecision.CANCEL:
            self._pending = None
            program_open = self._pending_program_open
            self._pending_program_open = None
            if program_open is not None:
                self.events.publish("action.cancelled")
                return self._remember_result(self._cancel_program_open_resolution(program_open))
            program_group = self._pending_program_group
            self._pending_program_group = None
            if program_group is not None:
                self.events.publish("action.cancelled")
                total = len(program_group.completed) + len(program_group.remaining) + 1
                succeeded = sum(item.metadata.get("tool_ok") is True for item in program_group.completed)
                failed = len(program_group.completed) - succeeded
                return self._remember_result(
                    AssistantResult(
                        (
                            "Beleza, cancelei a ação pendente e as restantes do grupo. "
                            f"{succeeded} de {total} ações já foram concluídas; "
                            f"{failed} falharam e {len(program_group.remaining) + 1} não foram executadas."
                        ),
                        action="confirmation.cancelled",
                        metadata={
                            "selected": total,
                            "completed": len(program_group.completed),
                            "succeeded": succeeded,
                            "failed": failed,
                            "cancelled": len(program_group.remaining) + 1,
                        },
                    )
                )
            batch = self._pending_batch
            self._pending_batch = None
            if batch is not None:
                if batch.program_group_ids:
                    self.session_context.clear_recent_program_group()
                self.events.publish("action.cancelled")
                return self._remember_result(self._cancel_pending_batch(batch))
            answer = "Beleza, cancelei essa ação."
            self.events.publish("action.cancelled")
            return self._remember_result(AssistantResult(answer, action="confirmation.cancelled"))
        if decision is ConfirmationDecision.AMBIGUOUS:
            answer = (
                "Não vou executar enquanto a confirmação estiver ambígua. "
                "Responda de forma clara com algo como 'sim' ou 'não'."
            )
            self.events.publish(
                "action.confirmation_ambiguous",
                tool=self._pending.intent.tool_name,
            )
            return self._remember_result(
                AssistantResult(
                    answer,
                    action="confirmation.ambiguous",
                    metadata={"pending_tool": self._pending.intent.tool_name},
                )
            )
        # A new unrelated request cancels a stale permission prompt instead of
        # accidentally authorizing it later.
        self._pending = None
        self._pending_batch = None
        self._pending_program_group = None
        self._pending_program_open = None
        self.events.publish("action.confirmation_expired")
        return None

    def _handle_pending_clarification(self, clean: str) -> AssistantResult | None:
        pending = self.session_context.pending_clarification
        if pending is None:
            return None
        reply = self.session_context.consume_clarification(clean)
        if reply.decision is ClarificationDecision.SELECTED and reply.selected_intents:
            intents = reply.selected_intents
            if len(intents) == 1:
                return self._remember_result(self._run_intent(intents[0]))
            return self._remember_result(self._run_clarification_batch(intents))
        if reply.decision is ClarificationDecision.CANCELLED:
            self.events.publish("clarification.cancelled")
            return self._remember_result(AssistantResult("Beleza, cancelei esse pedido.", action="clarification.cancelled"))
        if reply.decision is ClarificationDecision.AMBIGUOUS:
            return self._remember_result(
                AssistantResult(
                    "Ainda preciso de uma opção específica. Diga o nome, 'a primeira', 'a segunda' ou 'não'.",
                    action="clarification.ambiguous",
                )
            )
        if reply.decision is ClarificationDecision.UNRELATED and pending.request.target_kind == "program":
            # A named, non-action reply to "qual programa?" is still local
            # semantic input.  Give an explicit unknown-program answer rather
            # than leaking it into conversational fallback or a provider.
            resolution = self.resolver.resolve_program_clarification_reply(clean)
            if resolution is not None:
                result = self._apply_resolution(resolution)
                if result is not None:
                    return result
        if reply.decision is ClarificationDecision.EXPIRED:
            self.events.publish("clarification.expired")
        # UNRELATED and EXPIRED deliberately fall through: the current input
        # is now handled as a new request and cannot revive the old question.
        return None

    def _new_request_after_clarification_cancel(self, text: str) -> str | None:
        """Allow an explicit dismissal followed by a new command in one turn.

        The prefix is recognized only while a clarification exists and only
        when punctuation separates it from a new request.  This keeps ordinary
        uses of these words outside clarification from gaining command meaning.
        """

        match = re.match(
            r"^\s*(?:deixa|esquece|cancela)(?:\s+isso)?\s*[,;:]\s*(?P<request>.+?)\s*$",
            text,
            flags=re.IGNORECASE,
        )
        if not match:
            return None
        return match.group("request")

    def _conversation_fallback(self) -> AssistantResult:
        try:
            answer = self.provider.reply(list(self._session))
        except Exception as exc:  # Provider failures must not kill the desktop process.
            self.logger.exception("provider_error type=%s", type(exc).__name__)
            answer = "Meu provider de IA falhou agora, mas o NESK continua rodando. Verifique a conexão/configuração e tente novamente."
        return self._remember_result(AssistantResult(answer))

    def _interpret_semantic(self, request: SemanticRequest, cancel: Event) -> tuple[SemanticCandidate | None, bool]:
        try:
            future = self._semantic_executor.submit(self.semantic_provider.interpret, request, cancel=cancel)
            return future.result(timeout=self.semantic_timeout_seconds), False
        except FutureTimeout:
            cancel.set()
            self.events.publish("semantic.provider_timeout")
            self.logger.warning("semantic_provider_timeout")
            return None, True
        except Exception as exc:
            self.events.publish("semantic.provider_unavailable", error_type=type(exc).__name__)
            self.logger.warning("semantic_provider_error type=%s", type(exc).__name__)
        return None, False

    def _begin_turn(self, clean: str) -> int:
        self._turn_generation += 1
        # A new request supersedes any remote semantic interpretation that has
        # not yet reached the Core.  Providers that support cooperative
        # cancellation can stop immediately; all others are still discarded by
        # the generation check before execution.
        for generation, cancel in tuple(self._semantic_cancellations.items()):
            if generation < self._turn_generation:
                cancel.set()
        self.session_context.advance_turn()
        self._remember_session(Message(Role.USER, clean))
        # Do not log message contents by default.
        self.logger.info("user_message_received chars=%d", len(clean))
        return self._turn_generation

    def handle(self, text: str) -> AssistantResult:
        clean = text.strip()
        if not clean:
            return AssistantResult("Fala alguma coisa pra mim primeiro.")

        semantic_request: SemanticRequest | None = None
        semantic_cancel: Event | None = None
        ticket = 0
        request_text = clean
        with self._lock:
            if self._closed:
                return AssistantResult("O NESK está sendo encerrado.", action="runtime.closed")
            ticket = self._begin_turn(clean)

            pending_result = self._handle_pending_action(clean)
            if pending_result is not None:
                return pending_result
            if self.session_context.pending_clarification is not None:
                replacement = self._new_request_after_clarification_cancel(clean)
                if replacement is not None:
                    self.session_context.invalidate_clarification()
                    self.events.publish("clarification.cancelled")
                    request_text = replacement
                else:
                    pending_result = self._handle_pending_clarification(clean)
                    if pending_result is not None:
                        return pending_result

            resolution = self.resolver.resolve_local(request_text, self.router.route(request_text))
            result = self._apply_resolution(resolution)
            if result is not None:
                return result
            if not resolution.needs_provider:
                return self._conversation_fallback()

            # The remote call happens outside the Core lock.  A later turn or a
            # shutdown invalidates this ticket before any candidate can reach a
            # ToolRegistry.
            semantic_request = self.resolver.request_for_provider(request_text)
            semantic_cancel = Event()
            self._semantic_cancellations[ticket] = semantic_cancel

        assert semantic_request is not None and semantic_cancel is not None
        candidate, timed_out = self._interpret_semantic(semantic_request, semantic_cancel)

        with self._lock:
            self._semantic_cancellations.pop(ticket, None)
            if self._closed:
                return AssistantResult("O NESK está sendo encerrado.", action="runtime.closed")
            if ticket != self._turn_generation or (semantic_cancel.is_set() and not timed_out):
                # A worker may finish after another input/close.  Returning a
                # non-executing result is safe; its late candidate is discarded.
                return AssistantResult("Essa solicitação foi substituída por uma mais recente.", action="intent.stale")

            resolution = self.resolver.resolve_provider_candidate(request_text, candidate)
            result = self._apply_resolution(resolution)
            if result is not None:
                return result
            return self._conversation_fallback()

    def close(self) -> None:
        """Invalidate semantic work and release providers without executing late results."""

        with self._lock:
            if self._closed:
                return
            self._closed = True
            self._turn_generation += 1
            cancellations = tuple(self._semantic_cancellations.values())
            self._semantic_cancellations.clear()
            self._pending_batch = None
            self._pending_program_group = None
            self._pending_program_open = None
            self.session_context.invalidate_clarification()
            # Session context is RAM-only, but clear its narrow plural
            # antecedent explicitly during logical shutdown as well.  This
            # keeps lifecycle behavior auditable even if a caller retains the
            # closed Core object for diagnostics.
            self.session_context.clear_recent_program_group()
        for cancel in cancellations:
            cancel.set()
        self._semantic_executor.shutdown(wait=False, cancel_futures=True)
        for provider in (self.semantic_provider, self.provider):
            try:
                provider.close()
            except Exception as exc:
                self.logger.warning("core_provider_close_error type=%s", type(exc).__name__)

    def cancel_inflight_semantic(self) -> None:
        """Cooperatively cancel a pending semantic provider request.

        VoiceService calls this before taking its lifecycle lock, so a UI
        cancel/close can invalidate a remote semantic turn even while the
        post-STT handoff is waiting for that bounded provider call.  This method
        never cancels or bypasses an already executing ToolRegistry action.
        """

        with self._lock:
            if self._closed or not self._semantic_cancellations:
                return
            self._turn_generation += 1
            cancellations = tuple(self._semantic_cancellations.values())
        for cancel in cancellations:
            cancel.set()
        self.events.publish("semantic.cancelled")

    @property
    def pending_action(self) -> PendingAction | None:
        return self._pending

    @property
    def pending_clarification(self):
        return self.session_context.pending_clarification
