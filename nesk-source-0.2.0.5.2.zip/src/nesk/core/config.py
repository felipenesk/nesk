from __future__ import annotations

import json
import os
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


_CONFIG_VERSION = 10

DEFAULTS: dict[str, Any] = {
    "_config_version": _CONFIG_VERSION,
    "ai": {
        "provider": "local",
        "model": "gpt-5.6",
        "recent_context_messages": 12,
        "fallback_to_local": True,
    },
    "semantic": {
        # Local composition/context remains available without any model.  A
        # remote provider is explicitly opt-in and never inherits ai.provider.
        "provider": "none",
        "allow_remote": False,
        "model": "gpt-5.6",
        "timeout_seconds": 4.0,
        "reference_ttl_turns": 3,
        "clarification_ttl_turns": 2,
    },
    "privacy": {
        "mode": "hybrid",
        "store_conversations": True,
        "log_message_content": False,
        "store_audio": False,
        "automatic_memory": False,
    },
    "ui": {
        "minimize_to_tray": True,
        "system_refresh_ms": 2500,
        "theme": "monochrome",
    },
    "voice": {
        "enabled": True,
        "mode": "push_to_talk",
        "wake_word": "NESK",
        "capture": {
            "device": None,
            "sample_rate": None,
            "min_seconds": 0.12,
            "max_seconds": 12.0,
            "startup_timeout_ms": 750,
            "post_roll_ms": 160,
            "block_ms": 20,
            "latency": "low",
            "endpoint_speech_rms_dbfs": -60.0,
            "endpoint_silence_ms": 650,
            "endpoint_min_speech_ms": 120,
        },
        "stt": {
            "provider": "local",
            "language": "pt",
            "local_model": "small",
            "device": "cpu",
            "compute_type": "int8",
            "cpu_threads": 0,
            "beam_size": 5,
            "patience": 1.0,
            "log_prob_threshold": -1.0,
            "no_speech_threshold": 0.80,
            "compression_ratio_threshold": 2.6,
            "initial_prompt": "Português brasileiro. Transcreva apenas a fala ou retorne vazio.",
            "hotwords": [
                "NESK", "YouTube", "Google", "Discord", "Minecraft", "Valorant",
                "ChatGPT", "Claude", "Gmail", "WhatsApp", "Twitch", "Reddit",
            ],
            "vad_filter": True,
            "vad_threshold": 0.5,
            "vad_min_speech_ms": 100,
            "vad_min_silence_ms": 500,
            "vad_speech_pad_ms": 180,
            "max_new_tokens": 64,
            "cloud_model": "gpt-4o-mini-transcribe",
        },
        "store_audio": False,
        "speaker_verification": False,
        "speaker_threshold": 0.82,
    },
    "offline": {
        "enabled": True,
        "prefer_local_tools": True,
    },
    "programs": {},
}


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def data_dir() -> Path:
    override = os.getenv("NESK_DATA_DIR")
    if override:
        return Path(override).expanduser().resolve()
    local = os.getenv("LOCALAPPDATA")
    if local:
        return Path(local) / "NESK"
    return Path.home() / ".nesk"


def _safe_config_for_disk(config: dict[str, Any]) -> dict[str, Any]:
    """Return only normal configuration; runtime credentials never belong here."""
    safe = deepcopy(config)
    # Future connectors/providers may add runtime credential-shaped fields.
    for section in safe.values():
        if isinstance(section, dict):
            for key in list(section):
                lowered = key.lower()
                if any(token in lowered for token in ("api_key", "token", "password", "secret")):
                    section.pop(key, None)
    safe["_config_version"] = _CONFIG_VERSION
    return safe


def load_config() -> tuple[dict[str, Any], Path]:
    root = data_dir()
    root.mkdir(parents=True, exist_ok=True)
    path = root / "config.json"

    loaded: dict[str, Any] = {}
    rewrite = not path.exists()
    if path.exists():
        try:
            candidate = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(candidate, dict):
                loaded = candidate
            else:
                rewrite = True
        except (json.JSONDecodeError, OSError):
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            backup = root / f"config.corrupt.{stamp}.json"
            try:
                path.replace(backup)
            except OSError:
                pass
            rewrite = True

    loaded_version = int(loaded.get("_config_version", 0) or 0)
    if loaded_version < 3:
        # Voice was only a disabled architectural placeholder in 0.1.x, so
        # enabling First Listen here cannot override a previously functional
        # user voice preference. All privacy/audio-storage defaults stay intact.
        loaded.setdefault("voice", {})["enabled"] = True
        rewrite = True

    if loaded_version < 9:
        # 0.2.0.5.2 replaces stacked silence gates, gain/edge trimming and
        # alternate command decodes with one shared pre-Core pipeline. Retain
        # provider/model/device choices, but remove inactive hotfix knobs so a
        # migrated config tells the truth about the runtime policy.
        loaded_voice = loaded.get("voice")
        capture = loaded_voice.get("capture") if isinstance(loaded_voice, dict) else None
        if isinstance(capture, dict):
            for key in (
                "silence_rms_dbfs",
                "silence_peak_dbfs",
                "minimum_signal_rms_dbfs",
                "minimum_signal_peak_dbfs",
            ):
                capture.pop(key, None)
        stt = loaded_voice.get("stt") if isinstance(loaded_voice, dict) else None
        if isinstance(stt, dict):
            for key in (
                "repetition_penalty",
                "no_repeat_ngram_size",
                "word_timestamps",
                "hallucination_silence_threshold",
                "quality_min_avg_logprob",
                "quality_max_no_speech_prob",
                "quality_max_compression_ratio",
                "short_retry_enabled",
                "short_retry_max_words",
                "short_retry_logprob",
                "short_initial_prompt",
                "short_hotwords",
                "command_retry_enabled",
                "command_retry_logprob",
                "command_retry_max_words",
                "command_retry_min_improvement",
                "command_ambiguity_margin",
                "command_initial_prompt",
                "command_hotwords",
                "frontend_enabled",
                "frontend_trim_enabled",
                "frontend_normalize_enabled",
                "frontend_pad_ms",
                "frontend_target_rms_dbfs",
                "frontend_max_gain_db",
            ):
                stt.pop(key, None)
        rewrite = True

    if loaded_version < 10:
        # The semantic context layer is runtime-only; migration only writes its
        # safe opt-in defaults and intentionally preserves all prior AI, voice,
        # privacy and program preferences.
        rewrite = True

    config = _deep_merge(DEFAULTS, loaded)
    if loaded_version < _CONFIG_VERSION:
        rewrite = True
    config["_config_version"] = _CONFIG_VERSION

    # Runtime-only overrides. These values are intentionally not persisted below.
    config["ai"]["provider"] = os.getenv("NESK_AI_PROVIDER", config["ai"]["provider"])
    config["ai"]["model"] = os.getenv("NESK_OPENAI_MODEL", config["ai"]["model"])
    config["semantic"]["provider"] = os.getenv(
        "NESK_SEMANTIC_PROVIDER", config["semantic"]["provider"]
    )
    semantic_remote = os.getenv("NESK_SEMANTIC_ALLOW_REMOTE")
    if semantic_remote is not None:
        config["semantic"]["allow_remote"] = semantic_remote.strip().lower() in {"1", "true", "yes", "on"}

    if rewrite:
        disk_config = _safe_config_for_disk(_deep_merge(DEFAULTS, loaded))
        path.write_text(json.dumps(disk_config, ensure_ascii=False, indent=2), encoding="utf-8")

    return config, root
