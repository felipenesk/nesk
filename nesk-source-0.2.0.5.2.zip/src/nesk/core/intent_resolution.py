from __future__ import annotations

import re
from dataclasses import dataclass, replace

from nesk.core.intent import Intent, IntentSource
from nesk.core.session_context import ClarificationOption, ClarificationRequest, SessionContext
from nesk.nlu.lexicon import SITE_LOOKUP
from nesk.nlu.ptbr import extract_open_platform_search, is_plural_program_reference, normalized_words
from nesk.platform.windows.program_directory import ProgramDirectory, ProgramEntry, ProgramResolutionKind
from nesk.semantic.contracts import SemanticCandidate, SemanticRequest, SemanticSource
from nesk.semantic.local import (
    ExplicitProgramTarget,
    ExplicitProgramTargetKind,
    LocalSemanticInterpreter,
    action_safety_reason,
    classify_explicit_program_open_targets,
    classify_program_name_reply,
    is_reference_target,
    looks_like_action_request,
)
from nesk.tools.registry import ToolRegistry


_SEMANTIC_ACTIONS = frozenset(
    {
        "programs.open",
        "programs.close",
        "browser.open_default",
        "browser.open_named",
        "browser.search",
    }
)
_SEARCH_ENGINES = frozenset({"google", "youtube"})
_SITES = frozenset(SITE_LOOKUP.values())
_PATH_OR_URL = re.compile(r"(?:^[a-z]:[\\/]|://|[\\/])", re.IGNORECASE)
_NON_NAME_REPLY_STARTS = frozenset(
    {"qual", "que", "como", "quem", "onde", "quando", "porque", "por", "oi", "ola", "obrigado", "obrigada"}
)


@dataclass(frozen=True, slots=True)
class IntentResolution:
    """Outcome of the non-executing intent-resolution stage."""

    intent: Intent | None = None
    clarification: ClarificationRequest | None = None
    # Explicit local program-open handling only.  This is intentionally not a
    # generic arbitrary-tool batch and cannot be created by a provider.
    program_open: "ProgramOpenResolution | None" = None
    # Fresh Intents rebuilt from a RAM-only plural program group.  The name is
    # explicit so callers cannot mistake this for a free-form list of tools.
    program_group_intents: tuple[Intent, ...] = ()
    needs_provider: bool = False
    safety_blocked: bool = False
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class UnrecognizedProgramTarget:
    """Safe-to-display local text that never becomes a launch argument."""

    label: str

    def __post_init__(self) -> None:
        if (
            not self.label
            or len(self.label) > 100
            or _PATH_OR_URL.search(self.label)
            or any(ord(character) < 32 for character in self.label)
        ):
            raise ValueError("alvo desconhecido deve ser texto público seguro")


@dataclass(frozen=True, slots=True)
class ProgramOpenItem:
    """One ordered known or non-executable unknown opening target."""

    intent: Intent | None = None
    unknown: UnrecognizedProgramTarget | None = None
    invalid: bool = False

    def __post_init__(self) -> None:
        alternatives = int(self.intent is not None) + int(self.unknown is not None) + int(self.invalid)
        if alternatives != 1:
            raise ValueError("ProgramOpenItem exige exatamente um alvo tipado")
        if self.intent is not None and self.intent.tool_name != "programs.open":
            raise ValueError("ProgramOpenItem aceita somente Intent de abertura de programa")


@dataclass(frozen=True, slots=True)
class ProgramOpenResolution:
    """Closed result of parsing an explicit local ``abre`` request.

    ``items`` preserves user mention order.  Only items with a locally
    canonical ``programs.open`` Intent may reach Core; unknown/invalid entries
    are response-only and cannot contain paths or executable arguments.
    """

    items: tuple[ProgramOpenItem, ...]

    def __post_init__(self) -> None:
        if not self.items:
            raise ValueError("ProgramOpenResolution exige pelo menos um alvo")

    @property
    def known_intents(self) -> tuple[Intent, ...]:
        return tuple(item.intent for item in self.items if item.intent is not None)

    @property
    def unknown_targets(self) -> tuple[UnrecognizedProgramTarget, ...]:
        return tuple(item.unknown for item in self.items if item.unknown is not None)

    @property
    def invalid_count(self) -> int:
        return sum(item.invalid for item in self.items)


def _display_site(value: str) -> str:
    values = {
        "youtube": "YouTube",
        "google": "Google",
        "chatgpt": "ChatGPT",
        "gmail": "Gmail",
        "whatsapp": "WhatsApp",
    }
    return values.get(value, value.replace("_", " ").title())


class IntentResolutionCoordinator:
    """Validate local/semantic candidates before Core execution.

    This is the only adapter from a semantic candidate to the existing Intent
    contract.  It accepts a ToolRegistry solely to reject unregistered action
    names; it has no execution method.  Program identity comes from the shared
    ProgramDirectory, not from an import-time lexical allowlist.
    """

    def __init__(
        self,
        *,
        tools: ToolRegistry,
        context: SessionContext,
        directory: ProgramDirectory | None = None,
    ) -> None:
        self.tools = tools
        self.context = context
        self.directory = directory or context.directory
        self.local_semantic = LocalSemanticInterpreter(directory=self.directory)

    @staticmethod
    def is_action_intent(intent: Intent) -> bool:
        return intent.tool_name in _SEMANTIC_ACTIONS

    def request_for_provider(self, text: str) -> SemanticRequest:
        return SemanticRequest(
            text=text,
            context=self.context.semantic_view_for(text),
            allowed_actions=tuple(sorted(_SEMANTIC_ACTIONS)),
            # Opaque canonical IDs only: executable paths, cache contents and
            # process identities never leave the local directory.
            allowed_programs=self.directory.allowed_programs(),
            allowed_sites=tuple(sorted(_SITES)),
            allowed_search_engines=tuple(sorted(_SEARCH_ENGINES)),
        )

    def resolve_local(self, text: str, routed: Intent | None) -> IntentResolution:
        """Resolve deterministic NLU, context and local semantic wording first."""

        if routed is not None:
            if self.is_action_intent(routed):
                blocked = action_safety_reason(text)
                if blocked is not None:
                    return IntentResolution(safety_blocked=True, reason=blocked)
                contextual = self._resolve_suspicious_local(routed, text)
                if contextual is not None:
                    return contextual
            return IntentResolution(intent=routed)

        blocked = action_safety_reason(text)
        if blocked is not None:
            return IntentResolution(safety_blocked=True, reason=blocked)

        # A platform clause remains a browser-search classification.  For all
        # other direct ``abre`` forms, preserve each explicit target before
        # the legacy mention matcher can discard unknown segments.
        if extract_open_platform_search(text) is None:
            explicit_open = self._resolve_explicit_program_open(text)
            if explicit_open is not None:
                return explicit_open

        candidate = self.local_semantic.interpret(self.request_for_provider(text))
        if candidate is not None:
            resolution = self.resolve_candidate(candidate)
            if (
                resolution.intent
                or resolution.clarification
                or resolution.program_open is not None
                or resolution.program_group_intents
                or resolution.safety_blocked
            ):
                return resolution

        return IntentResolution(
            needs_provider=looks_like_action_request(text, self.directory),
            reason="no_local_match",
        )

    @staticmethod
    def _program_intent(entry: ProgramEntry, *, action: str, source: IntentSource) -> Intent:
        return Intent(
            action,
            {"name": entry.identifier, "display_name": entry.display_name},
            confidence=0.98,
            source=source,
        )

    @staticmethod
    def _unknown_program_notice(labels: tuple[str, ...]) -> str:
        if not labels:
            return "Não reconheci um programa seguro nesse pedido."
        quoted = ", ".join(f"'{label}'" for label in labels)
        if len(labels) == 1:
            return f"Não reconheço o programa {quoted} neste computador."
        return f"Não reconheço estes programas neste computador: {quoted}."

    def _program_open_plan(self, targets: tuple[ExplicitProgramTarget, ...]) -> ProgramOpenResolution:
        """Build an ordered, local-only plan from already classified targets."""

        # A path/URL/shell-like segment makes the complete direct request fail
        # closed.  Do not run an adjacent known program and do not repeat the
        # unsafe text in the response.
        if any(target.kind is ExplicitProgramTargetKind.INVALID for target in targets):
            items: list[ProgramOpenItem] = []
            for target in targets:
                if target.kind is ExplicitProgramTargetKind.UNKNOWN and target.label:
                    items.append(ProgramOpenItem(unknown=UnrecognizedProgramTarget(target.label)))
                elif target.kind is ExplicitProgramTargetKind.INVALID:
                    items.append(ProgramOpenItem(invalid=True))
            return ProgramOpenResolution(tuple(items or (ProgramOpenItem(invalid=True),)))

        items = []
        for target in targets:
            if target.kind is ExplicitProgramTargetKind.KNOWN and target.entry is not None:
                items.append(ProgramOpenItem(intent=self._program_intent(
                    target.entry,
                    action="programs.open",
                    source=IntentSource.SEMANTIC_LOCAL,
                )))
            elif target.kind is ExplicitProgramTargetKind.UNKNOWN and target.label:
                items.append(ProgramOpenItem(unknown=UnrecognizedProgramTarget(target.label)))
        return ProgramOpenResolution(tuple(items))

    def _resolve_explicit_program_open(self, text: str) -> IntentResolution | None:
        parsed = classify_explicit_program_open_targets(text, self.directory)
        if parsed is None:
            return None
        targets = parsed.targets
        # ``abre eles`` is a narrow, linguistically compatible plural
        # reference, not an unknown executable name.  Exact directory lookup
        # above still wins for a real installed app with such a display name;
        # only an otherwise unknown single target can enter the local group
        # resolver.  That resolver reconstructs fresh canonical Intents and
        # returns a clarification when there is no active RAM-only group.
        if (
            len(targets) == 1
            and targets[0].kind is ExplicitProgramTargetKind.UNKNOWN
            and targets[0].label
            and is_plural_program_reference(targets[0].label)
        ):
            return self._resolve_program_group_reference(
                Intent(
                    "programs.open",
                    {"name": targets[0].label},
                    confidence=0.82,
                    source=IntentSource.SEMANTIC_LOCAL,
                )
            )
        if not targets or all(target.kind is ExplicitProgramTargetKind.KNOWN for target in targets):
            # Preserve the existing all-known router/local-semantic flow,
            # including ordered clarification and its approved multi-select.
            return None

        if len(targets) == 1 and targets[0].kind is ExplicitProgramTargetKind.MISSING:
            # Keep legacy local-semantic hints such as ``aquele negócio de
            # conversar`` alive.  The fallback still produces a Core-owned
            # clarification for a bare missing target.
            return None
        if any(target.kind is ExplicitProgramTargetKind.MISSING for target in targets):
            return IntentResolution(clarification=self._target_question("programs.open", "program"))

        has_ambiguity = any(target.kind is ExplicitProgramTargetKind.AMBIGUOUS for target in targets)
        ambiguous_entries: list[ProgramEntry] = []
        if has_ambiguity:
            for target in targets:
                if target.kind is ExplicitProgramTargetKind.KNOWN and target.entry is not None:
                    ambiguous_entries.append(target.entry)
                elif target.kind is ExplicitProgramTargetKind.AMBIGUOUS:
                    ambiguous_entries.extend(target.entries)
        if has_ambiguity:
            unique_ids: list[str] = []
            for entry in ambiguous_entries:
                if entry.identifier not in unique_ids:
                    unique_ids.append(entry.identifier)
            clarification = self._target_question("programs.open", "program", tuple(unique_ids))
            unknown_labels = tuple(target.label for target in targets if target.label)
            if unknown_labels:
                clarification = replace(
                    clarification,
                    prompt=f"{self._unknown_program_notice(unknown_labels)} {clarification.prompt}",
                )
            return IntentResolution(clarification=clarification)

        plan = self._program_open_plan(targets)
        known_count = len(plan.known_intents)
        if known_count > 1:
            # Preserve the prior all-known multi-action UX even when an
            # unknown extra target is present: no multiple known programs open
            # until the Core-owned clarification explicitly selects them.
            options = tuple(str(intent.args["name"]) for intent in plan.known_intents)
            clarification = self._target_question("programs.open", "program", options)
            labels = tuple(target.label for target in plan.unknown_targets)
            if labels:
                clarification = replace(
                    clarification,
                    prompt=f"{self._unknown_program_notice(labels)} {clarification.prompt}",
                )
            return IntentResolution(clarification=clarification)
        return IntentResolution(program_open=plan)

    def resolve_program_clarification_reply(self, text: str) -> IntentResolution | None:
        """Return typed UX for an explicit unknown reply to a program prompt.

        The Core invokes this only after the pending clarification rejected the
        reply as a selection and only for non-action-shaped text.  Known and
        ambiguous values stay out of this shortcut so the existing scoped
        clarification behavior remains authoritative.
        """

        clean = normalized_words(text)
        first = clean.split(maxsplit=1)[0] if clean else ""
        # A pending program question must not reinterpret a new conversational
        # or interrogative turn as a program name.  The original clarification
        # has already been invalidated by SessionContext, so returning None lets
        # the normal local/conversation flow handle this new topic.
        if "?" in text or first in _NON_NAME_REPLY_STARTS or looks_like_action_request(text, self.directory):
            return None
        target = classify_program_name_reply(text, self.directory)
        if target.kind not in {ExplicitProgramTargetKind.UNKNOWN, ExplicitProgramTargetKind.INVALID}:
            return None
        return IntentResolution(program_open=self._program_open_plan((target,)))

    def _resolve_program_group_reference(self, intent: Intent) -> IntentResolution:
        reference = self.context.resolve_program_group_reference(intent)
        if not reference.program_ids:
            return IntentResolution(clarification=self._reference_question(reference.reason, intent.tool_name))

        intents: list[Intent] = []
        seen: set[str] = set()
        for identifier in reference.program_ids:
            entry = self.directory.entry(identifier)
            if entry is None or entry.identifier in seen:
                self.context.clear_recent_program_group()
                return IntentResolution(clarification=self._reference_question("program_group_reference", intent.tool_name))
            seen.add(entry.identifier)
            intents.append(self._program_intent(entry, action=intent.tool_name, source=intent.source))
        # The context API records only a two-program group.  Keep this Core
        # boundary defensive if a future caller corrupts its RAM state.
        if len(intents) != 2:
            self.context.clear_recent_program_group()
            return IntentResolution(clarification=self._reference_question("program_group_reference", intent.tool_name))
        return IntentResolution(program_group_intents=tuple(intents))

    def _resolve_suspicious_local(self, intent: Intent, text: str) -> IntentResolution | None:
        if intent.tool_name in {"programs.open", "programs.close"}:
            # Defensive layer for legacy/local callers: no text resembling an
            # entity-on-platform may reach a program tool even if a future
            # router accidentally emits a raw programs.open Intent.
            if intent.tool_name == "programs.open":
                platform_search = extract_open_platform_search(text)
                if platform_search is not None:
                    return IntentResolution(
                        intent=Intent(
                            "browser.search",
                            {"query": platform_search.query, "engine": platform_search.engine},
                            confidence=0.98,
                            source=IntentSource.LOCAL_NLU,
                        )
                    )

            target = str(intent.args.get("name") or "")
            if is_plural_program_reference(target):
                return self._resolve_program_group_reference(intent)
            if is_reference_target(target):
                reference = self.context.resolve_reference(intent)
                if reference.intent is not None:
                    return IntentResolution(intent=reference.intent)
                return IntentResolution(clarification=self._reference_question(reference.reason, intent.tool_name))

            resolution = self.directory.resolve(target)
            if resolution.kind is ProgramResolutionKind.UNIQUE and resolution.entry is not None:
                entry = resolution.entry
                args = dict(intent.args)
                args["name"] = entry.identifier
                args["display_name"] = entry.display_name
                return IntentResolution(
                    intent=Intent(intent.tool_name, args, confidence=max(intent.confidence, 0.98), source=IntentSource.LOCAL_NLU)
                )
            if resolution.kind is ProgramResolutionKind.AMBIGUOUS:
                return IntentResolution(
                    clarification=self._target_question(intent.tool_name, "program", tuple(entry.identifier for entry in resolution.entries))
                )
            # Fail closed rather than returning ``None`` and letting a raw
            # unknown program intent through to ToolRegistry.
            if intent.tool_name == "programs.open":
                unknown = classify_program_name_reply(target, self.directory)
                if unknown.kind in {ExplicitProgramTargetKind.UNKNOWN, ExplicitProgramTargetKind.INVALID}:
                    return IntentResolution(program_open=self._program_open_plan((unknown,)))
            return IntentResolution(clarification=self._target_question(intent.tool_name, "program"))

        if intent.tool_name == "browser.search":
            query = str(intent.args.get("query") or "")
            if not query or is_reference_target(query):
                reference = self.context.resolve_reference(intent)
                if reference.intent is not None:
                    return IntentResolution(intent=reference.intent)
                return IntentResolution(clarification=self._reference_question(reference.reason, intent.tool_name))
        return None

    def resolve_provider_candidate(self, text: str, candidate: SemanticCandidate | None) -> IntentResolution:
        """Treat all externally supplied candidates as provider-origin metadata."""

        blocked = action_safety_reason(text)
        if blocked is not None:
            return IntentResolution(safety_blocked=True, reason=blocked)
        # Defense in depth: even a buggy caller must not let a provider turn a
        # bare entity mention into an action.  Pending clarifications are
        # resolved locally before this method and therefore do not need this
        # remote escape hatch.
        if not looks_like_action_request(text, self.directory):
            return IntentResolution(reason="provider_non_action_request")
        if candidate is None:
            return IntentResolution(reason="provider_no_match")
        return self.resolve_candidate(replace(candidate, source=SemanticSource.PROVIDER))

    def resolve_candidate(self, candidate: SemanticCandidate) -> IntentResolution:
        # A plural antecedent is a local SessionContext capability, never a
        # provider-controlled target.  Rebuild its fresh canonical IDs below
        # before the normal scalar candidate path can inspect a directory.
        if (
            candidate.source is SemanticSource.LOCAL
            and candidate.action in {"programs.open", "programs.close"}
            and candidate.target
            and is_plural_program_reference(candidate.target)
        ):
            source = IntentSource.SEMANTIC_LOCAL
            return self._resolve_program_group_reference(
                Intent(candidate.action, {"name": normalized_words(candidate.target)}, candidate.confidence, source)
            )

        if candidate.clarification_required:
            return IntentResolution(clarification=self._candidate_question(candidate))

        # A same-name directory collision must become an explicit selection,
        # never an arbitrary first target.  Its options were obtained locally.
        if candidate.action in {"programs.open", "programs.close"} and candidate.target:
            resolution = self.directory.resolve(candidate.target)
            if resolution.kind is ProgramResolutionKind.AMBIGUOUS:
                source = IntentSource.SEMANTIC_LOCAL if candidate.source is SemanticSource.LOCAL else IntentSource.SEMANTIC_PROVIDER
                return IntentResolution(
                    clarification=self._target_question_with_source(
                        candidate.action,
                        "program",
                        tuple(entry.identifier for entry in resolution.entries),
                        source,
                    )
                )

        intent = self._candidate_to_intent(candidate)
        if intent is None:
            # Only a genuinely missing target in a *local* browser-search
            # continuation becomes a context question.  An external provider
            # cannot introduce a hidden subject by sending an empty target.
            if (
                candidate.source is SemanticSource.LOCAL
                and candidate.action == "browser.search"
                and (candidate.target is None or not candidate.target.strip())
            ):
                return IntentResolution(clarification=self._candidate_question(candidate))
            if (
                candidate.action in _SEMANTIC_ACTIONS
                and candidate.confidence >= 0.70
                and candidate.source is SemanticSource.LOCAL
                and (candidate.target is None or not candidate.target.strip())
            ):
                return IntentResolution(clarification=self._candidate_question(candidate))
            return IntentResolution(reason="invalid_semantic_candidate")

        reference = self.context.resolve_reference(intent)
        if reference.intent is None:
            if reference.requires_clarification:
                return IntentResolution(clarification=self._reference_question(reference.reason, intent.tool_name))
            return IntentResolution(reason="unresolved_semantic_candidate")
        intent = reference.intent

        # A successful contextual substitution is deliberately promoted by
        # SessionContext to high confidence: the reference was type-compatible,
        # recent and tied to the active subject rather than guessed.
        if intent.confidence >= 0.90:
            return IntentResolution(intent=intent)
        if intent.confidence >= 0.70:
            return IntentResolution(clarification=self._candidate_question(candidate, intent=intent))
        return IntentResolution(reason="low_semantic_confidence")

    def _candidate_to_intent(self, candidate: SemanticCandidate) -> Intent | None:
        if candidate.action not in _SEMANTIC_ACTIONS or candidate.action is None:
            return None
        if self.tools.get(candidate.action) is None:
            return None
        if candidate.source is SemanticSource.PROVIDER:
            if set(candidate.entities) - {"engine", "program", "site"}:
                return None
            if candidate.options and not candidate.clarification_required:
                return None

        source = (
            IntentSource.SEMANTIC_LOCAL
            if candidate.source is SemanticSource.LOCAL
            else IntentSource.SEMANTIC_PROVIDER
        )
        target = " ".join((candidate.target or "").split()).strip()

        if candidate.action in {"programs.open", "programs.close"}:
            if not target:
                return None
            normalized = normalized_words(target)
            if is_reference_target(normalized):
                return Intent(candidate.action, {"name": normalized, "display_name": normalized}, candidate.confidence, source)
            resolution = self.directory.resolve(normalized)
            if resolution.kind is not ProgramResolutionKind.UNIQUE or resolution.entry is None:
                return None
            entry = resolution.entry
            return Intent(
                candidate.action,
                {"name": entry.identifier, "display_name": entry.display_name},
                candidate.confidence,
                source,
            )

        if candidate.action == "browser.open_default":
            if target or candidate.entities:
                return None
            return Intent(candidate.action, {}, candidate.confidence, source)

        if candidate.action == "browser.open_named":
            if not target:
                return None
            canonical = SITE_LOOKUP.get(normalized_words(target), normalized_words(target))
            if canonical not in _SITES:
                return None
            return Intent(candidate.action, {"name": canonical}, candidate.confidence, source)

        if candidate.action == "browser.search":
            if len(target) > 500:
                return None
            if candidate.source is SemanticSource.PROVIDER and (not target or _PATH_OR_URL.search(target)):
                return None
            engine = normalized_words(candidate.entities.get("engine", "google"))
            if engine not in _SEARCH_ENGINES:
                return None
            return Intent(
                candidate.action,
                {"query": target, "engine": engine},
                candidate.confidence,
                source,
            )
        return None

    def _program_options(self, options: tuple[str, ...]) -> tuple[ProgramEntry, ...]:
        output: list[ProgramEntry] = []
        seen: set[str] = set()
        for target in options:
            resolution = self.directory.resolve(target)
            entry = resolution.entry
            if resolution.kind is not ProgramResolutionKind.UNIQUE or entry is None:
                continue
            if entry.identifier in seen:
                continue
            seen.add(entry.identifier)
            output.append(entry)
        return tuple(output)

    def _options_for(
        self,
        action: str,
        target_kind: str,
        options: tuple[str, ...],
        source: IntentSource,
    ) -> tuple[ClarificationOption, ...]:
        if self.tools.get(action) is None:
            return ()
        if target_kind == "program":
            entries = self._program_options(options)
            labels = self.directory.option_labels(entries)
            return tuple(
                ClarificationOption(
                    labels[entry.identifier],
                    Intent(
                        action,
                        {"name": entry.identifier, "display_name": entry.display_name},
                        confidence=0.98,
                        source=source,
                    ),
                )
                for entry in entries
            )

        output: list[ClarificationOption] = []
        for target in options:
            canonical = normalized_words(target)
            if canonical not in _SITES:
                continue
            output.append(
                ClarificationOption(
                    _display_site(canonical),
                    Intent(action, {"name": canonical}, confidence=0.98, source=source),
                )
            )
        return tuple(output)

    def _target_question(self, action: str, target_kind: str, options: tuple[str, ...] = ()) -> ClarificationRequest:
        return self._target_question_with_source(action, target_kind, options, IntentSource.SEMANTIC_LOCAL)

    def _target_question_with_source(
        self,
        action: str,
        target_kind: str,
        options: tuple[str, ...],
        source: IntentSource,
    ) -> ClarificationRequest:
        choices = self._options_for(action, target_kind, options, source)
        verb = "abrir" if action == "programs.open" else "fechar"
        if choices:
            prompt = f"Você quer {verb} {' ou '.join(item.label for item in choices)}?"
        elif target_kind == "program":
            prompt = f"Qual programa você quer {verb}?"
        else:
            prompt = "Qual site você quer abrir?"
        allowed = self.directory.allowed_programs() if target_kind == "program" else tuple(sorted(_SITES))
        return ClarificationRequest(
            prompt,
            choices,
            action,
            target_kind,
            allowed,
            # Product decision: only two same-family, low-risk program-open
            # Intents have an explicit multi-select contract.
            allow_multi_select=(action == "programs.open" and len(choices) == 2),
        )

    def _reference_question(self, reason: str | None, action: str) -> ClarificationRequest:
        if reason in {"program_reference", "program_group_reference"}:
            return self._target_question(action, "program")
        if reason == "search_reference":
            return ClarificationRequest("Não tenho um assunto recente para pesquisar. O que você quer procurar?")
        return ClarificationRequest("Não tenho certeza do que você quer repetir. Pode me dizer qual ação?")

    def _candidate_question(self, candidate: SemanticCandidate, *, intent: Intent | None = None) -> ClarificationRequest:
        action = candidate.action
        if action in {"programs.open", "programs.close"}:
            source = IntentSource.SEMANTIC_LOCAL if candidate.source is SemanticSource.LOCAL else IntentSource.SEMANTIC_PROVIDER
            options = tuple(entry.identifier for entry in self._program_options(candidate.options))
            if intent is not None and intent.args.get("name") and not options:
                options = (str(intent.args["name"]),)
            return self._target_question_with_source(action, "program", options, source)
        if action == "browser.open_named":
            source = IntentSource.SEMANTIC_LOCAL if candidate.source is SemanticSource.LOCAL else IntentSource.SEMANTIC_PROVIDER
            options = tuple(item for item in candidate.options if normalized_words(item) in _SITES)
            if intent is not None and intent.args.get("name") and not options:
                options = (str(intent.args["name"]),)
            return self._target_question_with_source(action, "site", options, source)
        if action == "browser.search":
            return ClarificationRequest("O que você quer pesquisar?")
        return ClarificationRequest("Não tenho certeza do que você quer fazer. Pode reformular o pedido?")


__all__ = [
    "IntentResolution",
    "IntentResolutionCoordinator",
    "ProgramOpenItem",
    "ProgramOpenResolution",
    "UnrecognizedProgramTarget",
]
