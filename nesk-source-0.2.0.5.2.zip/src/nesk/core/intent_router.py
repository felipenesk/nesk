from __future__ import annotations

import re
from urllib.parse import urlparse

from nesk.core.intent import Intent, IntentSource
from nesk.nlu.lexicon import (
    BROWSER_ALIASES,
    CAPABILITY_PHRASES,
    OPEN_VERBS,
    SITE_LOOKUP,
    SYSTEM_QUESTION_WORDS,
    SYSTEM_SUBJECTS,
)
from nesk.nlu.ptbr import (
    extract_close_target,
    extract_open_platform_search,
    extract_open_target,
    extract_search_request,
    is_context_reference,
    normalize_ptbr,
    normalized_words,
    strip_wake_name,
)
from nesk.platform.windows.program_directory import ProgramDirectory, ProgramResolutionKind


def _word_set_pattern(words: tuple[str, ...]) -> re.Pattern[str]:
    escaped = sorted((re.escape(normalize_ptbr(word)) for word in words), key=len, reverse=True)
    return re.compile(r"\b(?:" + "|".join(escaped) + r")\b", re.IGNORECASE)


class LocalIntentRouter:
    """Deterministic high-confidence router for safe local Foundation actions.

    This layer deliberately prefers *not* executing over guessing.  In
    particular, an unknown target after ``abre`` is not granted program type;
    it is left for typed semantic clarification or a validated Program
    Directory entry.
    """

    _url = re.compile(r"https?://[^\s]+", re.IGNORECASE)
    _open_verbs = _word_set_pattern(OPEN_VERBS)
    _system_subject = _word_set_pattern(SYSTEM_SUBJECTS)
    _system_question = _word_set_pattern(SYSTEM_QUESTION_WORDS)

    _browser_targets = {normalize_ptbr(item) for item in BROWSER_ALIASES}
    _capabilities = {normalized_words(item) for item in CAPABILITY_PHRASES}

    def __init__(self, *, directory: ProgramDirectory | None = None) -> None:
        self.directory = directory or ProgramDirectory.static()

    def route(self, text: str) -> Intent | None:
        original = " ".join(text.strip().split())
        if not original:
            return None

        # URLs are extracted before punctuation normalization.
        url_match = self._url.search(original)
        normalized = strip_wake_name(normalize_ptbr(original))
        phrase = normalized_words(strip_wake_name(original))

        if url_match and self._open_verbs.search(normalized):
            # Require the request itself to start like a direct action rather than
            # opening a URL merely because the user discussed one in a sentence.
            open_target = extract_open_target(normalized)
            if open_target is not None:
                url = url_match.group(0).rstrip(".,!?)\"]}")
                parsed = urlparse(url)
                if parsed.scheme in {"http", "https"} and parsed.netloc:
                    return Intent("browser.open_url", {"url": url}, confidence=0.99, source=IntentSource.LOCAL_NLU)

        if phrase in self._capabilities:
            return Intent("nesk.capabilities", {}, confidence=0.99, source=IntentSource.LOCAL_NLU)

        # System status is read-only and safe. Natural variants are accepted when
        # both a system subject and a status/question signal are present.
        if self._system_subject.search(normalized) and self._system_question.search(normalized):
            return Intent("system.status", {}, confidence=0.99, source=IntentSource.LOCAL_NLU)

        search = extract_search_request(normalized)
        if search is not None:
            # An engine-only form is a typed local continuation.  SessionContext
            # supplies a recent topic or explicitly asks; no literal "no
            # youtube" query reaches a browser tool.
            if search.query is None or is_context_reference(search.query):
                return None
            return Intent(
                "browser.search",
                {"query": search.query, "engine": search.engine},
                confidence=0.98,
                source=IntentSource.LOCAL_NLU,
            )

        # Classify an entity placed on a web platform before considering local
        # programs.  No URL is derived from this text.
        platform_search = extract_open_platform_search(normalized)
        if platform_search is not None:
            return Intent(
                "browser.search",
                {"query": platform_search.query, "engine": platform_search.engine},
                confidence=0.98,
                source=IntentSource.LOCAL_NLU,
            )

        close_target = extract_close_target(normalized)
        if close_target is not None:
            close_target = re.sub(r"^(?:meu|minha|meus|minhas)\s+", "", close_target).strip()
            if is_context_reference(close_target):
                return None
            resolution = self.directory.resolve(close_target)
            if resolution.kind is not ProgramResolutionKind.UNIQUE or resolution.entry is None:
                return None
            entry = resolution.entry
            return Intent(
                "programs.close",
                {"name": entry.identifier, "display_name": entry.display_name},
                confidence=0.96,
                source=IntentSource.LOCAL_NLU,
            )

        target = extract_open_target(normalized)
        if target is None:
            return None

        # Possessives can survive uncommon combinations of polite framing.
        target = re.sub(r"^(?:meu|minha|meus|minhas)\s+", "", target).strip()
        if is_context_reference(target):
            return None

        if target in self._browser_targets:
            return Intent("browser.open_default", {}, confidence=0.99, source=IntentSource.LOCAL_NLU)

        site_name = SITE_LOOKUP.get(target)
        if site_name:
            return Intent("browser.open_named", {"name": site_name}, confidence=0.99, source=IntentSource.LOCAL_NLU)

        resolution = self.directory.resolve(target)
        if resolution.kind is not ProgramResolutionKind.UNIQUE or resolution.entry is None:
            # Never promote raw unknown text into programs.open.  The local
            # semantic stage may still ask a typed clarification, but no Tool
            # receives this target unless a trusted directory recognizes it.
            return None
        entry = resolution.entry
        return Intent(
            "programs.open",
            {"name": entry.identifier, "display_name": entry.display_name},
            confidence=0.97,
            source=IntentSource.LOCAL_NLU,
        )
