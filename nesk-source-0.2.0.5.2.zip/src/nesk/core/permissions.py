from __future__ import annotations

from enum import IntEnum


class RiskLevel(IntEnum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3


class PermissionDecision(str):
    ALLOW = "allow"
    CONFIRM = "confirm"
    BLOCK = "block"


class PermissionPolicy:
    """Central policy boundary. Keep this independent from the UI and model."""

    def decide(self, risk: RiskLevel) -> str:
        if risk == RiskLevel.LOW:
            return PermissionDecision.ALLOW
        if risk == RiskLevel.MEDIUM:
            return PermissionDecision.CONFIRM
        return PermissionDecision.BLOCK
