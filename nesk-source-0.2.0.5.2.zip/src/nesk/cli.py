from __future__ import annotations


def main() -> int:
    from nesk.core.bootstrap import bootstrap
    from nesk.version import __version__

    runtime = bootstrap()
    print(f"NESK {__version__} Core Hardening — CLI de diagnóstico")
    print("Digite /sair para encerrar.\n")
    while True:
        try:
            text = input("Você > ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if text.lower() in {"/sair", "/exit", "exit", "quit"}:
            break
        if not text:
            continue
        result = runtime.core.handle(text)
        print(f"NESK > {result.text}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
