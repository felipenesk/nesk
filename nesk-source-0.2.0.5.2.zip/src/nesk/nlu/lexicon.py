from __future__ import annotations

"""Brazilian Portuguese lexical knowledge used by the deterministic NLU layer.

This module is intentionally data-oriented. Expanding how NESK understands common
phrasing should mostly mean adding aliases here, not scattering conditionals across
the Core. It is *not* a full natural-language model; it is the safe/high-confidence
local command layer that must keep working even when no AI provider is available.
"""

WAKE_NAMES = ("nesk",)

OPEN_VERBS = (
    "abre", "abrir", "abra",
    "bota", "boto", "botar",
    "coloca", "colocar",
    "inicia", "iniciar",
    "executa", "execute", "executar",
    "acessa", "acessar",
    "entra", "entrar",
    "chama", "chamar",
    "roda", "rodar",
)


CLOSE_VERBS = (
    "fecha", "fechar", "feche",
    "encerra", "encerrar", "encerre",
    "sai", "sair",
)

SEARCH_VERBS = (
    "pesquisa", "pesquisar", "pesquise",
    "procura", "procurar", "procure",
    "busca", "buscar", "busque",
    "google", "googla", "googlar",
)

# Phrases that may introduce a direct request. They only expose a following
# high-confidence command verb; by themselves they never trigger an action.
REQUEST_PREFIXES = (
    "por favor",
    "manda",
    "voce pode", "vc pode", "pode",
    "voce poderia", "vc poderia", "poderia",
    "voce consegue", "vc consegue", "consegue",
    "voce conseguiria", "vc conseguiria", "conseguiria",
    "tem como", "da pra", "da para",
    "sera que da pra", "sera que da para",
)

# Short discourse markers that may precede a direct request in informal
# Brazilian Portuguese.  They are intentionally *not* verbs, targets or full
# sentence patterns: the parser removes them only at the very beginning and
# still checks the modality of everything that follows.
DISCOURSE_PREAMBLES = (
    "agora", "entao", "depois",
    "ae", "ai", "ei", "opa",
    "mano", "mana", "vei", "veio", "velho", "cara",
    "tipo assim", "tipo", "po", "pô",
)

# Common conversational material that can safely be removed from around a target
# *after* an action has already been confidently identified.
LEADING_FILLERS = (
    "pra mim", "para mim", "pra min", "para min", "ai", "aqui",
)

TRAILING_FILLERS = (
    "pra mim", "para mim", "pra min", "para min",
    "por favor",
    "rapidinho", "rapidão", "rapidao",
    "ai", "aí",
    "aqui",
    "quando puder", "se puder",
    "por gentileza",
    "faz favor",
    "por obséquio", "por obsequio",
    "pra rodar", "para rodar",
    "beleza", "blz",
)

DETERMINERS = (
    "o", "a", "os", "as", "um", "uma",
    "no", "na", "nos", "nas",
    "meu", "minha", "meus", "minhas",
)

# Canonical target -> accepted local-language aliases. These aliases map meaning;
# the tool layer still decides whether/how the target may be executed.
SITE_ALIASES: dict[str, tuple[str, ...]] = {
    "youtube": ("youtube", "you tube", "yt"),
    "google": ("google",),
    "github": ("github", "git hub"),
    "chatgpt": ("chatgpt", "chat gpt", "chat openai", "openai chat"),
    "claude": ("claude", "anthropic", "claude ai"),
    "gmail": ("gmail", "g mail", "email do google"),
    "whatsapp": ("whatsapp", "whats", "whatsapp web", "zap"),
    "twitch": ("twitch",),
    "reddit": ("reddit",),
    "spotify_web": ("spotify web", "spotify no navegador"),
}

PROGRAM_ALIASES: dict[str, tuple[str, ...]] = {
    "chrome": ("chrome", "google chrome"),
    "edge": ("edge", "microsoft edge"),
    "firefox": ("firefox", "mozilla", "mozilla firefox"),
    "discord": ("discord",),
    "spotify": ("spotify",),
    "notepad": ("notepad", "bloco de notas", "bloco notas"),
    "explorer": (
        "explorer", "explorador", "explorador de arquivos", "arquivos", "meus arquivos"
    ),
    "calculator": ("calculadora", "calculator", "calc"),
    "paint": ("paint", "mspaint"),
}

BROWSER_ALIASES = (
    "navegador", "browser", "navegador padrao", "browser padrao", "internet"
)

SYSTEM_SUBJECTS = (
    "ram", "memoria", "memoria ram",
    "cpu", "processador",
    "disco", "armazenamento", "ssd", "hd",
    "pc", "computador", "maquina", "sistema",
)

SYSTEM_QUESTION_WORDS = (
    "quanto", "quanta", "qual", "uso", "usando", "utilizacao", "status",
    "como", "estado", "consumo", "livre", "disponivel", "ta", "esta",
    "ocupado", "ocupada", "gastando", "pegando",
)

CAPABILITY_PHRASES = (
    "o que voce consegue fazer",
    "o que vc consegue fazer",
    "o que consegue fazer",
    "o que tu consegue fazer",
    "o que voce faz",
    "o que vc faz",
    "o que tu faz",
    "o que o nesk faz",
    "quais sao suas funcoes",
    "quais suas funcoes",
    "quais sao seus comandos",
    "quais seus comandos",
    "me mostra seus comandos",
    "mostra seus comandos",
    "me fala o que voce consegue fazer",
    "me diz o que voce consegue fazer",
    "me ajuda com os comandos",
    "ajuda comandos",
    "ajuda",
    "help",
)

# Search-engine aliases are separated from named sites because they indicate where
# a query should be performed, not merely which homepage should be opened.
SEARCH_ENGINE_ALIASES: dict[str, tuple[str, ...]] = {
    "google": ("google", "no google", "na internet", "internet"),
    "youtube": ("youtube", "no youtube", "you tube", "no you tube"),
}


def invert_alias_map(mapping: dict[str, tuple[str, ...]]) -> dict[str, str]:
    result: dict[str, str] = {}
    for canonical, aliases in mapping.items():
        for alias in aliases:
            result[alias] = canonical
    return result


SITE_LOOKUP = invert_alias_map(SITE_ALIASES)
PROGRAM_LOOKUP = invert_alias_map(PROGRAM_ALIASES)
