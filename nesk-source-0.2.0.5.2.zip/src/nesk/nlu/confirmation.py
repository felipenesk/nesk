from __future__ import annotations

import re
from enum import Enum

from nesk.nlu.ptbr import normalized_words, strip_wake_name


class ConfirmationDecision(str, Enum):
    CONFIRM = "confirm"
    CANCEL = "cancel"
    AMBIGUOUS = "ambiguous"
    UNRELATED = "unrelated"


# Exact, intentionally conservative phrases. These are only considered while a
# permission prompt is already pending; outside that context they do nothing.
_POSITIVES = {
    "sim",
    "sim pode",
    "sim pode fazer",
    "pode",
    "pode sim",
    "pode fazer",
    "confirmo",
    "confirma",
    "confirmado",
    "isso",
    "isso mesmo",
    "claro",
    "claro que sim",
    "ok",
    "okay",
    "beleza",
    "blz",
    "faz",
    "manda",
    "vai",
}

_NEGATIVES = {
    "nao",
    "nao precisa",
    "nao quero",
    "melhor nao",
    "cancela",
    "cancelar",
    "deixa",
    "deixa quieto",
    "pode deixar",
    "esquece",
    "para",
    "pare",
}

# Politeness around an otherwise exact confirmation must not invalidate it.
# Keep this list narrow so we never strip meaningful action words.
_POLITE = (
    "por favor",
    "por gentileza",
    "pfv",
    "obrigado",
    "obrigada",
    "valeu",
)

_CUE_PATTERNS = tuple(
    re.compile(rf"(?:^|\s){re.escape(phrase)}(?:$|\s)")
    for phrase in sorted(_POSITIVES | _NEGATIVES, key=len, reverse=True)
)


def _strip_politeness(phrase: str) -> str:
    clean = phrase
    for _ in range(3):
        before = clean
        for polite in _POLITE:
            clean = re.sub(rf"^{re.escape(polite)}\s+", "", clean).strip()
            clean = re.sub(rf"\s+{re.escape(polite)}$", "", clean).strip()
        if clean == before:
            break
    return clean


def classify_confirmation(text: str) -> ConfirmationDecision:
    """Classify one reply to a pending permission prompt.

    Safety rule: only exact, normalized confirmation phrases execute/cancel the
    pending action. Phrases that merely *contain* a yes/no cue are ambiguous and
    must never authorize an action. Unrelated text can safely expire the stale
    prompt and be processed as a new request by the Core.
    """

    phrase = normalized_words(strip_wake_name(text)).strip(" .,:;!?-_")
    if not phrase:
        return ConfirmationDecision.AMBIGUOUS

    canonical = _strip_politeness(phrase).strip(" .,:;!?-_")
    if canonical in _POSITIVES:
        return ConfirmationDecision.CONFIRM
    if canonical in _NEGATIVES:
        return ConfirmationDecision.CANCEL

    # Examples: "acho que sim", "sim mas espera", "nao sei". They contain a
    # confirmation cue but are not clear authorization/cancellation. Keep the
    # pending action and ask again instead of guessing.
    if any(pattern.search(canonical) for pattern in _CUE_PATTERNS):
        return ConfirmationDecision.AMBIGUOUS

    return ConfirmationDecision.UNRELATED
