from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

from nesk.nlu.lexicon import (
    CLOSE_VERBS,
    DETERMINERS,
    DISCOURSE_PREAMBLES,
    LEADING_FILLERS,
    OPEN_VERBS,
    REQUEST_PREFIXES,
    SEARCH_VERBS,
    TRAILING_FILLERS,
)


def normalize_ptbr(text: str) -> str:
    """Return accent-insensitive, whitespace-normalized lower-case text.

    Punctuation is preserved here because URLs and some later parsing steps may
    still need it. Individual parsers decide what punctuation is irrelevant.
    """
    folded = unicodedata.normalize("NFKD", text)
    folded = "".join(ch for ch in folded if not unicodedata.combining(ch))
    folded = folded.lower().strip()
    folded = re.sub(r"\s+", " ", folded)
    return folded


def normalized_words(text: str) -> str:
    """Normalize text for phrase matching while turning punctuation into spaces.

    A tiny set of extremely common Brazilian-Portuguese typing forms is
    canonicalized here. This is intentionally conservative: the deterministic
    NLU should tolerate normal chat typos without turning into a fuzzy matcher
    that guesses dangerous actions.
    """
    clean = normalize_ptbr(text)
    clean = re.sub(r"[^a-z0-9:/._+\-\s]", " ", clean)
    clean = re.sub(r"\boque\b", "o que", clean)
    clean = re.sub(r"\s+", " ", clean).strip()
    return clean


def strip_wake_name(text: str) -> str:
    """Remove an optional NESK name/wake prefix from the utterance.

    Speech-to-text engines naturally vary punctuation around a vocative.
    Treat ``NESK, abre...``, ``NESK. Abre...`` and similar forms as the
    same wake/name prefix without making the rest of the command fuzzy.
    """
    return re.sub(
        r"^nesk\b(?:\s*[^\w\s])*\s*",
        "",
        text,
        count=1,
        flags=re.IGNORECASE,
    ).strip()


def _phrase_pattern(phrases: tuple[str, ...]) -> str:
    # Longest first prevents a shorter phrase consuming part of a longer one.
    values = sorted((re.escape(normalize_ptbr(p)) for p in phrases), key=len, reverse=True)
    return "(?:" + "|".join(values) + ")"


_OPEN_VERB_PATTERN = _phrase_pattern(OPEN_VERBS)
_CLOSE_VERB_PATTERN = _phrase_pattern(CLOSE_VERBS)
_SEARCH_VERB_PATTERN = _phrase_pattern(SEARCH_VERBS)
_REQUEST_PREFIX_PATTERN = _phrase_pattern(REQUEST_PREFIXES)
_DISCOURSE_PREAMBLE_PATTERN = _phrase_pattern(DISCOURSE_PREAMBLES)
_DETERMINER_PATTERN = _phrase_pattern(DETERMINERS)
_CONTEXT_REFERENCE_WORDS = {
    "ele",
    "ela",
    "isso",
    "isto",
    "esse",
    "essa",
    "aquele",
    "aquela",
    "aquilo",
}
_CONTEXT_PLACEHOLDER = re.compile(r"\b(?:esse|essa|aquele|aquela)\s+(?:coisa|parada|negocio)\b")
_PLURAL_PROGRAM_REFERENCE_VALUES = frozenset(
    {
        "eles",
        "elas",
        "ambos",
        "ambas",
        "os dois",
        "as duas",
        "os 2",
        "as 2",
        # ``cleanup_command_target`` deliberately removes leading determiners
        # after an action has been identified.  Keep the post-cleanup forms
        # here instead of weakening the generic singular-reference parser.
        "dois",
        "duas",
        "2",
    }
)


def is_context_reference(value: str) -> bool:
    """Whether an extracted target needs a typed session antecedent.

    The strict local router deliberately leaves these to the Core/context layer;
    a pronoun or deictic phrase must never become a literal program or query.
    """

    clean = normalized_words(value)
    return clean in _CONTEXT_REFERENCE_WORDS or bool(_CONTEXT_PLACEHOLDER.search(clean))


def is_plural_program_reference(value: str) -> bool:
    """Whether a program target is an exact, local plural reference.

    This deliberately stays separate from :func:`is_context_reference`.
    Treating ``eles`` as a generic reference would make the existing singular
    resolver silently substitute only ``last_program``.  Callers must opt in
    to the narrowly typed program-group contract instead.
    """

    return normalized_words(value) in _PLURAL_PROGRAM_REFERENCE_VALUES


def strip_discourse_preamble(text: str) -> str:
    """Remove only a compact sequence of initial discourse markers.

    This is intentionally not a "find the next verb" heuristic.  It consumes
    known standalone markers from the beginning of an utterance and leaves the
    rest intact for modality/safety checks.  Thus ``mano não abre`` still
    contains its negation and ``cara eu estava pensando...`` remains a
    first-person discussion rather than a command.
    """

    clean = normalize_ptbr(text)
    for _ in range(6):
        before = clean
        clean = re.sub(r"^[,;:\-\s]+", "", clean)
        match = re.match(
            rf"^(?:{_DISCOURSE_PREAMBLE_PATTERN})\b\s*[,;:\-]?\s*",
            clean,
        )
        if match:
            clean = clean[match.end() :].lstrip()
        if clean == before:
            break
    return clean


def strip_request_prefixes(text: str) -> str:
    """Remove request framing only when it occurs at the beginning."""
    clean = strip_discourse_preamble(text)
    # Multiple pieces can compose naturally: "por favor, voce pode abrir..."
    for _ in range(4):
        before = clean
        clean = re.sub(r"^[,;:\-\s]+", "", clean)
        clean = strip_discourse_preamble(clean)
        match = re.match(rf"^(?:{_REQUEST_PREFIX_PATTERN})\b\s*[,;:\-]?\s*", clean)
        if match:
            clean = clean[match.end():].lstrip()
        if clean == before:
            break
    return clean


def _strip_phrase_from_start(text: str, phrases: tuple[str, ...]) -> str:
    clean = text
    for phrase in sorted(phrases, key=len, reverse=True):
        normalized = normalize_ptbr(phrase)
        match = re.match(rf"^{re.escape(normalized)}\b\s*", clean)
        if match:
            return clean[match.end():].lstrip()
    return clean


def cleanup_command_target(target: str, *, strip_determiners: bool = True) -> str:
    """Remove conversational filler around an already-detected command target."""
    clean = target.strip()
    clean = re.sub(r"^[,;:\-\s]+", "", clean)
    clean = re.sub(r"[.!?,;:\-\s]+$", "", clean)

    if strip_determiners:
        # Natural wrappers that only describe where the target will open. This runs
        # only after an OPEN action is confidently detected.
        clean = re.sub(
            r"^(?:(?:uma?|a)\s+)?(?:aba|guia)\s+(?:no|na|do|da)\s+",
            "",
            clean,
            flags=re.IGNORECASE,
        )
        clean = re.sub(
            r"^(?:(?:o|a|no|na)\s+)?(?:site|pagina)\s+(?:do|da|de)\s+",
            "",
            clean,
            flags=re.IGNORECASE,
        )

    # Prefix filler can repeat: "abre pra mim ai o navegador".
    for _ in range(4):
        before = clean
        clean = _strip_phrase_from_start(clean, LEADING_FILLERS)
        if strip_determiners:
            clean = re.sub(rf"^(?:{_DETERMINER_PATTERN})\b\s+", "", clean).strip()
        if clean == before:
            break

    # Suffix filler can appear in several combinations.
    normalized_fillers = tuple(normalize_ptbr(p) for p in TRAILING_FILLERS)
    for _ in range(10):
        before = clean
        clean = re.sub(r"[.!?,;:\-\s]+$", "", clean)
        for phrase in sorted(normalized_fillers, key=len, reverse=True):
            updated = re.sub(rf"(?:\s+|^){re.escape(phrase)}\s*$", "", clean).strip()
            if updated != clean:
                clean = updated
                break
        if clean == before:
            break

    if strip_determiners:
        clean = re.sub(rf"^(?:{_DETERMINER_PATTERN})\b\s+", "", clean).strip()
    return clean


def extract_open_target(text: str) -> str | None:
    """Extract target from a high-confidence direct open/access request."""
    clean = strip_request_prefixes(text)
    match = re.match(
        rf"^(?:me\s+)?{_OPEN_VERB_PATTERN}\b\s+(?P<target>.+)$",
        clean,
        re.IGNORECASE,
    )
    if not match:
        return None
    target = cleanup_command_target(match.group("target"))
    return target or None


def extract_close_target(text: str) -> str | None:
    """Extract target from a direct close/terminate request."""
    clean = strip_request_prefixes(text)
    match = re.match(
        rf"^(?:me\s+)?{_CLOSE_VERB_PATTERN}\b\s+(?P<target>.+)$",
        clean,
        re.IGNORECASE,
    )
    if not match:
        return None
    target = cleanup_command_target(match.group("target"))
    return target or None


@dataclass(frozen=True, slots=True)
class SearchRequest:
    # ``None`` is an explicit engine-only continuation, never a literal query.
    # The local SessionContext may supply a recent topic; external providers may
    # not use it as an implicit argument.
    query: str | None
    engine: str = "google"


def _extract_search_engine(query: str) -> tuple[str | None, str]:
    """Split a query from an optional Google/YouTube placement clause."""

    clean = cleanup_command_target(query, strip_determiners=False)
    engine_only = re.fullmatch(r"(?:no|na)\s+(youtube|you\s*tube|google)", clean)
    if engine_only:
        return None, "youtube" if "tube" in engine_only.group(1) or engine_only.group(1) == "youtube" else "google"

    engine = "google"
    youtube_prefix = re.match(r"^(?:no|na)\s+(?:youtube|you\s*tube)\s+(?P<query>.+)$", clean)
    google_prefix = re.match(r"^(?:no|na)\s+google\s+(?P<query>.+)$", clean)
    if youtube_prefix:
        clean = youtube_prefix.group("query").strip()
        engine = "youtube"
    elif google_prefix:
        clean = google_prefix.group("query").strip()
        engine = "google"

    youtube_suffix = re.search(r"\s+(?:no|na)\s+(?:youtube|you\s*tube)\s*$", clean)
    google_suffix = re.search(r"\s+(?:no|na)\s+google\s*$", clean)
    if youtube_suffix:
        clean = clean[: youtube_suffix.start()].strip()
        engine = "youtube"
    elif google_suffix:
        clean = clean[: google_suffix.start()].strip()
        engine = "google"
    return clean or None, engine


def extract_search_request(text: str) -> SearchRequest | None:
    """Extract a safe browser-search request from direct Portuguese phrasing.

    Examples:
      "pesquisa dragonsteel pra mim" -> query=dragonsteel, engine=google
      "procura dragonsteel no youtube" -> query=dragonsteel, engine=youtube
    """
    clean = strip_request_prefixes(text)
    match = re.match(
        rf"^(?:me\s+)?{_SEARCH_VERB_PATTERN}\b\s+(?P<query>.+)$",
        clean,
        re.IGNORECASE,
    )
    if not match:
        return None

    query, engine = _extract_search_engine(match.group("query"))
    if query is None:
        return SearchRequest(query=None, engine=engine)
    query = cleanup_command_target(query, strip_determiners=False)
    # "pesquisa por X" / "procura sobre X"
    query = re.sub(r"^(?:por|sobre)\s+", "", query).strip()
    return SearchRequest(query=query, engine=engine) if query else None


def extract_open_platform_search(text: str) -> SearchRequest | None:
    """Recognize ``abre <entidade> no YouTube|Google`` as a safe search.

    This runs before program classification.  It never manufactures a URL and
    requires a non-empty entity, so a bare ``abre YouTube`` remains the named
    site action handled by the router.
    """

    target = extract_open_target(text)
    if target is None:
        return None
    normalized_target = normalized_words(target)
    # ``_extract_search_engine`` also has a Google default for ordinary search
    # verbs.  An open request is a platform search only when the user actually
    # placed the entity on Google/YouTube.
    if not re.search(r"(?:^|\s)(?:no|na)\s+(?:youtube|you\s*tube|google)(?:\s|$)", normalized_target):
        return None
    query, engine = _extract_search_engine(target)
    if query is None:
        return None
    return SearchRequest(query=query, engine=engine)
