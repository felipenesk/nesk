from __future__ import annotations

from abc import ABC, abstractmethod

from nesk.core.models import Message


class AIProvider(ABC):
    @abstractmethod
    def reply(self, messages: list[Message]) -> str:
        raise NotImplementedError

    def close(self) -> None:
        """Release provider resources.

        Providers are allowed to be stateless, so the default is intentionally a
        no-op. Network/local-model providers can override this later without the
        Core needing provider-specific shutdown logic.
        """
        return None
