from __future__ import annotations

import logging

from nesk.core.models import Message
from nesk.providers.base import AIProvider


class ResilientProvider(AIProvider):
    """Use a primary provider but preserve NESK responsiveness on outages."""

    def __init__(self, primary: AIProvider, fallback: AIProvider) -> None:
        self.primary = primary
        self.fallback = fallback
        self.logger = logging.getLogger("nesk")

    def reply(self, messages: list[Message]) -> str:
        try:
            return self.primary.reply(messages)
        except Exception as exc:
            self.logger.warning("provider_fallback type=%s", type(exc).__name__)
            return self.fallback.reply(messages)

    def close(self) -> None:
        # Isolate shutdown failures exactly like reply failures. Shutdown should
        # never leave the application hanging because one provider misbehaved.
        for provider in (self.primary, self.fallback):
            try:
                provider.close()
            except Exception as exc:
                self.logger.warning("provider_close_error type=%s", type(exc).__name__)
