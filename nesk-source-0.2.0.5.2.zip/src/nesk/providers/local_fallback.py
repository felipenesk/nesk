from __future__ import annotations

import re

from nesk.core.models import Message, Role
from nesk.providers.base import AIProvider
from nesk.nlu.lexicon import CLOSE_VERBS, OPEN_VERBS, SEARCH_VERBS
from nesk.nlu.ptbr import normalize_ptbr, normalized_words, strip_wake_name


def _contains_action_word(text: str) -> bool:
    words = set(normalized_words(text).split())
    action_words = {
        normalized_words(item)
        for item in (*OPEN_VERBS, *CLOSE_VERBS, *SEARCH_VERBS)
        if " " not in normalized_words(item)
    }
    return bool(words & action_words)


class LocalFallbackProvider(AIProvider):
    """Zero-network fallback used while the real local/cloud brain is absent.

    It deliberately does not pretend to be a full LLM. Its job is to keep NESK
    responsive, identifiable and testable when offline/provider-less.
    """

    def reply(self, messages: list[Message]) -> str:
        last = next((m.content for m in reversed(messages) if m.role == Role.USER), "")
        text = strip_wake_name(normalize_ptbr(last)).strip(" .!?,-")

        if not text or text in {"ei", "fala", "alo", "alô"}:
            return "Fala. Tô aqui."
        if any(greeting in text for greeting in ("oi", "ola", "boa noite", "bom dia", "boa tarde")):
            return "Tô aqui. Essa build já tem ferramentas locais; meu modo de conversa completo ainda não está ligado."
        if "quem e voce" in text or "quem e o nesk" in text:
            return (
                "Eu sou o NESK. Nesta fase meu Core, contexto de sessão e ferramentas locais já funcionam; "
                "voz, memória avançada e conversa completa ainda estão em desenvolvimento."
            )
        if text in {"obrigado", "valeu", "vlw", "tmj"}:
            return "Tamo junto."

        # During Foundation validation, make safe no-op decisions visible instead
        # of replying with an ambiguous generic fallback. This does not execute
        # anything; it only explains why the deterministic router stayed idle.
        words = normalized_words(text)
        if re.match(r"^(?:nao|não)\b", text) and _contains_action_word(text):
            return "Beleza. Entendi a negação e não executei nenhuma ação."
        if words.startswith("como ") and _contains_action_word(text):
            return (
                "Entendi isso como uma pergunta, não como um comando, então não executei nada. "
                "A resposta explicativa completa entra quando o provider de IA estiver ativo."
            )
        if _contains_action_word(text):
            return (
                "Entendi isso como conversa, não como um pedido direto. Não executei nenhuma ação. "
                "Meu modo de conversa completo ainda depende do provider de IA."
            )

        return (
            "Tô te acompanhando, mas esta build ainda usa meu cérebro local de fallback para conversa aberta. "
            "As ferramentas locais funcionam normalmente; respostas conversacionais completas entram com o provider de IA."
        )
