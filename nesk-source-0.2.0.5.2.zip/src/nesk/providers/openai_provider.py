from __future__ import annotations

import os

from nesk.core.identity import BASE_IDENTITY
from nesk.core.models import Message
from nesk.providers.base import AIProvider


class OpenAIProvider(AIProvider):
    def __init__(self, model: str) -> None:
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError('Provider OpenAI não instalado. Rode: pip install -e ".[openai]"') from exc
        if not os.getenv("OPENAI_API_KEY"):
            raise RuntimeError("OPENAI_API_KEY não configurada.")
        self.model = model
        # Keep retries/timeouts bounded so a lost connection cannot freeze the UI forever.
        self.client = OpenAI(timeout=30.0, max_retries=1)

    def reply(self, messages: list[Message]) -> str:
        transcript = "\n".join(f"{m.role.value.upper()}: {m.content}" for m in messages)
        response = self.client.responses.create(
            model=self.model,
            instructions=BASE_IDENTITY,
            input=transcript,
        )
        text = (response.output_text or "").strip()
        return text or "Não recebi uma resposta de texto do provider."
