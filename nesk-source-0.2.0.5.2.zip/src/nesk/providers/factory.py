from __future__ import annotations

import logging

from nesk.providers.base import AIProvider
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.providers.openai_provider import OpenAIProvider
from nesk.providers.resilient import ResilientProvider


def create_provider(config: dict) -> AIProvider:
    name = str(config.get("provider", "local")).lower()
    fallback = LocalFallbackProvider()
    if name == "openai":
        try:
            primary = OpenAIProvider(model=str(config.get("model", "gpt-5.6")))
        except Exception as exc:
            if bool(config.get("fallback_to_local", True)):
                logging.getLogger("nesk").warning("provider_init_fallback type=%s", type(exc).__name__)
                return fallback
            raise
        if bool(config.get("fallback_to_local", True)):
            return ResilientProvider(primary, fallback)
        return primary
    return fallback
