@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "NESK_VERSION=DEV"
if exist "VERSION" set /p NESK_VERSION=<VERSION
title NESK %NESK_VERSION% - Validacao

if not exist ".venv\Scripts\python.exe" (
  echo [ERRO] Ambiente .venv nao encontrado. Rode INICIAR_NESK.bat primeiro.
  pause
  exit /b 1
)

echo ============================================================
echo              NESK %NESK_VERSION% - VALIDACAO LOCAL
echo ============================================================
echo.
".venv\Scripts\python.exe" scripts\preflight.py
if errorlevel 1 goto :error
".venv\Scripts\python.exe" scripts\diagnostics.py
if errorlevel 1 goto :error
".venv\Scripts\python.exe" scripts\voice_diagnostics.py
if errorlevel 1 goto :error
".venv\Scripts\python.exe" -m nesk.app --self-check
if errorlevel 1 goto :error

echo.
echo [OK] Validacao local concluida sem erro.
pause
exit /b 0

:error
echo.
echo [ERRO] A validacao encontrou um problema.
pause
exit /b 1
