@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title NESK - Qualidade de Voz PT-BR

if not exist ".venv\Scripts\python.exe" (
    echo [ERRO] Ambiente .venv nao encontrado.
    echo Rode INICIAR_NESK.bat primeiro para instalar/sincronizar a versao.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" scripts\voice_quality_probe.py
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo [FALHA] O teste terminou com erro %RC%.
pause
exit /b %RC%
