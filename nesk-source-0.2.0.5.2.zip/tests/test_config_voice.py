import json
from pathlib import Path

from nesk.core.config import DEFAULTS


ROOT = Path(__file__).resolve().parents[1]


def test_first_listen_voice_is_enabled_by_default():
    assert DEFAULTS["voice"]["enabled"] is True
    assert DEFAULTS["voice"]["mode"] == "push_to_talk"
    assert DEFAULTS["voice"]["stt"]["provider"] == "local"
    assert DEFAULTS["voice"]["stt"]["language"] == "pt"


def test_audio_storage_is_disabled_by_default():
    assert DEFAULTS["privacy"]["store_audio"] is False
    assert DEFAULTS["voice"]["store_audio"] is False


def test_serialized_defaults_match_runtime_defaults_exactly():
    serialized = json.loads((ROOT / "config" / "defaults.json").read_text(encoding="utf-8"))
    assert serialized == DEFAULTS


def test_shared_pipeline_capture_defaults_have_one_endpoint_and_one_safety_guard():
    capture = DEFAULTS["voice"]["capture"]
    assert capture["min_seconds"] == 0.12
    assert capture["endpoint_silence_ms"] > 0
    assert capture["endpoint_min_speech_ms"] > 0
    assert "silence_rms_dbfs" not in capture
    assert "silence_peak_dbfs" not in capture
    assert "minimum_signal_rms_dbfs" not in capture
    assert "minimum_signal_peak_dbfs" not in capture
