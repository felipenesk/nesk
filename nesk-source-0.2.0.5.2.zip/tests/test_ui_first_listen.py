from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication

from nesk.core.assistant import NeskCore
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.storage.database import ConversationStore
from nesk.tools.registry import ToolRegistry
from nesk.ui.main_window import MainWindow


class FakeVoiceService:
    enabled = True
    recording = False

    def close(self):
        pass


def test_first_listen_window_exposes_enabled_push_to_talk(tmp_path: Path):
    app = QApplication.instance() or QApplication([])
    core = NeskCore(
        provider=LocalFallbackProvider(),
        store=ConversationStore(tmp_path / "ui.db"),
        tools=ToolRegistry(),
    )
    window = MainWindow(
        core,
        {"ai": {"provider": "local"}, "ui": {"system_refresh_ms": 5000}},
        FakeVoiceService(),
    )
    try:
        assert window.voice_button.isEnabled()
        assert window.voice_button.text() == "SEGURE"
        assert "FIRST LISTEN" in window.windowTitle().upper()
        assert "PUSH-TO-TALK" in window.voice_footer.text()
    finally:
        window.shutdown()
        window.deleteLater()
        app.processEvents()
        core.close()
