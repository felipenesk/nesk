from __future__ import annotations

import json
import threading
from pathlib import Path

import pytest

from nesk.core.assistant import NeskCore
from nesk.core.permissions import RiskLevel
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.semantic.contracts import SemanticCandidate, SemanticSource
from nesk.semantic.provider import OpenAISemanticProvider
from nesk.storage.database import ConversationStore
from nesk.tools.base import Tool, ToolResult
from nesk.tools.registry import ToolRegistry


class RecordingTool(Tool):
    risk = RiskLevel.LOW
    side_effects = True

    def __init__(self, name: str, *, succeeds: bool = True) -> None:
        self.name = name
        self.description = name
        self.succeeds = succeeds
        self.calls: list[dict] = []

    def run(self, **kwargs) -> ToolResult:
        self.calls.append(kwargs)
        if not self.succeeds:
            return ToolResult(False, "falhou")
        data = {
            "program": kwargs.get("name"),
            "query": kwargs.get("query"),
            "engine": kwargs.get("engine"),
        }
        return ToolResult(True, "ok", {key: value for key, value in data.items() if value is not None})


class StaticSemanticProvider:
    def __init__(self, candidate: SemanticCandidate | None = None, error: Exception | None = None) -> None:
        self.candidate = candidate
        self.error = error
        self.requests = []
        self.closed = False

    def interpret(self, request, *, cancel):
        self.requests.append(request)
        if self.error is not None:
            raise self.error
        return self.candidate

    def close(self) -> None:
        self.closed = True


class BlockingSemanticProvider:
    def __init__(self) -> None:
        self.started = threading.Event()
        self.cancelled = threading.Event()
        self.closed = False

    def interpret(self, request, *, cancel):
        self.started.set()
        cancel.wait(2.0)
        if cancel.is_set():
            self.cancelled.set()
            return None
        return SemanticCandidate("programs.open", "discord", 0.99, SemanticSource.PROVIDER)

    def close(self) -> None:
        self.closed = True


def make_core(
    tmp_path: Path,
    *,
    semantic_provider=None,
    semantic_timeout_seconds: float = 0.2,
    succeeds: bool = True,
    include_open: bool = True,
    clarification_ttl_turns: int = 2,
) -> tuple[NeskCore, dict[str, RecordingTool]]:
    registry = ToolRegistry()
    tools: dict[str, RecordingTool] = {}
    names = ["programs.close", "browser.search", "browser.open_named", "browser.open_default"]
    if include_open:
        names.insert(0, "programs.open")
    for name in names:
        tool = RecordingTool(name, succeeds=succeeds)
        registry.register(tool)
        tools[name] = tool
    core = NeskCore(
        provider=LocalFallbackProvider(),
        store=ConversationStore(tmp_path / "nesk.db"),
        tools=registry,
        semantic_provider=semantic_provider,
        semantic_timeout_seconds=semantic_timeout_seconds,
        clarification_ttl_turns=clarification_ttl_turns,
    )
    return core, tools


@pytest.mark.parametrize(
    "phrase",
    [
        "boto o Discord",
        "bota o Discord pra rodar",
        "manda abrir o Discord",
        "coloca o Discord aí",
        "consegue abrir o Discord?",
        "dá pra abrir o Discord?",
        "abre essa parada aí, o Discord",
    ],
)
def test_natural_open_forms_resolve_to_canonical_program(tmp_path: Path, phrase: str):
    core, tools = make_core(tmp_path)
    result = core.handle(phrase)
    assert result.action == "programs.open"
    assert tools["programs.open"].calls[-1]["name"] == "discord"


def test_clear_local_commands_remain_direct_and_offline(tmp_path: Path):
    core, tools = make_core(tmp_path)
    assert core.handle("abre o Discord").action == "programs.open"
    assert core.handle("fecha o Discord").action == "programs.close"
    assert core.handle("inicia o Discord").action == "programs.open"
    assert core.handle("pesquisa Minecraft").action == "browser.search"
    assert core.handle("abre o YouTube").action == "browser.open_named"
    assert tools["browser.search"].calls[-1] == {"query": "minecraft", "engine": "google"}


@pytest.mark.parametrize(
    "phrase",
    [
        "não abre o Discord",
        "não fecha o Discord",
        "eu gosto de abrir o Discord",
        "eu estava pensando em fechar o Discord",
        "como eu faço para abrir o Discord?",
        "talvez abre o Discord",
        "seria legal abrir o Discord",
        "me explica como fechar o Discord",
        "gosto de procurar mods no Google",
        "ele abre o Discord quando joga",
        "abre o Discord como?",
    ],
)
def test_semantic_guard_never_executes_negation_questions_or_hypotheses(tmp_path: Path, phrase: str):
    core, tools = make_core(tmp_path)
    result = core.handle(phrase)
    assert result.action is None
    assert all(not tool.calls for tool in tools.values())


def test_program_reference_uses_only_recent_compatible_program(tmp_path: Path):
    core, tools = make_core(tmp_path)
    core.handle("abre o Discord")
    result = core.handle("fecha ele")
    assert result.action == "programs.close"
    assert tools["programs.close"].calls[-1]["name"] == "discord"


def test_search_reference_resolves_subject_and_engine(tmp_path: Path):
    core, tools = make_core(tmp_path)
    core.handle("pesquisa Minecraft 1.12.2 no Google")
    result = core.handle("agora procura isso no YouTube")
    assert result.action == "browser.search"
    assert tools["browser.search"].calls[-1] == {"query": "minecraft 1.12.2", "engine": "youtube"}


def test_search_continuation_uses_active_topic_only(tmp_path: Path):
    core, tools = make_core(tmp_path)
    core.handle("pesquisa Ice and Fire")
    result = core.handle("agora vê no YouTube")
    assert result.action == "browser.search"
    assert tools["browser.search"].calls[-1] == {"query": "ice and fire", "engine": "youtube"}


def test_reference_without_compatible_antecedent_asks_instead_of_executing(tmp_path: Path):
    core, tools = make_core(tmp_path)
    result = core.handle("fecha ele")
    assert result.action == "clarification.requested"
    assert not tools["programs.close"].calls


def test_site_context_cannot_be_reinterpreted_as_program_to_close(tmp_path: Path):
    core, tools = make_core(tmp_path)
    core.handle("abre o YouTube")
    result = core.handle("fecha ele")
    assert result.action == "clarification.requested"
    assert not tools["programs.close"].calls


def test_search_reference_without_topic_asks_instead_of_searching_literal_pronoun(tmp_path: Path):
    core, tools = make_core(tmp_path)
    result = core.handle("procura isso")
    assert result.action == "clarification.requested"
    assert not tools["browser.search"].calls


def test_ambiguous_open_enters_clarification_and_named_reply_is_scoped(tmp_path: Path):
    core, tools = make_core(tmp_path)
    first = core.handle("abre aquele negócio")
    assert first.action == "clarification.requested"
    assert core.pending_clarification is not None
    second = core.handle("o Discord")
    assert second.action == "programs.open"
    assert tools["programs.open"].calls[-1]["name"] == "discord"


def test_single_option_clarification_accepts_isso_only_while_pending(tmp_path: Path):
    core, tools = make_core(tmp_path)
    assert core.handle("abre aquele negócio de conversar").action == "clarification.requested"
    assert core.handle("isso").action == "programs.open"
    assert tools["programs.open"].calls[-1]["name"] == "discord"


def test_short_reply_outside_clarification_never_executes(tmp_path: Path):
    core, tools = make_core(tmp_path)
    result = core.handle("isso")
    assert result.action is None
    assert all(not tool.calls for tool in tools.values())


def test_option_indexes_and_no_are_scoped_to_pending_clarification(tmp_path: Path):
    core, tools = make_core(tmp_path)
    assert core.handle("abre Discord e Spotify").action == "clarification.requested"
    assert core.handle("a segunda").action == "programs.open"
    assert tools["programs.open"].calls[-1]["name"] == "spotify"
    assert core.handle("abre aquele negócio").action == "clarification.requested"
    assert core.handle("não").action == "clarification.cancelled"
    assert core.pending_clarification is None


def test_new_topic_invalidates_old_clarification_before_running_new_intent(tmp_path: Path):
    core, tools = make_core(tmp_path)
    assert core.handle("abre aquele negócio").action == "clarification.requested"
    result = core.handle("deixa, pesquisa Minecraft")
    assert result.action == "browser.search"
    assert core.pending_clarification is None
    assert tools["browser.search"].calls[-1]["query"] == "minecraft"


def test_expired_clarification_cannot_be_answered_later(tmp_path: Path):
    core, tools = make_core(tmp_path, clarification_ttl_turns=1)
    assert core.handle("abre aquele negócio").action == "clarification.requested"
    assert core.handle("isso").action == "clarification.ambiguous"
    result = core.handle("Discord")
    assert result.action is None
    assert core.pending_clarification is None
    assert not tools["programs.open"].calls


def test_new_core_has_no_old_clarification_or_reference(tmp_path: Path):
    first, _ = make_core(tmp_path / "first")
    assert first.handle("abre aquele negócio").action == "clarification.requested"
    second, tools = make_core(tmp_path / "second")
    result = second.handle("Discord")
    assert result.action is None
    assert not tools["programs.open"].calls


def test_context_is_recorded_only_after_successful_tool_result(tmp_path: Path):
    core, tools = make_core(tmp_path, succeeds=False)
    assert core.handle("abre Discord").action == "programs.open"
    result = core.handle("fecha ele")
    assert result.action == "clarification.requested"
    assert not tools["programs.close"].calls


def test_semantic_provider_is_structured_and_cannot_execute_directly(tmp_path: Path):
    provider = StaticSemanticProvider(
        SemanticCandidate("programs.open", "discord", 0.95, SemanticSource.PROVIDER)
    )
    core, tools = make_core(tmp_path, semantic_provider=provider)
    result = core.handle("por gentileza, abra o Discord em funcionamento")
    assert result.action == "programs.open"
    assert tools["programs.open"].calls[-1]["name"] == "discord"
    assert provider.requests


def test_provider_candidate_is_rechecked_against_request_modality(tmp_path: Path):
    provider = StaticSemanticProvider(
        SemanticCandidate("programs.open", "discord", 0.99, SemanticSource.PROVIDER)
    )
    core, tools = make_core(tmp_path, semantic_provider=provider)
    resolution = core.resolver.resolve_provider_candidate(
        "gosto de abrir o Discord enquanto jogo", provider.candidate
    )
    assert resolution.safety_blocked
    assert not resolution.intent
    assert all(not tool.calls for tool in tools.values())


@pytest.mark.parametrize(
    "candidate",
    [
        SemanticCandidate("system.shell", "cmd /c calc", 0.99, SemanticSource.PROVIDER),
        SemanticCandidate("programs.open", "cmd /c calc", 0.99, SemanticSource.PROVIDER),
        SemanticCandidate("programs.open", "discord", 0.20, SemanticSource.PROVIDER),
    ],
)
def test_invalid_or_low_confidence_provider_candidate_fails_closed(tmp_path: Path, candidate: SemanticCandidate):
    provider = StaticSemanticProvider(candidate)
    core, tools = make_core(tmp_path, semantic_provider=provider)
    result = core.handle("por gentileza, abra o Discord em funcionamento")
    assert result.action is None
    assert all(not tool.calls for tool in tools.values())


def test_unregistered_semantic_action_is_not_executed(tmp_path: Path):
    provider = StaticSemanticProvider(
        SemanticCandidate("programs.open", "discord", 0.99, SemanticSource.PROVIDER)
    )
    core, tools = make_core(tmp_path, semantic_provider=provider, include_open=False)
    result = core.handle("por gentileza, abra o Discord em funcionamento")
    assert result.action is None
    assert all(not tool.calls for tool in tools.values())


def test_provider_failure_and_timeout_fall_back_without_tool_execution(tmp_path: Path):
    failed = StaticSemanticProvider(error=RuntimeError("offline"))
    core, tools = make_core(tmp_path / "failed", semantic_provider=failed)
    assert core.handle("por gentileza, abra o Discord em funcionamento").action is None
    assert all(not tool.calls for tool in tools.values())

    slow = BlockingSemanticProvider()
    timed, timed_tools = make_core(
        tmp_path / "timed", semantic_provider=slow, semantic_timeout_seconds=0.01
    )
    result = timed.handle("por gentileza, abra o Discord em funcionamento")
    assert result.action is None
    assert slow.cancelled.wait(0.5)
    assert all(not tool.calls for tool in timed_tools.values())
    timed.close()


@pytest.mark.parametrize(
    "payload",
    [
        "not json",
        '{"action":"programs.open"}',
        '{"action":"system.shell","target":"cmd","confidence":0.9,"clarification_required":false,"extra":1}',
        '{"action":"programs.open","target":"discord","confidence":"high","clarification_required":false}',
        '{"action":"programs.open","target":"discord","confidence":0.9,"clarification_required":false,"entities":{"shell":"cmd"}}',
    ],
)
def test_openai_semantic_parser_rejects_invalid_json_or_schema(payload: str):
    assert OpenAISemanticProvider.parse_candidate(payload) is None


def test_openai_semantic_parser_accepts_only_closed_valid_candidate_schema():
    candidate = OpenAISemanticProvider.parse_candidate(
        '{"action":"programs.open","target":"discord","confidence":0.94,'
        '"clarification_required":false,"entities":{"program":"discord"},"options":[]}'
    )
    assert candidate is not None
    assert candidate.action == "programs.open"
    assert candidate.target == "discord"
    assert candidate.source is SemanticSource.PROVIDER


def test_semantic_provider_receives_minimized_request_not_conversation_history(tmp_path: Path):
    provider = StaticSemanticProvider(None)
    core, _ = make_core(tmp_path, semantic_provider=provider)
    core.handle("minha senha secreta de teste não deve sair no próximo pedido")
    core.handle("por gentileza, abra o Discord em funcionamento")
    assert provider.requests
    payload = provider.requests[-1].provider_payload()
    serialized = json.dumps(payload, ensure_ascii=False)
    assert "senha secreta" not in serialized
    assert "messages" not in payload
    assert "paths" not in payload


def test_newer_turn_cancels_and_discards_late_semantic_result(tmp_path: Path):
    provider = BlockingSemanticProvider()
    core, tools = make_core(tmp_path, semantic_provider=provider, semantic_timeout_seconds=1.0)
    holder = []
    thread = threading.Thread(
        target=lambda: holder.append(core.handle("por gentileza, abra o Discord em funcionamento"))
    )
    thread.start()
    assert provider.started.wait(0.5)
    second = core.handle("abre Discord")
    thread.join(1.0)
    assert second.action == "programs.open"
    assert provider.cancelled.wait(0.5)
    assert holder and holder[0].action == "intent.stale"
    assert len(tools["programs.open"].calls) == 1
    core.close()


def test_close_cancels_inflight_semantic_request_before_any_tool_runs(tmp_path: Path):
    provider = BlockingSemanticProvider()
    core, tools = make_core(tmp_path, semantic_provider=provider, semantic_timeout_seconds=1.0)
    holder = []
    thread = threading.Thread(
        target=lambda: holder.append(core.handle("por gentileza, abra o Discord em funcionamento"))
    )
    thread.start()
    assert provider.started.wait(0.5)
    core.close()
    thread.join(1.0)
    assert provider.cancelled.wait(0.5)
    assert holder and holder[0].action == "runtime.closed"
    assert all(not tool.calls for tool in tools.values())
