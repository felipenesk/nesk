from nesk.core.models import Message, Role
from nesk.providers.local_fallback import LocalFallbackProvider


def reply(text: str) -> str:
    return LocalFallbackProvider().reply([Message(Role.USER, text)])


def test_calling_nesk_alone_gets_short_presence_reply():
    assert reply("NESK") == "Fala. Tô aqui."


def test_local_fallback_does_not_pretend_to_be_full_ai():
    answer = reply("o que você acha do meu projeto?")
    assert "fallback" in answer.lower()


def test_thanks_is_natural():
    assert reply("valeu") == "Tamo junto."
