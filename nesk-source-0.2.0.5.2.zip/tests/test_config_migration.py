from __future__ import annotations

import json
from pathlib import Path

from nesk.core.config import load_config


def test_old_config_is_merged_and_rewritten(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("NESK_DATA_DIR", str(tmp_path))
    (tmp_path / "config.json").write_text(
        json.dumps({"ai": {"provider": "local"}, "ui": {"minimize_to_tray": False}}),
        encoding="utf-8",
    )
    config, root = load_config()
    assert root == tmp_path
    assert config["_config_version"] == 10
    assert config["voice"]["speaker_verification"] is False
    assert config["ui"]["theme"] == "monochrome"
    assert config["ui"]["minimize_to_tray"] is False
    saved = json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))
    assert saved["_config_version"] == 10
    assert "speaker_verification" in saved["voice"]


def test_corrupt_config_is_preserved(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("NESK_DATA_DIR", str(tmp_path))
    (tmp_path / "config.json").write_text("{not-json", encoding="utf-8")
    config, _ = load_config()
    assert config["_config_version"] == 10
    backups = list(tmp_path.glob("config.corrupt.*.json"))
    assert len(backups) == 1
    assert backups[0].read_text(encoding="utf-8") == "{not-json"
    assert json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))["_config_version"] == 10


def test_environment_provider_override_is_not_written_to_disk(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("NESK_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("NESK_AI_PROVIDER", "openai")
    config, _ = load_config()
    assert config["ai"]["provider"] == "openai"
    saved = json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))
    assert saved["ai"]["provider"] == "local"


def test_semantic_context_defaults_are_opt_in_and_persisted_safely(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("NESK_DATA_DIR", str(tmp_path))
    config, _ = load_config()
    assert config["semantic"]["provider"] == "none"
    assert config["semantic"]["allow_remote"] is False
    assert config["semantic"]["reference_ttl_turns"] == 3
    saved = json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))
    assert saved["semantic"] == config["semantic"]


def test_semantic_environment_override_is_runtime_only(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("NESK_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("NESK_SEMANTIC_PROVIDER", "openai")
    monkeypatch.setenv("NESK_SEMANTIC_ALLOW_REMOTE", "true")
    config, _ = load_config()
    assert config["semantic"]["provider"] == "openai"
    assert config["semantic"]["allow_remote"] is True
    saved = json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))
    assert saved["semantic"]["provider"] == "none"
    assert saved["semantic"]["allow_remote"] is False


def test_foundation_schema_2_migrates_to_first_listen_without_enabling_audio_storage(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("NESK_DATA_DIR", str(tmp_path))
    old = {
        "_config_version": 2,
        "voice": {"enabled": False, "store_audio": False},
        "privacy": {"store_audio": False},
    }
    (tmp_path / "config.json").write_text(json.dumps(old), encoding="utf-8")
    config, _ = load_config()
    assert config["_config_version"] == 10
    assert config["voice"]["enabled"] is True
    assert config["voice"]["stt"]["provider"] == "local"
    assert config["voice"]["stt"]["local_model"] == "small"
    assert config["voice"]["store_audio"] is False
    assert config["privacy"]["store_audio"] is False


def test_schema_3_explicit_voice_disable_is_preserved(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("NESK_DATA_DIR", str(tmp_path))
    current = {"_config_version": 3, "voice": {"enabled": False}}
    (tmp_path / "config.json").write_text(json.dumps(current), encoding="utf-8")
    config, _ = load_config()
    assert config["voice"]["enabled"] is False
    assert config["_config_version"] == 10
    assert config["voice"]["stt"]["language"] == "pt"
    assert "NESK" in config["voice"]["stt"]["hotwords"]
    saved = json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))
    assert saved["_config_version"] == 10
    assert saved["voice"]["enabled"] is False


def test_schema_4_migrates_voice_hardening_defaults_without_resetting_stt(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("NESK_DATA_DIR", str(tmp_path))
    current = {
        "_config_version": 4,
        "voice": {
            "enabled": True,
            "capture": {"min_seconds": 0.4},
            "stt": {"local_model": "small", "beam_size": 7},
        },
    }
    (tmp_path / "config.json").write_text(json.dumps(current), encoding="utf-8")
    config, _ = load_config()
    assert config["_config_version"] == 10
    assert config["voice"]["capture"]["min_seconds"] == 0.4
    assert config["voice"]["capture"]["endpoint_speech_rms_dbfs"] == -60.0
    assert config["voice"]["stt"]["beam_size"] == 7
    saved = json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))
    assert saved["_config_version"] == 10
    assert "silence_rms_dbfs" not in saved["voice"]["capture"]
    assert "silence_peak_dbfs" not in saved["voice"]["capture"]
    assert "minimum_signal_rms_dbfs" not in saved["voice"]["capture"]
    assert "minimum_signal_peak_dbfs" not in saved["voice"]["capture"]


def test_schema_5_migrates_capture_readiness_and_stt_quality_defaults(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("NESK_DATA_DIR", str(tmp_path))
    current = {
        "_config_version": 5,
        "voice": {
            "capture": {"min_seconds": 0.33},
            "stt": {"beam_size": 6, "hotwords": ["NESK", "YouTube"]},
        },
    }
    (tmp_path / "config.json").write_text(json.dumps(current), encoding="utf-8")
    config, _ = load_config()
    assert config["_config_version"] == 10
    assert config["voice"]["capture"]["min_seconds"] == 0.33
    assert config["voice"]["capture"]["startup_timeout_ms"] == 750
    assert config["voice"]["capture"]["post_roll_ms"] == 160
    assert config["voice"]["stt"]["beam_size"] == 6
    assert config["voice"]["stt"]["no_speech_threshold"] == 0.80
    assert "short_retry_enabled" not in config["voice"]["stt"]


def test_schema_6_migrates_speech_pipeline_defaults_without_overwriting_user_choices(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("NESK_DATA_DIR", str(tmp_path))
    current = {
        "_config_version": 6,
        "voice": {
            "capture": {"post_roll_ms": 140},
            "stt": {"beam_size": 8, "local_model": "small"},
        },
    }
    (tmp_path / "config.json").write_text(json.dumps(current), encoding="utf-8")
    config, _ = load_config()
    assert config["_config_version"] == 10
    assert config["voice"]["capture"]["post_roll_ms"] == 140
    assert config["voice"]["capture"]["block_ms"] == 20
    assert config["voice"]["stt"]["beam_size"] == 8
    assert "command_retry_enabled" not in config["voice"]["stt"]
    assert "frontend_enabled" not in config["voice"]["stt"]
    assert config["privacy"]["store_audio"] is False


def test_schema_7_removes_stacked_speech_hotfixes_but_keeps_explicit_choices(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("NESK_DATA_DIR", str(tmp_path))
    current = {
        "_config_version": 7,
        "voice": {
            "capture": {
                "device": 3,
                "min_seconds": 0.31,
                "silence_rms_dbfs": -55.0,
                "silence_peak_dbfs": -40.0,
            },
            "stt": {
                "local_model": "base",
                "beam_size": 8,
                "command_retry_enabled": True,
                "short_retry_enabled": True,
                "frontend_normalize_enabled": True,
                "quality_max_no_speech_prob": 0.72,
            },
        },
    }
    (tmp_path / "config.json").write_text(json.dumps(current), encoding="utf-8")

    config, _ = load_config()

    assert config["_config_version"] == 10
    assert config["voice"]["capture"]["device"] == 3
    assert config["voice"]["capture"]["min_seconds"] == 0.31
    assert config["voice"]["stt"]["local_model"] == "base"
    assert config["voice"]["stt"]["beam_size"] == 8
    for key in (
        "silence_rms_dbfs",
        "silence_peak_dbfs",
        "command_retry_enabled",
        "short_retry_enabled",
        "frontend_normalize_enabled",
        "quality_max_no_speech_prob",
    ):
        section = config["voice"]["capture"] if key.startswith("silence_") else config["voice"]["stt"]
        assert key not in section

    saved = json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))
    assert saved["_config_version"] == 10
    assert "command_retry_enabled" not in saved["voice"]["stt"]
