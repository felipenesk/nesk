from __future__ import annotations

from pathlib import Path

import pytest

from nesk.core.assistant import NeskCore
from nesk.core.permissions import PermissionDecision, PermissionPolicy, RiskLevel
from nesk.platform.windows.program_directory import DiscoveryRecord, ProgramDirectory, ProgramSource
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.semantic.contracts import SemanticCandidate
from nesk.tools.base import Tool, ToolResult
from nesk.tools.registry import ToolRegistry
from nesk.storage.database import ConversationStore


class RecordingTool(Tool):
    side_effects = True

    def __init__(
        self,
        name: str,
        *,
        risk: RiskLevel = RiskLevel.LOW,
        failed_names: set[str] | None = None,
    ) -> None:
        self.name = name
        self.description = name
        self.risk = risk
        self.failed_names = failed_names or set()
        self.calls: list[dict[str, object]] = []

    def run(self, **kwargs) -> ToolResult:
        self.calls.append(dict(kwargs))
        name = str(kwargs.get("name") or "")
        if name in self.failed_names:
            return ToolResult(False, f"falhou {name}", {"program": name})
        data: dict[str, object] = {}
        if self.name.startswith("programs."):
            data["program"] = name
        if self.name == "browser.search":
            data["query"] = kwargs.get("query")
            data["engine"] = kwargs.get("engine")
        return ToolResult(True, f"{self.name}:{name or kwargs.get('query', '')}", data)


class TrackingRegistry(ToolRegistry):
    def __init__(self, policy: PermissionPolicy | None = None) -> None:
        super().__init__(policy)
        self.executions: list[tuple[str, bool, dict[str, object]]] = []

    def execute(self, tool_name: str, *, confirmed: bool = False, **kwargs) -> ToolResult:
        self.executions.append((tool_name, confirmed, dict(kwargs)))
        return super().execute(tool_name, confirmed=confirmed, **kwargs)


class SequencePolicy(PermissionPolicy):
    def __init__(self, decisions: list[str]) -> None:
        self.decisions = list(decisions)
        self.calls: list[RiskLevel] = []

    def decide(self, risk: RiskLevel) -> str:
        self.calls.append(risk)
        return self.decisions.pop(0) if self.decisions else PermissionDecision.ALLOW


class ProbeSemanticProvider:
    def __init__(self) -> None:
        self.requests = []

    def interpret(self, request, *, cancel):
        self.requests.append(request)
        return SemanticCandidate("programs.open", "inventado", 0.99)

    def close(self) -> None:
        return None


def make_core(
    tmp_path: Path,
    *,
    directory: ProgramDirectory | None = None,
    semantic_provider: ProbeSemanticProvider | None = None,
    open_tool: RecordingTool | None = None,
    close_tool: RecordingTool | None = None,
    reference_ttl_turns: int = 3,
) -> tuple[NeskCore, TrackingRegistry, dict[str, RecordingTool]]:
    registry = TrackingRegistry()
    tools = {
        "programs.open": open_tool or RecordingTool("programs.open"),
        "programs.close": close_tool or RecordingTool("programs.close"),
        "browser.search": RecordingTool("browser.search"),
        "browser.open_named": RecordingTool("browser.open_named"),
        "browser.open_default": RecordingTool("browser.open_default"),
        "system.status": RecordingTool("system.status"),
    }
    for tool in tools.values():
        registry.register(tool)
    return (
        NeskCore(
            provider=LocalFallbackProvider(),
            store=ConversationStore(tmp_path / "nesk.db"),
            tools=registry,
            program_directory=directory,
            semantic_provider=semantic_provider,
            reference_ttl_turns=reference_ttl_turns,
        ),
        registry,
        tools,
    )


def open_plural_group(core: NeskCore) -> None:
    assert core.handle("abre Spotify e Discord").action == "clarification.requested"
    assert core.handle("os dois").action == "clarification.batch.completed"


@pytest.mark.parametrize(
    "phrase",
    ["fecha eles", "fecha ambos", "fecha os dois", "agora fecha os 2", "agora fecha ambos"],
)
def test_plural_program_reference_rebuilds_two_fresh_close_intents_in_order(tmp_path: Path, phrase: str):
    core, registry, tools = make_core(tmp_path)
    open_plural_group(core)
    assert core.session_context.recent_program_group == ("spotify", "discord")

    result = core.handle(phrase)

    assert result.action == "program_group.completed"
    assert [call["name"] for call in tools["programs.close"].calls] == ["spotify", "discord"]
    close_executions = [entry for entry in registry.executions if entry[0] == "programs.close"]
    assert [entry[2]["name"] for entry in close_executions] == ["spotify", "discord"]
    assert all(not entry[1] for entry in close_executions)


def test_plural_group_is_ram_only_ids_and_never_sent_to_semantic_provider(tmp_path: Path):
    semantic = ProbeSemanticProvider()
    core, _registry, _tools = make_core(tmp_path / "first", semantic_provider=semantic)
    open_plural_group(core)

    assert core.session_context.recent_program_group == ("spotify", "discord")
    assert all(isinstance(identifier, str) for identifier in core.session_context.recent_program_group)
    assert not hasattr(core.session_context, "launch_target")
    result = core.handle("fecha eles")
    assert result.action == "program_group.completed"
    assert not semantic.requests

    fresh, _fresh_registry, fresh_tools = make_core(tmp_path / "fresh")
    assert fresh.session_context.recent_program_group == ()
    assert fresh.handle("fecha eles").action == "clarification.requested"
    assert not fresh_tools["programs.close"].calls


def test_plural_group_is_cleared_on_logical_core_shutdown(tmp_path: Path):
    core, _registry, _tools = make_core(tmp_path)
    open_plural_group(core)
    assert core.session_context.recent_program_group == ("spotify", "discord")

    core.close()

    assert core.session_context.recent_program_group == ()


def test_plural_open_rebuilds_fresh_intents_only_with_a_compatible_group(tmp_path: Path):
    semantic = ProbeSemanticProvider()
    core, registry, tools = make_core(tmp_path / "active", semantic_provider=semantic)
    open_plural_group(core)

    result = core.handle("abre eles")

    assert result.action == "program_group.completed"
    assert [call["name"] for call in tools["programs.open"].calls] == ["spotify", "discord", "spotify", "discord"]
    replay_executions = [entry for entry in registry.executions if entry[0] == "programs.open"][-2:]
    assert [entry[2]["name"] for entry in replay_executions] == ["spotify", "discord"]
    assert core.session_context.recent_program_group == ()
    assert not semantic.requests

    fresh_semantic = ProbeSemanticProvider()
    fresh, _fresh_registry, fresh_tools = make_core(tmp_path / "fresh", semantic_provider=fresh_semantic)
    assert fresh.handle("abre eles").action == "clarification.requested"
    assert fresh.handle("não abre eles").action is None
    assert not fresh_tools["programs.open"].calls
    assert not fresh_semantic.requests


@pytest.mark.parametrize("intervening", ["pesquisa eles", "quanto de RAM estou usando?"])
def test_plural_group_does_not_survive_an_intervening_successful_tool(tmp_path: Path, intervening: str):
    core, _registry, tools = make_core(tmp_path)
    open_plural_group(core)
    core.handle(intervening)

    assert core.handle("fecha eles").action == "clarification.requested"
    assert not tools["programs.close"].calls


def test_plural_group_expires_and_preserves_modality_safety(tmp_path: Path):
    core, _registry, tools = make_core(tmp_path, reference_ttl_turns=1)
    open_plural_group(core)
    assert core.handle("conversa sem ação").action is None
    assert core.handle("mais uma conversa sem ação").action is None
    assert core.handle("fecha eles").action == "clarification.requested"
    assert core.handle("não fecha eles").action is None
    assert not tools["programs.close"].calls


def test_plural_close_keeps_per_intent_permission_boundary(tmp_path: Path):
    core, registry, tools = make_core(tmp_path)
    open_plural_group(core)
    registry.policy = SequencePolicy(
        [PermissionDecision.ALLOW, PermissionDecision.CONFIRM, PermissionDecision.ALLOW]
    )

    first = core.handle("fecha eles")
    assert first.action == "confirmation.requested"
    assert [call["name"] for call in tools["programs.close"].calls] == ["spotify"]

    second = core.handle("sim")
    assert second.action == "program_group.completed"
    assert [call["name"] for call in tools["programs.close"].calls] == ["spotify", "discord"]
    close_executions = [entry for entry in registry.executions if entry[0] == "programs.close"]
    assert [(entry[1], entry[2]["name"]) for entry in close_executions] == [
        (False, "spotify"),
        (False, "discord"),
        (True, "discord"),
    ]


def test_plural_close_confirmation_cancel_does_not_run_remaining_intent(tmp_path: Path):
    core, registry, tools = make_core(tmp_path)
    open_plural_group(core)
    registry.policy = SequencePolicy([PermissionDecision.ALLOW, PermissionDecision.CONFIRM])

    assert core.handle("fecha ambos").action == "confirmation.requested"
    cancelled = core.handle("não")

    assert cancelled.action == "confirmation.cancelled"
    assert [call["name"] for call in tools["programs.close"].calls] == ["spotify"]


def test_plural_close_reports_partial_outcome_honestly(tmp_path: Path):
    close_tool = RecordingTool("programs.close", failed_names={"discord"})
    core, _registry, tools = make_core(tmp_path, close_tool=close_tool)
    open_plural_group(core)

    result = core.handle("fecha os dois")

    assert result.action == "program_group.partial"
    assert "1 de 2" in result.text
    assert [call["name"] for call in tools["programs.close"].calls] == ["spotify", "discord"]


def test_failed_plural_close_consumes_group_and_cannot_be_replayed(tmp_path: Path):
    close_tool = RecordingTool("programs.close", failed_names={"spotify", "discord"})
    core, _registry, tools = make_core(tmp_path, close_tool=close_tool)
    open_plural_group(core)

    result = core.handle("fecha eles")

    assert result.action == "program_group.failed"
    assert core.session_context.recent_program_group == ()
    assert core.handle("fecha eles").action == "clarification.requested"
    assert [call["name"] for call in tools["programs.close"].calls] == ["spotify", "discord"]


def test_failed_then_cancelled_plural_close_consumes_group_before_confirmation(tmp_path: Path):
    close_tool = RecordingTool("programs.close", risk=RiskLevel.MEDIUM, failed_names={"spotify"})
    core, registry, tools = make_core(tmp_path, close_tool=close_tool)
    open_plural_group(core)
    registry.policy = SequencePolicy([PermissionDecision.ALLOW, PermissionDecision.CONFIRM])

    assert core.handle("fecha ambos").action == "confirmation.requested"
    assert core.session_context.recent_program_group == ()
    assert core.handle("não").action == "confirmation.cancelled"
    assert core.handle("fecha ambos").action == "clarification.requested"
    assert [call["name"] for call in tools["programs.close"].calls] == ["spotify"]


def test_failed_multi_open_never_creates_or_reuses_a_plural_group(tmp_path: Path):
    open_tool = RecordingTool("programs.open", failed_names={"notepad"})
    core, _registry, tools = make_core(tmp_path, open_tool=open_tool)
    open_plural_group(core)
    # The first group did not use Notepad and exists.
    assert core.session_context.recent_program_group == ("spotify", "discord")

    assert core.handle("abre Discord e Bloco de Notas").action == "clarification.requested"
    result = core.handle("os dois")
    assert result.action == "clarification.batch.partial"
    assert core.session_context.recent_program_group == ()
    assert core.handle("fecha eles").action == "clarification.requested"
    assert not tools["programs.close"].calls


def test_confirmed_multi_open_records_group_only_after_both_registry_successes(tmp_path: Path):
    open_tool = RecordingTool("programs.open", risk=RiskLevel.MEDIUM)
    core, _registry, tools = make_core(tmp_path, open_tool=open_tool)

    assert core.handle("abre Spotify e Discord").action == "clarification.requested"
    assert core.handle("os dois").action == "confirmation.requested"
    assert core.session_context.recent_program_group == ()
    assert core.handle("sim").action == "confirmation.requested"
    assert core.session_context.recent_program_group == ()
    assert core.handle("sim").action == "clarification.batch.completed"
    assert [call["name"] for call in tools["programs.open"].calls] == ["spotify", "discord"]
    assert core.session_context.recent_program_group == ("spotify", "discord")


@pytest.mark.parametrize(
    "phrase",
    [
        "abre Riot Client",
        "abre Logitech G Hub",
        "abre Batata Premium",
        # An arbitrary explicit label may contain a known alias; it must still
        # remain unknown instead of inheriting the embedded trusted program.
        "abre Discord falso",
        "abre Riot Client Discord",
    ],
)
def test_explicit_unknown_program_has_typed_local_ux_without_tool_or_provider(tmp_path: Path, phrase: str):
    semantic = ProbeSemanticProvider()
    core, _registry, tools = make_core(tmp_path, semantic_provider=semantic)

    result = core.handle(phrase)

    assert result.action == "programs.open.unrecognized"
    assert "não reconheço" in result.text.lower()
    assert not tools["programs.open"].calls
    assert not semantic.requests


def test_missing_unknown_and_ambiguous_programs_remain_distinct(tmp_path: Path):
    missing, _registry, missing_tools = make_core(tmp_path / "missing")
    assert missing.handle("abre aquele negócio").action == "clarification.requested"
    assert not missing_tools["programs.open"].calls

    trusted = tmp_path / "Program Files"
    first = trusted / "Riot One" / "RiotClient.exe"
    second = trusted / "Riot Two" / "RiotClient.exe"
    first.parent.mkdir(parents=True)
    second.parent.mkdir(parents=True)
    first.write_bytes(b"")
    second.write_bytes(b"")
    directory = ProgramDirectory(
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (
            DiscoveryRecord("Riot Client One", str(first), ProgramSource.APP_PATHS, aliases=("riot client",)),
            DiscoveryRecord("Riot Client Two", str(second), ProgramSource.APP_PATHS, aliases=("riot client",)),
        ),
    )
    directory.refresh()
    ambiguous, _registry, ambiguous_tools = make_core(tmp_path / "ambiguous", directory=directory)
    result = ambiguous.handle("abre Riot Client")
    assert result.action == "clarification.requested"
    assert ambiguous.pending_clarification is not None
    assert len(ambiguous.pending_clarification.request.options) == 2
    assert not ambiguous_tools["programs.open"].calls


def test_unknown_reply_to_pending_program_clarification_does_not_fall_back(tmp_path: Path):
    semantic = ProbeSemanticProvider()
    core, _registry, tools = make_core(tmp_path, semantic_provider=semantic)
    assert core.handle("abre aquele negócio").action == "clarification.requested"

    result = core.handle("Riot Client")

    assert result.action == "programs.open.unrecognized"
    assert "riot client" in result.text.lower()
    assert not tools["programs.open"].calls
    assert not semantic.requests


@pytest.mark.parametrize("reply", ["qual a hora?", "como faço isso?", "oi, tudo bem?"])
def test_pending_program_question_does_not_turn_new_conversation_into_unknown_name(tmp_path: Path, reply: str):
    core, _registry, tools = make_core(tmp_path)
    assert core.handle("abre aquele negócio").action == "clarification.requested"

    result = core.handle(reply)

    assert result.action is None
    assert "não reconheço" not in result.text.lower()
    assert not tools["programs.open"].calls


def test_mixed_known_unknown_open_keeps_its_own_permission_prompt(tmp_path: Path):
    open_tool = RecordingTool("programs.open", risk=RiskLevel.MEDIUM)
    core, registry, tools = make_core(tmp_path, open_tool=open_tool)

    first = core.handle("abre Discord e Riot Client")
    assert first.action == "confirmation.requested"
    assert not tools["programs.open"].calls

    second = core.handle("sim")
    assert second.action == "programs.open.partial"
    assert [call["name"] for call in tools["programs.open"].calls] == ["discord"]
    executions = [entry for entry in registry.executions if entry[0] == "programs.open"]
    assert [(entry[1], entry[2]["name"]) for entry in executions] == [(False, "discord"), (True, "discord")]
    assert "riot client" in second.text.lower()


@pytest.mark.parametrize(
    ("phrase", "riot_before_discord"),
    [("abre Discord e Riot Client", False), ("abre Riot Client e Discord", True)],
)
def test_mixed_known_unknown_opens_only_known_canonical_target_and_preserves_report_order(
    tmp_path: Path,
    phrase: str,
    riot_before_discord: bool,
):
    semantic = ProbeSemanticProvider()
    core, registry, tools = make_core(tmp_path, semantic_provider=semantic)

    result = core.handle(phrase)

    assert result.action == "programs.open.partial"
    assert [call["name"] for call in tools["programs.open"].calls] == ["discord"]
    open_executions = [entry for entry in registry.executions if entry[0] == "programs.open"]
    assert [entry[2]["name"] for entry in open_executions] == ["discord"]
    assert "riot client" in result.text.lower()
    if riot_before_discord:
        assert result.text.lower().index("riot client") < result.text.lower().index("programs.open:discord")
    assert core.session_context.recent_program_group == ()
    assert not semantic.requests


def test_all_unknown_mixed_request_runs_no_tool_and_reports_each_target(tmp_path: Path):
    core, _registry, tools = make_core(tmp_path)
    result = core.handle("abre Riot Client e Batata Premium")

    assert result.action == "programs.open.unrecognized"
    assert "riot client" in result.text.lower()
    assert "batata premium" in result.text.lower()
    assert result.text.lower().index("riot client") < result.text.lower().index("batata premium")
    assert not tools["programs.open"].calls


def test_all_known_multi_select_and_order_are_preserved(tmp_path: Path):
    core, _registry, tools = make_core(tmp_path)
    request = core.handle("abre Discord e Bloco de Notas")
    assert request.action == "clarification.requested"
    assert core.pending_clarification is not None
    assert [option.label for option in core.pending_clarification.request.options] == ["Discord", "Bloco de Notas"]
    assert core.handle("ambos").action == "clarification.batch.completed"
    assert [call["name"] for call in tools["programs.open"].calls] == ["discord", "notepad"]


def test_removed_discovered_group_entry_fails_closed_before_close_tool(tmp_path: Path):
    trusted = tmp_path / "Program Files"
    executable = trusted / "Riot" / "RiotApp.exe"
    executable.parent.mkdir(parents=True)
    executable.write_bytes(b"")
    records = [DiscoveryRecord("Riot App", str(executable), ProgramSource.APP_PATHS)]
    directory = ProgramDirectory(trusted_roots=(trusted,), app_paths_reader=lambda: tuple(records))
    directory.refresh()
    core, _registry, tools = make_core(tmp_path, directory=directory)

    assert core.handle("abre Spotify e Riot App").action == "clarification.requested"
    assert core.handle("os dois").action == "clarification.batch.completed"
    assert len(core.session_context.recent_program_group) == 2
    records.clear()
    directory.refresh()

    result = core.handle("fecha eles")
    assert result.action == "clarification.requested"
    assert core.session_context.recent_program_group == ()
    assert not tools["programs.close"].calls


@pytest.mark.parametrize("phrase", [r"abre C:\\Users\\mibg2\\Downloads\\evil.exe", "abre cmd /c calc"])
def test_unsafe_explicit_target_is_not_echoed_or_sent_to_a_tool(tmp_path: Path, phrase: str):
    semantic = ProbeSemanticProvider()
    core, _registry, tools = make_core(tmp_path, semantic_provider=semantic)

    result = core.handle(phrase)

    assert result.action == "programs.open.unrecognized"
    assert "downloads" not in result.text.lower()
    assert "cmd /c" not in result.text.lower()
    assert not tools["programs.open"].calls
    assert not semantic.requests
