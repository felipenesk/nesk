from __future__ import annotations

from pathlib import Path

import pytest

from nesk.core.assistant import NeskCore
from nesk.core.intent import Intent
from nesk.core.permissions import RiskLevel
from nesk.nlu.confirmation import ConfirmationDecision, classify_confirmation
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.storage.database import ConversationStore
from nesk.tools.base import Tool, ToolParameter, ToolResult
from nesk.tools.registry import ToolRegistry


class ConfirmedTool(Tool):
    name = "test.confirmed"
    description = "test confirmation"
    risk = RiskLevel.MEDIUM
    side_effects = True
    parameters = (ToolParameter("name"),)

    def __init__(self) -> None:
        self.calls = 0

    def run(self, **kwargs):
        self.calls += 1
        return ToolResult(True, "feito")


def make_core(tmp_path: Path) -> tuple[NeskCore, ConfirmedTool]:
    tool = ConfirmedTool()
    registry = ToolRegistry()
    registry.register(tool)
    core = NeskCore(
        provider=LocalFallbackProvider(),
        store=ConversationStore(tmp_path / "confirm.db"),
        tools=registry,
    )
    core.router.route = lambda _: Intent("test.confirmed", {"name": "x"}, 1.0)  # type: ignore[method-assign]
    return core, tool


@pytest.mark.parametrize(
    "phrase",
    [
        "sim",
        "Sim.",
        "sim, por favor",
        "pode sim",
        "pode, por favor",
        "confirmo",
        "isso mesmo",
        "claro que sim",
        "ok",
        "beleza",
        "NESK, sim por favor",
    ],
)
def test_natural_positive_confirmations_are_clear(phrase: str):
    assert classify_confirmation(phrase) is ConfirmationDecision.CONFIRM


@pytest.mark.parametrize(
    "phrase",
    [
        "não",
        "Não.",
        "não precisa",
        "não, obrigado",
        "melhor não",
        "cancela",
        "deixa quieto",
        "pode deixar",
        "esquece",
        "NESK, não por favor",
    ],
)
def test_natural_negative_confirmations_are_clear(phrase: str):
    assert classify_confirmation(phrase) is ConfirmationDecision.CANCEL


@pytest.mark.parametrize("phrase", ["acho que sim", "sim mas espera", "não sei", "talvez sim", "sim abre o youtube"])
def test_ambiguous_confirmation_never_authorizes(phrase: str):
    assert classify_confirmation(phrase) is ConfirmationDecision.AMBIGUOUS


def test_unrelated_text_is_not_misread_as_confirmation():
    assert classify_confirmation("abre o youtube") is ConfirmationDecision.UNRELATED


def test_sim_por_favor_executes_pending_action(tmp_path: Path):
    core, tool = make_core(tmp_path)
    first = core.handle("faz isso")
    assert first.action == "confirmation.requested"
    second = core.handle("Sim, por favor.")
    assert second.text == "feito"
    assert tool.calls == 1
    assert core.pending_action is None


def test_ambiguous_reply_keeps_pending_without_execution(tmp_path: Path):
    core, tool = make_core(tmp_path)
    core.handle("faz isso")
    result = core.handle("acho que sim")
    assert result.action == "confirmation.ambiguous"
    assert tool.calls == 0
    assert core.pending_action is not None
    final = core.handle("sim")
    assert final.text == "feito"
    assert tool.calls == 1


def test_unrelated_request_expires_pending_as_before(tmp_path: Path):
    core, tool = make_core(tmp_path)
    calls = iter([Intent("test.confirmed", {"name": "x"}, 1.0), None])
    core.router.route = lambda _: next(calls)  # type: ignore[method-assign]
    core.handle("faz isso")
    result = core.handle("oi tudo bem")
    assert result.text
    assert tool.calls == 0
    assert core.pending_action is None
