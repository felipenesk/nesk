from unittest.mock import patch

from nesk.tools.browser import OpenNamedSiteTool, SearchWebTool


def test_search_google_url_encodes_query():
    tool = SearchWebTool()
    with patch("nesk.tools.browser.webbrowser.open", return_value=True) as open_browser:
        result = tool.run(query="ice and fire dragonsteel", engine="google")
    assert result.ok
    url = open_browser.call_args.args[0]
    assert "google.com/search" in url
    assert "ice+and+fire+dragonsteel" in url


def test_search_youtube_uses_youtube_endpoint():
    tool = SearchWebTool()
    with patch("nesk.tools.browser.webbrowser.open", return_value=True) as open_browser:
        result = tool.run(query="dragonsteel tutorial", engine="youtube")
    assert result.ok
    assert "youtube.com/results" in open_browser.call_args.args[0]


def test_search_rejects_unknown_engine():
    result = SearchWebTool().run(query="teste", engine="unknown")
    assert not result.ok


def test_search_rejects_empty_query():
    result = SearchWebTool().run(query="   ")
    assert not result.ok


def test_search_rejects_unreasonably_long_query():
    result = SearchWebTool().run(query="x" * 501)
    assert not result.ok


def test_known_chatgpt_site_opens_without_shell():
    with patch("nesk.tools.browser.webbrowser.open", return_value=True) as open_browser:
        result = OpenNamedSiteTool().run(name="chatgpt")
    assert result.ok
    assert open_browser.call_args.args[0] == "https://chatgpt.com"
