from __future__ import annotations

from types import SimpleNamespace

import numpy as np

from nesk.voice.audio import CapturedAudio
from nesk.voice.stt import FasterWhisperSTTProvider, OpenAITranscriptionSTTProvider, _pcm16_to_mono_float32


def test_pcm_is_resampled_to_whisper_rate():
    samples = (np.sin(np.linspace(0, 4, 4800)) * 1000).astype(np.int16)
    audio = CapturedAudio(samples.tobytes(), 48000)
    result = _pcm16_to_mono_float32(audio)
    assert result.dtype == np.float32
    assert 1590 <= len(result) <= 1610


class FakeWhisperModel:
    def __init__(self, model_size, **kwargs):
        self.model_size = model_size
        self.kwargs = kwargs

    def transcribe(self, waveform, **kwargs):
        assert waveform.dtype == np.float32
        assert kwargs["language"] == "pt"
        assert kwargs["task"] == "transcribe"
        assert kwargs["temperature"] == 0.0
        assert kwargs["condition_on_previous_text"] is False
        assert kwargs["without_timestamps"] is True
        assert kwargs["word_timestamps"] is False
        assert kwargs["vad_filter"] is True
        assert kwargs["vad_parameters"]["speech_pad_ms"] == 180
        assert "repetition_penalty" not in kwargs
        assert "no_repeat_ngram_size" not in kwargs
        assert "NESK" in kwargs["hotwords"]
        assert "YouTube" in kwargs["hotwords"]
        assert "Português brasileiro" in kwargs["initial_prompt"]
        return [
            SimpleNamespace(text=" NESK ", avg_logprob=-0.2),
            SimpleNamespace(text="abre o YouTube ", avg_logprob=-0.4),
        ], SimpleNamespace(language="pt")


def test_local_stt_is_lazy_and_joins_segments(tmp_path):
    created = []

    def factory(model_size, **kwargs):
        created.append((model_size, kwargs))
        return FakeWhisperModel(model_size, **kwargs)

    provider = FasterWhisperSTTProvider(
        model_size="base",
        download_root=tmp_path,
        model_factory=factory,
    )
    assert created == []
    audio = CapturedAudio(b"\x00\x00" * 1600, 16000)
    assert provider.transcribe(audio) == "NESK abre o YouTube"
    assert created and created[0][0] == "base"
    assert provider.last_diagnostics is not None
    assert provider.last_diagnostics.language == "pt"
    assert provider.last_diagnostics.segment_count == 2
    assert provider.last_diagnostics.average_logprob == -0.30000000000000004
    assert provider.last_diagnostics.model_load_count == 1
    assert not hasattr(provider.last_diagnostics, "text")


class FakeTranscriptions:
    def __init__(self):
        self.kwargs = None

    def create(self, **kwargs):
        self.kwargs = kwargs
        return SimpleNamespace(text="olá NESK")


class FakeOpenAIClient:
    def __init__(self):
        self.audio = SimpleNamespace(transcriptions=FakeTranscriptions())


def test_cloud_stt_uses_in_memory_wav_only():
    client = FakeOpenAIClient()
    provider = OpenAITranscriptionSTTProvider(client=client)
    audio = CapturedAudio(b"\x00\x00" * 1600, 16000)
    assert provider.transcribe(audio) == "olá NESK"
    file_obj = client.audio.transcriptions.kwargs["file"]
    assert file_obj.name.endswith(".wav")
    assert file_obj.getbuffer().nbytes > len(audio.pcm16)


def test_local_stt_tuning_is_configurable(tmp_path):
    captured = {}

    class Model:
        def __init__(self, model_size, **kwargs):
            captured["model_size"] = model_size

        def transcribe(self, waveform, **kwargs):
            captured["kwargs"] = kwargs
            return [], SimpleNamespace(language="pt")

    provider = FasterWhisperSTTProvider(
        model_size="small",
        download_root=tmp_path,
        model_factory=Model,
        beam_size=7,
        patience=1.2,
        initial_prompt="PT-BR literal",
        hotwords="NESK YouTube",
        vad_threshold=0.55,
        vad_min_speech_ms=60,
        vad_min_silence_ms=140,
        vad_speech_pad_ms=420,
        max_new_tokens=48,
    )
    audio = CapturedAudio(b"\x00\x00" * 1600, 16000)
    assert provider.transcribe(audio) == ""
    kwargs = captured["kwargs"]
    assert kwargs["beam_size"] == 7
    assert kwargs["patience"] == 1.2
    assert kwargs["initial_prompt"] == "PT-BR literal"
    assert kwargs["hotwords"] == "NESK YouTube"
    assert kwargs["vad_parameters"] == {
        "threshold": 0.55,
        "min_speech_duration_ms": 60,
        "min_silence_duration_ms": 140,
        "speech_pad_ms": 420,
    }
    assert kwargs["max_new_tokens"] == 48


def test_local_stt_close_releases_loaded_model(tmp_path):
    created = []

    def factory(model_size, **kwargs):
        model = FakeWhisperModel(model_size, **kwargs)
        created.append(model)
        return model

    provider = FasterWhisperSTTProvider(model_factory=factory, download_root=tmp_path)
    provider.transcribe(CapturedAudio(b"\x01\x00" * 1600, 16000))
    assert provider._model is created[0]
    provider.close()
    provider.close()
    assert provider._model is None
    assert provider.last_diagnostics is None


def test_local_stt_decodes_once_and_does_not_reject_high_confidence_speech_for_no_speech_probability(tmp_path):
    calls = 0

    class Model:
        def __init__(self, model_size, **kwargs):
            pass

        def transcribe(self, waveform, **kwargs):
            nonlocal calls
            calls += 1
            return [
                SimpleNamespace(
                    text=" não feche o Discord",
                    avg_logprob=-0.15,
                    no_speech_prob=0.96,
                    compression_ratio=1.0,
                )
            ], SimpleNamespace(language="pt")

    provider = FasterWhisperSTTProvider(download_root=tmp_path, model_factory=Model)
    audio = CapturedAudio(b"\x20\x03" * 16000, 16000)

    assert provider.transcribe(audio) == "não feche o Discord"
    assert calls == 1
    assert provider.last_diagnostics is not None
    assert provider.last_diagnostics.quality_rejected is False


def test_local_stt_rejects_low_confidence_and_repeated_decode_without_content_rewrite(tmp_path):
    responses = iter(
        [
            SimpleNamespace(
                text=" abre o Discord",
                avg_logprob=-1.2,
                no_speech_prob=0.10,
                compression_ratio=1.0,
            ),
            SimpleNamespace(
                text=" se inscreva no canal se inscreva no canal",
                avg_logprob=-0.20,
                no_speech_prob=0.05,
                compression_ratio=1.0,
            ),
        ]
    )

    class Model:
        def __init__(self, model_size, **kwargs):
            pass

        def transcribe(self, waveform, **kwargs):
            return [next(responses)], SimpleNamespace(language="pt")

    provider = FasterWhisperSTTProvider(download_root=tmp_path, model_factory=Model)
    audio = CapturedAudio(b"\x20\x03" * 16000, 16000)

    assert provider.transcribe(audio) == ""
    assert provider.last_diagnostics is not None
    assert provider.last_diagnostics.rejection_reason == "low_confidence"
    assert provider.transcribe(audio) == ""
    assert provider.last_diagnostics is not None
    assert provider.last_diagnostics.rejection_reason == "repetitive_decode"


def test_cloud_stt_close_closes_client_when_supported():
    class Client(FakeOpenAIClient):
        def __init__(self):
            super().__init__()
            self.closed = 0

        def close(self):
            self.closed += 1

    client = Client()
    provider = OpenAITranscriptionSTTProvider(client=client)
    provider.close()
    provider.close()
    assert client.closed == 1
