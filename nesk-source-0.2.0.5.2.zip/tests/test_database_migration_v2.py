from __future__ import annotations

import sqlite3
from pathlib import Path

from nesk.core.models import Message, Role
from nesk.storage.database import ConversationStore


def test_new_database_does_not_create_migration_backup(tmp_path: Path):
    path = tmp_path / "nesk.db"
    store = ConversationStore(path)
    assert store.schema_version() == 2
    assert not list(tmp_path.glob("*.bak.db"))


def test_legacy_database_gets_pre_migration_backup(tmp_path: Path):
    path = tmp_path / "nesk.db"
    with sqlite3.connect(path) as con:
        con.execute(
            "CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL)"
        )
        con.execute(
            "INSERT INTO messages(role, content, created_at) VALUES ('user','antes','2026-08-20T00:00:00+00:00')"
        )
    store = ConversationStore(path)
    assert store.schema_version() == 2
    backup = tmp_path / "nesk.pre_schema_2.bak.db"
    assert backup.exists()
    with sqlite3.connect(backup) as con:
        assert con.execute("PRAGMA user_version").fetchone()[0] == 0
        assert con.execute("SELECT content FROM messages").fetchone()[0] == "antes"
    assert [m.content for m in store.recent(5)] == ["antes"]


def test_store_releases_windows_database_handle_after_each_operation(tmp_path: Path):
    path = tmp_path / "nesk.db"
    store = ConversationStore(path)
    store.add(Message(Role.USER, "teste"))
    assert [message.content for message in store.recent(1)] == ["teste"]
    # This is especially important on Windows: sqlite Connection.__exit__ does
    # not close the handle, and a release/smoke TemporaryDirectory must remain
    # removable immediately after the store operation finishes.
    path.unlink()
    assert not path.exists()
