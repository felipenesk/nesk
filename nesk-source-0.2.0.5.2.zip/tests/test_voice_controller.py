from __future__ import annotations

from pathlib import Path

from nesk.core.assistant import NeskCore
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.storage.database import ConversationStore
from nesk.tools.registry import ToolRegistry
from nesk.voice.audio import CapturedAudio
from nesk.voice.controller import VoiceController
from nesk.voice.speaker import SpeakerDecision


AUDIO = CapturedAudio(b"\x00\x00" * 8000, 16000)


class FakeSTT:
    def __init__(self, text: str) -> None:
        self.text = text
        self.closed = 0

    def transcribe(self, audio: CapturedAudio) -> str:
        return self.text

    def close(self) -> None:
        self.closed += 1


class FakeTTS:
    def __init__(self) -> None:
        self.spoken: list[str] = []

    def speak(self, text: str) -> None:
        self.spoken.append(text)


class FakeVerifier:
    def __init__(self, accepted: bool, confidence: float) -> None:
        self.accepted = accepted
        self.confidence = confidence

    def verify(self, audio: CapturedAudio) -> SpeakerDecision:
        return SpeakerDecision(self.accepted, self.confidence, "owner", "")


def make_core(tmp_path: Path) -> NeskCore:
    return NeskCore(
        provider=LocalFallbackProvider(),
        store=ConversationStore(tmp_path / "voice.db"),
        tools=ToolRegistry(),
    )


def test_voice_pipeline_reuses_same_core_and_can_speak(tmp_path: Path):
    tts = FakeTTS()
    controller = VoiceController(core=make_core(tmp_path), stt=FakeSTT("oi"), tts=tts)
    result = controller.process_audio(AUDIO)
    assert result.accepted is True
    assert result.transcript == "oi"
    assert result.response == tts.spoken[0]
    assert controller.session.state.value == "idle"


def test_first_listen_does_not_require_tts(tmp_path: Path):
    controller = VoiceController(core=make_core(tmp_path), stt=FakeSTT("oi"), tts=None)
    result = controller.process_audio(AUDIO)
    assert result.accepted is True
    assert result.transcript == "oi"
    assert result.response
    assert controller.session.state.value == "idle"


def test_voice_can_reject_unrecognized_speaker_before_stt(tmp_path: Path):
    tts = FakeTTS()
    controller = VoiceController(
        core=make_core(tmp_path),
        stt=FakeSTT("oi"),
        tts=tts,
        speaker_verifier=FakeVerifier(False, 0.2),
        require_speaker=True,
    )
    result = controller.process_audio(AUDIO)
    assert result.accepted is False
    assert not tts.spoken


def test_begin_and_cancel_listening_is_deterministic(tmp_path: Path):
    controller = VoiceController(core=make_core(tmp_path), stt=FakeSTT("oi"))
    controller.begin_listening()
    assert controller.session.state.value == "listening"
    controller.cancel_listening()
    assert controller.session.state.value == "idle"


def test_legacy_controller_close_releases_its_stt_once(tmp_path: Path):
    stt = FakeSTT("oi")
    controller = VoiceController(core=make_core(tmp_path), stt=stt)

    controller.close()
    controller.close()

    assert stt.closed == 1
