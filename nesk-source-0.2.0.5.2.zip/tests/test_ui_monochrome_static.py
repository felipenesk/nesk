from pathlib import Path
import re


def test_ui_stylesheet_remains_monochrome():
    source = Path("src/nesk/ui/main_window.py").read_text(encoding="utf-8")
    colors = set(re.findall(r"#[0-9a-fA-F]{6}", source))
    assert colors
    non_gray = [c for c in colors if not (c[1:3].lower() == c[3:5].lower() == c[5:7].lower())]
    assert non_gray == []
