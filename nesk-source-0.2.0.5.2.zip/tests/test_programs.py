from unittest.mock import patch

from nesk.platform.windows.programs import ProgramLaunchError, ProgramTarget, WindowsProgramCatalog
from nesk.tools.programs import CloseProgramTool, OpenProgramTool


def test_launch_notepad_uses_safe_argv_without_shell_or_close_fds():
    catalog = WindowsProgramCatalog()
    target = catalog.resolve("notepad")
    assert target is not None
    with patch("nesk.platform.windows.programs.subprocess.Popen") as popen:
        catalog.launch(target)
    popen.assert_called_once_with([target.executable], shell=False)


def test_open_program_tool_converts_launch_error_to_result():
    catalog = WindowsProgramCatalog()
    tool = OpenProgramTool(catalog)
    with patch.object(catalog, "resolve", return_value=ProgramTarget("bloco de notas", "notepad.exe")), \
         patch.object(catalog, "launch", side_effect=ProgramLaunchError("teste")):
        result = tool.run(name="bloco de notas")
    assert not result.ok
    assert "Não consegui abrir" in result.message


def test_open_program_can_preserve_natural_display_name():
    catalog = WindowsProgramCatalog()
    tool = OpenProgramTool(catalog)
    with patch.object(catalog, "resolve", return_value=ProgramTarget("notepad", "notepad.exe")), \
         patch.object(catalog, "launch"):
        result = tool.run(name="notepad", display_name="bloco de notas")
    assert result.ok
    assert result.message == "Abri bloco de notas."


def test_discord_process_matching_is_limited_to_exact_allowlist():
    catalog = WindowsProgramCatalog()
    assert catalog.process_matches("discord", "Discord.exe")
    assert catalog.process_matches("discord", "DiscordCanary.exe")
    assert catalog.process_matches("discord", "DiscordPTB.exe")
    assert not catalog.process_matches("discord", "Update.exe")
    assert not catalog.process_matches("discord", "DiscordFoo.exe")


def test_close_discord_waits_for_exact_process_after_recent_catalog_launch():
    catalog = WindowsProgramCatalog()
    tool = CloseProgramTool(catalog)

    class Proc:
        def __init__(self):
            self.info = {"name": "Discord.exe", "exe": r"C:\\Discord\\app-1.0.0\\Discord.exe"}
            self.terminated = 0

        def terminate(self):
            self.terminated += 1

    proc = Proc()
    # The launch authorization test is separate.  Seed only the bounded
    # recent-launch state here so this process-polling regression remains
    # independent from whether Discord is installed on the test host.
    catalog._mark_recent_launch("discord")
    with patch("nesk.tools.programs.psutil.process_iter", side_effect=[[], [proc]]), \
         patch("nesk.tools.programs.time.sleep") as sleep:
        result = tool.run(name="discord", display_name="Discord")

    assert result.ok
    assert proc.terminated == 1
    sleep.assert_called_once()
    assert catalog.recent_launch_wait_seconds("discord") == 0.0


def test_close_absent_discord_does_not_poll_without_recent_launch():
    catalog = WindowsProgramCatalog()
    tool = CloseProgramTool(catalog)
    with patch("nesk.tools.programs.psutil.process_iter", return_value=[]), \
         patch("nesk.tools.programs.time.sleep") as sleep:
        result = tool.run(name="discord", display_name="Discord")

    assert not result.ok
    sleep.assert_not_called()


def test_close_discord_never_terminates_the_updater():
    catalog = WindowsProgramCatalog()
    tool = CloseProgramTool(catalog)

    class Updater:
        def __init__(self):
            self.info = {"name": "Update.exe", "exe": r"C:\\Discord\\Update.exe"}
            self.terminated = 0

        def terminate(self):
            self.terminated += 1

    updater = Updater()
    with patch("nesk.tools.programs.psutil.process_iter", return_value=[updater]):
        result = tool.run(name="discord", display_name="Discord")

    assert not result.ok
    assert updater.terminated == 0
