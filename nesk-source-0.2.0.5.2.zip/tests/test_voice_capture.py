from __future__ import annotations

from nesk.voice.capture import MicrophoneCapture


class FakeStream:
    def __init__(self, *, callback, **kwargs):
        self.callback = callback
        self.started = False
        self.closed = False
        self.aborted = False

    def start(self):
        self.started = True
        self.callback(b"\x01\x00" * 1600, 1600, None, None)

    def stop(self):
        pass

    def close(self):
        self.closed = True

    def abort(self):
        self.aborted = True


class FakeSoundDevice:
    def __init__(self):
        self.stream = None

    def query_devices(self, device=None, kind=None):
        if kind == "input":
            return {"name": "Mic padrão", "default_samplerate": 16000, "max_input_channels": 1}
        return [
            {"name": "Saída", "default_samplerate": 48000, "max_input_channels": 0},
            {"name": "Mic padrão", "default_samplerate": 16000, "max_input_channels": 1},
        ]

    def RawInputStream(self, **kwargs):
        self.stream = FakeStream(**kwargs)
        return self.stream


def test_microphone_capture_keeps_audio_in_memory():
    sd = FakeSoundDevice()
    capture = MicrophoneCapture(sounddevice_module=sd, max_seconds=2, post_roll_ms=0)
    capture.start()
    assert capture.recording is True
    audio = capture.stop()
    assert capture.recording is False
    assert audio.sample_rate == 16000
    assert audio.duration_seconds == 0.1
    assert sd.stream.closed is True


def test_device_list_only_returns_input_devices():
    capture = MicrophoneCapture(sounddevice_module=FakeSoundDevice())
    devices = capture.devices()
    assert len(devices) == 1
    assert devices[0].name == "Mic padrão"
