from nesk.core.permissions import RiskLevel
from nesk.tools.base import Tool, ToolResult
from nesk.tools.registry import ToolRegistry


class LowTool(Tool):
    name = "low"
    description = "test"
    risk = RiskLevel.LOW
    def run(self, **kwargs):
        return ToolResult(True, "ok")


class HighTool(Tool):
    name = "high"
    description = "test"
    risk = RiskLevel.HIGH
    def run(self, **kwargs):
        raise AssertionError("blocked tool must not run")


def test_low_executes():
    registry = ToolRegistry()
    registry.register(LowTool())
    assert registry.execute("low").ok


def test_high_is_blocked():
    registry = ToolRegistry()
    registry.register(HighTool())
    result = registry.execute("high")
    assert not result.ok
    assert "bloqueada" in result.message


class NamedArgTool(Tool):
    name = "named"
    description = "test name argument collision"
    risk = RiskLevel.LOW

    def run(self, *, name: str, **kwargs):
        return ToolResult(True, f"received:{name}")


def test_registry_allows_tool_argument_called_name():
    registry = ToolRegistry()
    registry.register(NamedArgTool())
    result = registry.execute("named", name="bloco de notas")
    assert result.ok
    assert result.message == "received:bloco de notas"
