from nesk.tools.system_status import SystemStatusTool, system_disk_root


def test_system_disk_root_not_empty():
    assert system_disk_root()


def test_system_status_returns_metrics():
    result = SystemStatusTool().run()
    assert result.ok
    assert result.data is not None
    assert 0 <= result.data["ram_percent"] <= 100
    assert "nesk_memory_mb" in result.data
