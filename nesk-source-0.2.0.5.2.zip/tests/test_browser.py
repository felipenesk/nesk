from nesk.tools.browser import OpenUrlTool


def test_reject_non_http_url():
    result = OpenUrlTool().run(url="file:///C:/Windows/System32")
    assert not result.ok
