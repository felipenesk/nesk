from pathlib import Path

from nesk.core.assistant import NeskCore
from nesk.core.models import Message
from nesk.providers.base import AIProvider
from nesk.storage.database import ConversationStore
from nesk.tools.registry import ToolRegistry


class CaptureProvider(AIProvider):
    def __init__(self):
        self.calls: list[list[Message]] = []

    def reply(self, messages: list[Message]) -> str:
        self.calls.append(messages)
        return "ok"


def test_session_context_survives_when_persistence_disabled(tmp_path: Path):
    provider = CaptureProvider()
    store = ConversationStore(tmp_path / "nesk.db", enabled=False)
    core = NeskCore(provider=provider, store=store, tools=ToolRegistry(), context_limit=6)
    core.handle("primeira frase")
    core.handle("segunda frase")
    assert any(m.content == "primeira frase" for m in provider.calls[-1])
    assert store.recent(10) == []
