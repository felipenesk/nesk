from __future__ import annotations

import threading
import time
from pathlib import Path

from nesk.core.assistant import NeskCore
from nesk.core.models import AssistantResult
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.semantic.contracts import SemanticCandidate, SemanticSource
from nesk.storage.database import ConversationStore
from nesk.tools.registry import ToolRegistry
from nesk.voice.audio import CapturedAudio
from nesk.voice.controller import VoiceController
from nesk.voice.service import VoiceService
from nesk.voice.speaker import SpeakerDecision


def _audible_audio(seconds: float = 0.5) -> CapturedAudio:
    sample = int(1200).to_bytes(2, "little", signed=True)
    return CapturedAudio(sample * int(16000 * seconds), 16000)


class FakeCapture:
    def __init__(
        self,
        audio: CapturedAudio,
        *,
        overflowed: bool = False,
        warning_on_stop: bool = False,
    ):
        self.audio = audio
        self.recording = False
        self.overflowed = overflowed
        self.backend_warning = False
        self.warning_on_stop = warning_on_stop
        self.cancelled = False

    def start(self):
        self.recording = True

    def stop(self):
        self.recording = False
        if self.warning_on_stop:
            self.backend_warning = True
        return self.audio

    def cancel(self):
        self.recording = False
        self.cancelled = True


class FakeSTT:
    def __init__(self):
        self.calls = 0

    def transcribe(self, audio: CapturedAudio) -> str:
        self.calls += 1
        return "oi"


def core(tmp_path: Path) -> NeskCore:
    return NeskCore(
        provider=LocalFallbackProvider(),
        store=ConversationStore(tmp_path / "voice-service.db"),
        tools=ToolRegistry(),
    )


def config() -> dict:
    return {
        "voice": {
            "enabled": True,
            "mode": "push_to_talk",
            "capture": {"min_seconds": 0.25, "max_seconds": 20.0},
            "stt": {"provider": "local", "local_model": "small"},
        }
    }


def test_voice_service_rejects_tap_too_short(tmp_path: Path):
    c = core(tmp_path)
    controller = VoiceController(core=c, stt=FakeSTT())
    capture = FakeCapture(CapturedAudio(b"\x00\x00" * 1600, 16000))  # 0.1 s
    service = VoiceService(core=c, config=config(), data_root=tmp_path, capture=capture, controller=controller)
    service.start_listening()
    result = service.finish_turn()
    assert result.accepted is False
    assert result.reason == "fala curta demais"
    assert controller.session.state.value == "idle"


def test_voice_service_processes_normal_turn(tmp_path: Path):
    c = core(tmp_path)
    controller = VoiceController(core=c, stt=FakeSTT())
    capture = FakeCapture(_audible_audio())
    service = VoiceService(core=c, config=config(), data_root=tmp_path, capture=capture, controller=controller)
    service.start_listening()
    result = service.finish_turn()
    assert result.accepted is True
    assert result.transcript == "oi"
    assert controller.session.state.value == "idle"


def test_voice_service_close_cancels_capture(tmp_path: Path):
    c = core(tmp_path)
    controller = VoiceController(core=c, stt=FakeSTT())
    capture = FakeCapture(_audible_audio())
    service = VoiceService(core=c, config=config(), data_root=tmp_path, capture=capture, controller=controller)
    service.start_listening()
    service.close()
    assert capture.cancelled is True
    assert controller.session.state.value == "idle"


def test_voice_service_rejects_truncated_overflow(tmp_path: Path):
    c = core(tmp_path)
    controller = VoiceController(core=c, stt=FakeSTT())
    capture = FakeCapture(_audible_audio(), overflowed=True)
    service = VoiceService(core=c, config=config(), data_root=tmp_path, capture=capture, controller=controller)
    service.start_listening()
    result = service.finish_turn()
    assert result.accepted is False
    assert result.reason == "a captura atingiu o limite de duração"
    assert controller.session.state.value == "idle"


def test_voice_service_rechecks_backend_warning_that_arrives_during_stop(tmp_path: Path):
    c = core(tmp_path)
    controller = VoiceController(core=c, stt=FakeSTT())
    capture = FakeCapture(_audible_audio(), warning_on_stop=True)
    service = VoiceService(core=c, config=config(), data_root=tmp_path, capture=capture, controller=controller)

    service.start_listening()
    result = service.finish_turn()

    assert result.accepted is False
    assert "driver do microfone" in result.reason
    assert controller.session.state.value == "idle"


def test_voice_service_preserves_speaker_verification_before_stt_and_core(tmp_path: Path):
    class RejectingVerifier:
        def verify(self, audio: CapturedAudio) -> SpeakerDecision:
            return SpeakerDecision(False, 0.1, "unknown", "voz não reconhecida")

    c = core(tmp_path)
    stt = FakeSTT()
    controller = VoiceController(
        core=c,
        stt=stt,
        speaker_verifier=RejectingVerifier(),
        require_speaker=True,
    )
    service = VoiceService(
        core=c,
        config=config(),
        data_root=tmp_path,
        capture=FakeCapture(_audible_audio()),
        controller=controller,
    )

    service.start_listening()
    result = service.finish_turn()

    assert result.accepted is False
    assert result.reason == "voz não reconhecida"
    assert stt.calls == 0
    assert controller.session.state.value == "idle"


def test_voice_service_close_does_not_wait_for_inflight_stt_and_closes_it_afterward(tmp_path: Path):
    class BlockingSTT:
        def __init__(self):
            self.entered = threading.Event()
            self.release = threading.Event()
            self.closed = 0

        def transcribe(self, audio: CapturedAudio) -> str:
            self.entered.set()
            assert self.release.wait(2.0)
            return "oi"

        def close(self):
            self.closed += 1

    c = core(tmp_path)
    stt = BlockingSTT()
    controller = VoiceController(core=c, stt=stt)
    capture = FakeCapture(_audible_audio())
    service = VoiceService(core=c, config=config(), data_root=tmp_path, capture=capture, controller=controller)
    service.start_listening()
    thread = threading.Thread(target=service.finish_turn)
    thread.start()
    assert stt.entered.wait(1.0)

    started = time.perf_counter()
    service.close()
    elapsed = time.perf_counter() - started

    assert elapsed < 0.25
    assert stt.closed == 0
    stt.release.set()
    thread.join(2.0)
    assert not thread.is_alive()
    assert stt.closed == 1


def test_voice_service_cancel_during_stt_never_routes_the_finished_transcript_to_core(tmp_path: Path):
    class BlockingSTT:
        def __init__(self):
            self.entered = threading.Event()
            self.release = threading.Event()

        def transcribe(self, audio: CapturedAudio) -> str:
            self.entered.set()
            assert self.release.wait(2.0)
            return "abre o Discord"

    c = core(tmp_path)
    handled: list[str] = []

    def handle(text: str) -> AssistantResult:
        handled.append(text)
        return AssistantResult("não deveria executar")

    c.handle = handle  # type: ignore[method-assign]
    stt = BlockingSTT()
    controller = VoiceController(core=c, stt=stt)
    service = VoiceService(
        core=c,
        config=config(),
        data_root=tmp_path,
        capture=FakeCapture(_audible_audio()),
        controller=controller,
    )
    service.start_listening()
    results = []
    thread = threading.Thread(target=lambda: results.append(service.finish_turn()))
    thread.start()
    assert stt.entered.wait(1.0)

    service.cancel()
    stt.release.set()
    thread.join(2.0)

    assert not thread.is_alive()
    assert results and results[0].accepted is False
    assert results[0].reason == "entrada de voz cancelada"
    assert handled == []


def test_voice_cancel_invalidates_inflight_semantic_interpretation_without_touching_stt_pipeline(tmp_path: Path):
    class PhraseSTT:
        def transcribe(self, audio: CapturedAudio) -> str:
            return "por gentileza, abra o Discord em funcionamento"

    class BlockingSemanticProvider:
        def __init__(self) -> None:
            self.entered = threading.Event()
            self.cancelled = threading.Event()

        def interpret(self, request, *, cancel):
            self.entered.set()
            cancel.wait(2.0)
            if cancel.is_set():
                self.cancelled.set()
                return None
            return SemanticCandidate("programs.open", "discord", 0.99, SemanticSource.PROVIDER)

        def close(self) -> None:
            return None

    semantic = BlockingSemanticProvider()
    c = NeskCore(
        provider=LocalFallbackProvider(),
        store=ConversationStore(tmp_path / "voice-semantic.db"),
        tools=ToolRegistry(),
        semantic_provider=semantic,
        semantic_timeout_seconds=1.0,
    )
    controller = VoiceController(core=c, stt=PhraseSTT())
    service = VoiceService(
        core=c,
        config=config(),
        data_root=tmp_path,
        capture=FakeCapture(_audible_audio()),
        controller=controller,
    )
    service.start_listening()
    results = []
    thread = threading.Thread(target=lambda: results.append(service.finish_turn()))
    thread.start()
    assert semantic.entered.wait(1.0)

    started = time.perf_counter()
    service.cancel()
    elapsed = time.perf_counter() - started
    thread.join(1.0)

    assert elapsed < 0.5
    assert semantic.cancelled.wait(0.5)
    assert results and results[0].accepted is False
    assert results[0].reason == "entrada de voz cancelada"
