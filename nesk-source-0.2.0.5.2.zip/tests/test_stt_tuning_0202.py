from __future__ import annotations

import json
from pathlib import Path

from nesk.voice.stt import DEFAULT_PTBR_HOTWORDS, DEFAULT_PTBR_INITIAL_PROMPT


ROOT = Path(__file__).resolve().parents[1]


def test_ptbr_tuning_defaults_are_safe_and_present():
    defaults = json.loads((ROOT / "config/defaults.json").read_text(encoding="utf-8"))
    stt = defaults["voice"]["stt"]
    assert defaults["_config_version"] >= 4
    assert stt["language"] == "pt"
    assert stt["local_model"] == "small"
    assert stt["beam_size"] >= 1
    assert "NESK" in stt["hotwords"]
    assert "YouTube" in stt["hotwords"]
    assert "Transcreva apenas a fala" in stt["initial_prompt"]
    assert stt["max_new_tokens"] <= 96
    # Privacy/safety: tuning vocabulary may bias recognition, but it must not
    # contain instructions to execute, correct or infer actions.
    lowered = stt["initial_prompt"].lower()
    assert "execute" not in lowered
    assert "corrija" not in lowered
    assert "infer" not in lowered
    assert "retry" not in stt


def test_runtime_prompt_and_hotwords_match_release_intent():
    assert "Português brasileiro" in DEFAULT_PTBR_INITIAL_PROMPT
    assert "Transcreva apenas a fala" in DEFAULT_PTBR_INITIAL_PROMPT
    assert "NESK" in DEFAULT_PTBR_HOTWORDS
    assert "YouTube" in DEFAULT_PTBR_HOTWORDS


def test_voice_dependency_requires_hotword_capable_faster_whisper():
    requirements = (ROOT / "requirements.txt").read_text(encoding="utf-8")
    pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert "faster-whisper>=1.2.1,<2" in requirements
    assert "faster-whisper>=1.2.1,<2" in pyproject


def test_probe_never_imports_or_calls_nesk_core():
    probe = (ROOT / "scripts/stt_probe.py").read_text(encoding="utf-8")
    assert "SpeechPipeline" in probe
    assert "NeskCore" not in probe
    assert "core.handle" not in probe
    assert "process_text" not in probe


def test_voice_diagnostics_reports_tuning_without_prompt_or_hotword_content():
    script = (ROOT / "scripts/voice_diagnostics.py").read_text(encoding="utf-8")
    assert "stt_language:" in script
    assert "stt_local_model:" in script
    assert "stt_hotwords_count:" in script
    assert "endpoint_speech_rms_dbfs:" in script
    assert 'print("raw_rms_peak_gate:", "desativado")' in script
    assert 'print("stt_hotwords:",' not in script
    assert 'print("stt_initial_prompt:",' not in script
    assert "command_retry_enabled" not in script
    assert "silence_rms_dbfs" not in script
