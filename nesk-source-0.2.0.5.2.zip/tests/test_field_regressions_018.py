from pathlib import Path

from nesk.core.assistant import NeskCore
from nesk.core.intent_router import LocalIntentRouter
from nesk.core.models import Message, Role
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.storage.database import ConversationStore
from nesk.tools.registry import ToolRegistry


def test_field_typo_pra_min_is_removed_from_google_query():
    intent = LocalIntentRouter().route("pesquisa valorant pra min")
    assert intent is not None
    assert intent.name == "browser.search"
    assert intent.args == {"query": "valorant", "engine": "google"}


def test_field_merged_oque_capabilities_question_is_recognized():
    intent = LocalIntentRouter().route("nesk oque você consegue fazer")
    assert intent is not None
    assert intent.name == "nesk.capabilities"


def test_field_success_open_files_stays_supported():
    intent = LocalIntentRouter().route("consegue abrir meus arquivos rapidinho?")
    assert intent is not None
    assert intent.name == "programs.open"
    assert intent.args["name"] == "explorer"


def test_field_success_open_youtube_with_polite_suffix_stays_supported():
    intent = LocalIntentRouter().route("abre o youtube pra mim")
    assert intent is not None
    assert intent.name == "browser.open_named"
    assert intent.args["name"] == "youtube"


def _reply(text: str) -> str:
    return LocalFallbackProvider().reply([Message(Role.USER, text)])


def test_negative_command_fallback_makes_noop_explicit():
    answer = _reply("não abre o youtube")
    assert "não executei" in answer.lower()


def test_discussion_fallback_makes_noop_explicit():
    answer = _reply("eu gosto de abrir o youtube enquanto jogo")
    assert "não executei" in answer.lower()
    assert "conversa" in answer.lower()


def test_howto_question_fallback_makes_noop_explicit():
    answer = _reply("como eu faço para abrir a calculadora?")
    assert "pergunta" in answer.lower()
    assert "não executei" in answer.lower()


def test_negative_command_never_routes_to_tool():
    assert LocalIntentRouter().route("não abre o youtube") is None


def test_howto_question_never_routes_to_tool():
    assert LocalIntentRouter().route("como eu faço para abrir a calculadora?") is None


def test_core_uses_safe_noop_reply_instead_of_action(tmp_path: Path):
    store = ConversationStore(tmp_path / "nesk.db")
    core = NeskCore(provider=LocalFallbackProvider(), store=store, tools=ToolRegistry())
    result = core.handle("não abre o youtube")
    assert result.action is None
    assert "não executei" in result.text.lower()
