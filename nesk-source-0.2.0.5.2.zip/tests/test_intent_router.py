import pytest

from nesk.core.intent_router import LocalIntentRouter


def route(phrase: str):
    return LocalIntentRouter().route(phrase)


def test_open_program():
    intent = route("NESK, abre o Chrome")
    assert intent is not None
    assert intent.name == "programs.open"
    assert intent.args["name"] == "chrome"


@pytest.mark.parametrize(
    "phrase",
    [
        "quanto de RAM estou usando?",
        "NESK, como está meu PC?",
        "Nesk como ta meu pc",
        "como está o computador?",
        "como que tá meu computador?",
        "qual o uso de CPU?",
        "quanta memória estou usando?",
        "status do PC",
        "meu pc tá como?",
    ],
)
def test_system_status_natural_variants(phrase: str):
    intent = route(phrase)
    assert intent is not None
    assert intent.name == "system.status"


def test_open_url_only_http():
    intent = route("abre https://example.com")
    assert intent is not None
    assert intent.name == "browser.open_url"


@pytest.mark.parametrize(
    "phrase",
    [
        "NESK abre o navegador",
        "Nesk bota o navegador aí",
        "bota o navegador ai",
        "abre o navegador pra mim",
        "pode abrir o navegador?",
        "você pode abrir o meu navegador?",
        "tem como abrir o navegador?",
        "dá pra abrir o navegador por favor?",
        "por favor, abre o navegador rapidinho",
    ],
)
def test_open_default_browser_natural_variants(phrase: str):
    intent = route(phrase)
    assert intent is not None
    assert intent.name == "browser.open_default"


@pytest.mark.parametrize(
    "phrase",
    [
        "abre o YouTube",
        "abre o youtube pra mim",
        "bota o youtube aí",
        "coloca o youtube",
        "pode abrir o youtube?",
        "NESK, abre o youtube aí rapidinho",
        "consegue acessar o youtube pra mim?",
        "entra no youtube por favor",
        "abre o you tube",
    ],
)
def test_open_named_site_natural_variants(phrase: str):
    intent = route(phrase)
    assert intent is not None
    assert intent.name == "browser.open_named"
    assert intent.args["name"] == "youtube"


@pytest.mark.parametrize(
    ("phrase", "program"),
    [
        ("NESK: abre o bloco de notas!", "notepad"),
        ("NESK coloca o chrome aí", "chrome"),
        ("pode abrir o bloco de notas pra mim?", "notepad"),
        ("por favor abre o spotify", "spotify"),
        ("consegue me abrir o discord rapidinho?", "discord"),
        ("abre pra mim o chrome", "chrome"),
    ],
)
def test_open_program_natural_variants(phrase: str, program: str):
    intent = route(phrase)
    assert intent is not None
    assert intent.name == "programs.open"
    assert intent.args["name"] == program


@pytest.mark.parametrize(
    "phrase",
    [
        "eu comprei memória ram ontem",
        "eu gosto de abrir o youtube enquanto jogo",
        "não abre o youtube",
        "como abre o youtube?",
        "talvez eu abra o navegador depois",
    ],
)
def test_discussion_or_negative_text_does_not_trigger_tools(phrase: str):
    assert route(phrase) is None
