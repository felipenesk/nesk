from __future__ import annotations

from pathlib import Path

import numpy as np

from nesk.voice.audio import CapturedAudio
from nesk.voice.capture import CaptureResult
from nesk.voice.frontend import prepare_speech
from nesk.voice.pipeline import SpeechPipeline


def _speech_audio(seconds: float = 0.8, rate: int = 16000) -> CapturedAudio:
    frames = int(seconds * rate)
    samples = np.full(frames, 1400, dtype=np.int16)
    return CapturedAudio(samples.tobytes(), rate)


class FakeCapture:
    def __init__(self, result: CaptureResult) -> None:
        self.result = result
        self.recording = False
        self.cancelled = False
        self.endpoint_waits: list[float | None] = []

    def start(self) -> None:
        self.recording = True

    def wait_for_endpoint(self, *, timeout_seconds: float | None = None) -> bool:
        self.endpoint_waits.append(timeout_seconds)
        return True

    def stop_result(self) -> CaptureResult:
        self.recording = False
        return self.result

    def cancel(self) -> None:
        self.recording = False
        self.cancelled = True


class CountingSTT:
    def __init__(self, text: str = "não feche o Discord") -> None:
        self.text = text
        self.calls = 0
        self.closed = 0
        self.last_diagnostics = None

    def transcribe(self, audio: CapturedAudio) -> str:
        self.calls += 1
        return self.text

    def close(self) -> None:
        self.closed += 1


def _result(
    audio: CapturedAudio,
    *,
    overflowed: bool = False,
    backend_warning: bool = False,
    endpoint_detected: bool = True,
) -> CaptureResult:
    return CaptureResult(
        audio=audio,
        overflowed=overflowed,
        backend_warning=backend_warning,
        first_frame_latency_ms=6.0,
        endpoint_detected=endpoint_detected,
    )


def test_frontend_only_canonicalizes_format_and_preserves_speech_edges():
    rate = 48000
    samples = np.zeros(rate, dtype=np.int16)
    samples[100 : rate - 100] = 900
    audio = CapturedAudio(samples.tobytes(), rate)

    prepared = prepare_speech(audio)

    assert prepared.input_seconds == audio.duration_seconds
    assert prepared.output_seconds == audio.duration_seconds
    assert prepared.waveform.dtype == np.float32
    assert prepared.trimmed is False
    assert prepared.gain_db == 0.0


def test_pipeline_has_one_pre_core_decode_for_each_capture():
    stt = CountingSTT()
    capture = FakeCapture(_result(_speech_audio()))
    pipeline = SpeechPipeline(capture=capture, stt=stt)

    pipeline.start_capture()
    outcome = pipeline.finish_capture()

    assert outcome.accepted is True
    assert outcome.transcript == "não feche o Discord"
    assert stt.calls == 1
    assert outcome.capture is not None
    assert outcome.capture.audio.sample_rate == 16000


def test_pipeline_reads_warning_after_stop_and_never_sends_damaged_audio_to_stt():
    stt = CountingSTT()
    capture = FakeCapture(_result(_speech_audio(), backend_warning=True))
    pipeline = SpeechPipeline(capture=capture, stt=stt)

    pipeline.start_capture()
    outcome = pipeline.finish_capture()

    assert outcome.accepted is False
    assert outcome.reason_code == "capture_backend_warning"
    assert stt.calls == 0


def test_pipeline_rejects_digital_silence_but_not_a_quiet_real_signal():
    silence = CapturedAudio(b"\x00\x00" * 8000, 16000)
    quiet_speech = CapturedAudio((80).to_bytes(2, "little", signed=True) * 8000, 16000)
    silent_stt = CountingSTT()
    quiet_stt = CountingSTT()

    silent = SpeechPipeline(capture=FakeCapture(_result(silence)), stt=silent_stt)
    quiet = SpeechPipeline(capture=FakeCapture(_result(quiet_speech)), stt=quiet_stt)

    silent.start_capture()
    quiet.start_capture()
    assert silent.finish_capture().reason_code == "no_signal"
    assert quiet.finish_capture().accepted is True
    assert silent_stt.calls == 0
    assert quiet_stt.calls == 1


def test_capture_rejection_never_reuses_diagnostics_from_a_previous_turn():
    stt = CountingSTT()
    stt.last_diagnostics = object()
    pipeline = SpeechPipeline(
        capture=FakeCapture(_result(CapturedAudio(b"\x00\x00" * 8000, 16000))),
        stt=stt,
    )

    pipeline.start_capture()
    outcome = pipeline.finish_capture()

    assert outcome.reason_code == "no_signal"
    assert outcome.diagnostics is None


def test_benchmark_style_capture_uses_the_same_pipeline_endpoint_boundary():
    stt = CountingSTT()
    capture = FakeCapture(_result(_speech_audio()))
    pipeline = SpeechPipeline(capture=capture, stt=stt)

    outcome = pipeline.capture_until_endpoint(timeout_seconds=7.0)

    assert outcome.accepted is True
    assert capture.endpoint_waits == [7.0]
    assert stt.calls == 1


def test_probe_and_benchmark_are_pre_core_and_do_not_keep_a_fixed_recording_window():
    root = Path(__file__).resolve().parents[1]
    for relative in ("scripts/stt_probe.py", "scripts/voice_quality_probe.py"):
        source = (root / relative).read_text(encoding="utf-8")
        assert "SpeechPipeline" in source
        assert "NeskCore" not in source
        assert "core.handle" not in source
        assert "RECORD_SECONDS" not in source
        assert "time.sleep(" not in source


def test_pipeline_close_releases_the_provider_once_without_audio_persistence():
    stt = CountingSTT()
    pipeline = SpeechPipeline(capture=FakeCapture(_result(_speech_audio())), stt=stt)

    pipeline.close()
    pipeline.close()

    assert stt.closed == 1
