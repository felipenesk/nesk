from __future__ import annotations

import json
import logging
from pathlib import Path
from unittest.mock import patch

import pytest

from nesk.core.assistant import NeskCore
from nesk.core.intent import Intent
from nesk.core.permissions import RiskLevel
from nesk.core.session_context import (
    ClarificationDecision,
    ClarificationOption,
    ClarificationRequest,
    SessionContext,
)
from nesk.platform.windows.program_directory import (
    DiscoveryRecord,
    ProgramDirectory,
    ProgramResolutionKind,
    ProgramSource,
    ShortcutTarget,
    _is_rejected_machine_app_path,
)
from nesk.platform.windows.programs import ProgramLaunchError, ProgramTarget, WindowsProgramCatalog
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.semantic.contracts import SemanticCandidate, SemanticSource
from nesk.semantic.factory import create_semantic_provider
from nesk.semantic.provider import NullSemanticProvider
from nesk.storage.database import ConversationStore
from nesk.tools.base import Tool, ToolResult
from nesk.tools.programs import CloseProgramTool, OpenProgramTool
from nesk.tools.registry import ToolRegistry


class RecordingTool(Tool):
    risk = RiskLevel.LOW
    side_effects = True

    def __init__(self, name: str, *, fail_names: set[str] | None = None) -> None:
        self.name = name
        self.description = name
        self.fail_names = fail_names or set()
        self.calls: list[dict[str, object]] = []

    def run(self, **kwargs) -> ToolResult:
        self.calls.append(kwargs)
        if str(kwargs.get("name") or "") in self.fail_names:
            return ToolResult(False, f"falhou {kwargs.get('name')}")
        data = {
            "program": kwargs.get("name"),
            "query": kwargs.get("query"),
            "engine": kwargs.get("engine"),
        }
        return ToolResult(True, "ok", {key: value for key, value in data.items() if value is not None})


class ConfirmingOpenTool(RecordingTool):
    risk = RiskLevel.MEDIUM


class ProbeSemanticProvider:
    def __init__(self, candidate: SemanticCandidate | None = None) -> None:
        self.candidate = candidate
        self.requests = []

    def interpret(self, request, *, cancel):
        self.requests.append(request)
        return self.candidate

    def close(self) -> None:
        return None


def make_core(
    tmp_path: Path,
    *,
    directory: ProgramDirectory | None = None,
    provider: ProbeSemanticProvider | None = None,
    open_tool: RecordingTool | None = None,
) -> tuple[NeskCore, dict[str, RecordingTool]]:
    registry = ToolRegistry()
    tools: dict[str, RecordingTool] = {}
    for name in (
        "programs.open",
        "programs.close",
        "browser.search",
        "browser.open_named",
        "browser.open_default",
    ):
        tool = open_tool if name == "programs.open" and open_tool is not None else RecordingTool(name)
        registry.register(tool)
        tools[name] = tool
    core = NeskCore(
        provider=LocalFallbackProvider(),
        store=ConversationStore(tmp_path / "nesk.db"),
        tools=registry,
        semantic_provider=provider,
        program_directory=directory,
    )
    return core, tools


@pytest.mark.parametrize(
    ("phrase", "tool_name", "argument", "expected"),
    [
        ("ae mano abre o Discord aí pra mim", "programs.open", "name", "discord"),
        ("vei bota o Discord pra rodar", "programs.open", "name", "discord"),
        ("mano consegue abrir o bloco de notas pra mim", "programs.open", "name", "notepad"),
        ("tipo assim abre o YouTube aí", "browser.open_named", "name", "youtube"),
        ("po abre a calculadora rapidinho", "programs.open", "name", "calculator"),
        ("cara fecha o Discord aí pra mim", "programs.close", "name", "discord"),
        ("mano bota o Discord aí", "programs.open", "name", "discord"),
    ],
)
def test_colloquial_discourse_preambles_preserve_direct_actions(
    tmp_path: Path,
    phrase: str,
    tool_name: str,
    argument: str,
    expected: str,
):
    core, tools = make_core(tmp_path)
    result = core.handle(phrase)
    assert result.action == tool_name
    assert tools[tool_name].calls[-1][argument] == expected


@pytest.mark.parametrize(
    "phrase",
    [
        "mano não abre o Discord",
        "cara eu estava pensando em abrir o Discord",
        "tipo assim como eu faço pra abrir o Discord?",
        "mano talvez eu abra o Discord depois",
        "vei eu não quero que você abra o Discord",
    ],
)
def test_discourse_preambles_do_not_strip_modality_or_safety(tmp_path: Path, phrase: str):
    provider = ProbeSemanticProvider(SemanticCandidate("programs.open", "discord", 0.99))
    core, tools = make_core(tmp_path, provider=provider)
    result = core.handle(phrase)
    assert result.action is None
    assert not provider.requests
    assert all(not tool.calls for tool in tools.values())


@pytest.mark.parametrize(
    ("follow_up", "engine"),
    [
        ("agora vê no YouTube", "youtube"),
        ("agora procura no YouTube", "youtube"),
        ("procura no YouTube", "youtube"),
        ("agora no YouTube", "youtube"),
        ("agora no Google", "google"),
        ("vê isso no YouTube", "youtube"),
    ],
)
def test_implicit_search_continuation_reuses_only_recent_local_topic(
    tmp_path: Path,
    follow_up: str,
    engine: str,
):
    core, tools = make_core(tmp_path)
    assert core.handle("pesquisa Dark Souls Remastered no Google").action == "browser.search"
    result = core.handle(follow_up)
    assert result.action == "browser.search"
    assert tools["browser.search"].calls[-1] == {
        "query": "dark souls remastered",
        "engine": engine,
    }


@pytest.mark.parametrize("phrase", ["agora procura no YouTube", "agora no YouTube", "vê isso no YouTube"])
def test_engine_only_search_in_new_session_asks_for_topic_without_tool(tmp_path: Path, phrase: str):
    provider = ProbeSemanticProvider(SemanticCandidate("browser.search", "inventado", 0.99))
    core, tools = make_core(tmp_path, provider=provider)
    result = core.handle(phrase)
    assert result.action == "clarification.requested"
    assert not tools["browser.search"].calls
    # The continuation was resolved locally; context did not need to be sent.
    assert not provider.requests


def test_open_entity_on_youtube_is_a_search_not_an_unknown_program(tmp_path: Path):
    core, tools = make_core(tmp_path)
    result = core.handle("abre o canal do alanzoka no YouTube")
    assert result.action == "browser.search"
    assert tools["browser.search"].calls[-1] == {"query": "canal do alanzoka", "engine": "youtube"}
    assert not tools["programs.open"].calls


def test_unknown_open_target_is_not_promoted_to_program_intent(tmp_path: Path):
    core, tools = make_core(tmp_path)
    result = core.handle("abre arquivo aleatório da área de trabalho")
    assert result.action == "programs.open.unrecognized"
    assert not tools["programs.open"].calls


def test_clarification_options_follow_the_user_text_order_and_ordinals(tmp_path: Path):
    core, tools = make_core(tmp_path)
    first = core.handle("abre Discord e Bloco de Notas")
    assert first.action == "clarification.requested"
    assert core.pending_clarification is not None
    assert [option.label for option in core.pending_clarification.request.options] == ["Discord", "Bloco de Notas"]
    assert core.handle("a primeira").action == "programs.open"
    assert tools["programs.open"].calls[-1]["name"] == "discord"

    assert core.handle("abre Discord e Bloco de Notas").action == "clarification.requested"
    assert core.handle("a segunda").action == "programs.open"
    assert tools["programs.open"].calls[-1]["name"] == "notepad"


@pytest.mark.parametrize("reply", ["ambos", "os dois", "as duas", "pode abrir os dois", "abre os dois"])
def test_multi_select_runs_two_prevalidated_open_intents_individually(tmp_path: Path, reply: str):
    core, tools = make_core(tmp_path)
    assert core.handle("abre Discord e Bloco de Notas").action == "clarification.requested"
    request = core.pending_clarification.request if core.pending_clarification is not None else None
    assert request is not None and request.allow_multi_select
    result = core.handle(reply)
    assert result.action == "clarification.batch.completed"
    assert [call["name"] for call in tools["programs.open"].calls] == ["discord", "notepad"]
    assert result.metadata == {"selected": 2, "completed": 2, "succeeded": 2, "failed": 0}


def test_multi_select_reports_partial_result_without_claiming_full_success(tmp_path: Path):
    open_tool = RecordingTool("programs.open", fail_names={"notepad"})
    core, tools = make_core(tmp_path, open_tool=open_tool)
    assert core.handle("abre Discord e Bloco de Notas").action == "clarification.requested"
    result = core.handle("os dois")
    assert result.action == "clarification.batch.partial"
    assert "1 de 2" in result.text
    assert [call["name"] for call in tools["programs.open"].calls] == ["discord", "notepad"]


def test_multi_select_contract_refuses_a_generic_mixed_tool_batch():
    context = SessionContext()
    context.advance_turn()
    context.begin_clarification(
        ClarificationRequest(
            "Escolha.",
            options=(
                ClarificationOption("Discord", Intent("programs.open", {"name": "discord"})),
                ClarificationOption("YouTube", Intent("browser.open_named", {"name": "youtube"})),
            ),
            allow_multi_select=True,
        )
    )
    assert context.consume_clarification("os dois").decision is ClarificationDecision.AMBIGUOUS


def test_multi_select_does_not_bypass_individual_confirmation(tmp_path: Path):
    open_tool = ConfirmingOpenTool("programs.open")
    core, tools = make_core(tmp_path, open_tool=open_tool)
    assert core.handle("abre Discord e Bloco de Notas").action == "clarification.requested"
    selected = core.handle("os dois")
    assert selected.action == "confirmation.requested"
    assert not tools["programs.open"].calls

    second = core.handle("sim")
    assert second.action == "confirmation.requested"
    assert [call["name"] for call in tools["programs.open"].calls] == ["discord"]

    third = core.handle("sim")
    assert third.action == "clarification.batch.completed"
    assert [call["name"] for call in tools["programs.open"].calls] == ["discord", "notepad"]
    assert third.metadata == {"selected": 2, "completed": 2, "succeeded": 2, "failed": 0}


def test_multi_select_confirmation_cancel_does_not_run_any_remaining_intent(tmp_path: Path):
    open_tool = ConfirmingOpenTool("programs.open")
    core, tools = make_core(tmp_path, open_tool=open_tool)
    assert core.handle("abre Discord e Bloco de Notas").action == "clarification.requested"
    assert core.handle("os dois").action == "confirmation.requested"
    cancelled = core.handle("não")
    assert cancelled.action == "confirmation.cancelled"
    assert cancelled.metadata == {"selected": 2, "completed": 0, "succeeded": 0, "failed": 0, "cancelled": 2}
    assert not tools["programs.open"].calls


def _make_executable(root: Path, relative: str) -> Path:
    target = root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(b"")
    return target


def _dynamic_entries(directory: ProgramDirectory):
    return tuple(entry for entry in directory.entries() if entry.launch_target is not None)


def test_program_directory_normalizes_custom_display_and_aliases(tmp_path: Path):
    trusted = tmp_path / "Program Files"
    executable = _make_executable(trusted, "Dark Souls/DarkSoulsRemastered.exe")
    directory = ProgramDirectory(
        {
            "dark souls": {
                "path": str(executable),
                "display_name": "Dark Souls Remastered",
                "aliases": ["ds remastered"],
            }
        },
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (),
    )
    first = directory.resolve("DARK SOULS")
    second = directory.resolve("ds remastered")
    assert first.kind is ProgramResolutionKind.UNIQUE
    assert second.kind is ProgramResolutionKind.UNIQUE
    assert first.entry is not None and second.entry is not None
    assert first.entry.identifier == second.entry.identifier
    assert first.entry.display_name == "Dark Souls Remastered"
    assert str(executable) not in directory.allowed_programs()


def test_program_directory_merges_duplicate_targets_and_flags_same_name_ambiguity(tmp_path: Path):
    trusted = tmp_path / "Program Files"
    hub = _make_executable(trusted, "Logitech/GHub.exe")
    reader_records = [
        DiscoveryRecord("Logitech G Hub", str(hub), ProgramSource.APP_PATHS, aliases=("g hub",)),
        DiscoveryRecord("Logitech G Hub", str(hub), ProgramSource.APP_PATHS, aliases=("logitech hub",)),
    ]
    directory = ProgramDirectory(trusted_roots=(trusted,), app_paths_reader=lambda: tuple(reader_records))
    assert directory.refresh() == 2
    assert len(_dynamic_entries(directory)) == 1
    assert directory.resolve("g hub").entry == directory.resolve("logitech hub").entry

    first = _make_executable(trusted, "Riot/A/RiotClient.exe")
    second = _make_executable(trusted, "Riot/B/RiotClient.exe")
    ambiguous = ProgramDirectory(
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (
            DiscoveryRecord("Riot Client", str(first), ProgramSource.APP_PATHS),
            DiscoveryRecord("Riot Client", str(second), ProgramSource.APP_PATHS),
        ),
    )
    ambiguous.refresh()
    resolution = ambiguous.resolve("riot client")
    assert resolution.kind is ProgramResolutionKind.AMBIGUOUS
    labels = ambiguous.option_labels(resolution.entries)
    assert len(set(labels.values())) == 2


def test_program_directory_rejects_invalid_shortcut_missing_target_and_unsupported_source(tmp_path: Path):
    trusted = tmp_path / "Program Files"
    executable = _make_executable(trusted, "Safe/Safe.exe")
    start_menu = tmp_path / "Start Menu"
    shortcut = start_menu / "Safe Launcher.lnk"
    shortcut.parent.mkdir(parents=True)
    shortcut.write_text("not parsed", encoding="utf-8")

    invalid = ProgramDirectory(
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (
            DiscoveryRecord("Ignored", str(executable), ProgramSource.CACHE),
            DiscoveryRecord("Missing", str(trusted / "Missing.exe"), ProgramSource.APP_PATHS),
        ),
        start_menu_roots=(start_menu,),
        shortcut_resolver=lambda _: ShortcutTarget(str(executable), "--unsafe-argument"),
    )
    invalid.refresh()
    assert invalid.resolve("ignored").kind is ProgramResolutionKind.MISSING
    assert invalid.resolve("missing").kind is ProgramResolutionKind.MISSING
    assert invalid.resolve("safe launcher").kind is ProgramResolutionKind.MISSING

    valid = ProgramDirectory(
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (),
        start_menu_roots=(start_menu,),
        shortcut_resolver=lambda _: ShortcutTarget(str(executable)),
    )
    valid.refresh()
    assert valid.resolve("safe launcher").kind is ProgramResolutionKind.UNIQUE


def test_program_directory_cache_is_discardable_and_stale_entries_fail_closed(tmp_path: Path):
    trusted = tmp_path / "Program Files"
    cache = tmp_path / "program-directory.json"
    cache.write_text("{invalid", encoding="utf-8")
    invalid = ProgramDirectory(
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (),
        cache_path=cache,
    )
    assert not _dynamic_entries(invalid)

    cache.write_text(
        json.dumps(
            {
                "version": 2,
                "entries": [
                    {
                        "display_name": "Stale App",
                        "path": str(trusted / "removed.exe"),
                        "source": "app_paths",
                        "aliases": ["stale"],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    stale = ProgramDirectory(
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (),
        cache_path=cache,
    )
    assert stale.resolve("stale").kind is ProgramResolutionKind.MISSING

    # Even syntactically valid cache data aimed at an existing .exe is never
    # allowed to create a live executable identity before fresh discovery.
    forged_target = _make_executable(trusted, "Forged/Forged.exe")
    cache.write_text(
        json.dumps(
            {
                "version": 2,
                "entries": [
                    {
                        "display_name": "Forged Existing App",
                        "path": str(forged_target),
                        "source": "app_paths",
                        "aliases": ["forged app"],
                        "registry_scope": "machine",
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    forged = ProgramDirectory(
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (),
        cache_path=cache,
    )
    assert forged.resolve("forged app").kind is ProgramResolutionKind.MISSING


def test_custom_config_requires_trusted_existing_executable_and_catalog_rechecks_target(tmp_path: Path):
    trusted = tmp_path / "Program Files"
    valid = _make_executable(trusted, "Custom/Custom.exe")
    untrusted = _make_executable(tmp_path / "Desktop", "Evil.exe")
    unsupported = _make_executable(trusted, "Scripts/unsafe.cmd")
    catalog = WindowsProgramCatalog(
        {
            "custom app": str(valid),
            "desktop evil": str(untrusted),
            "unsafe script": str(unsupported),
            "missing": str(trusted / "gone.exe"),
        },
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (),
    )
    target = catalog.resolve("custom app")
    assert target is not None
    assert Path(target.executable) == valid.resolve()
    assert catalog.resolve("desktop evil") is None
    assert catalog.resolve("unsafe script") is None
    assert catalog.resolve("missing") is None
    with pytest.raises(ProgramLaunchError):
        catalog.launch(ProgramTarget(target.name, str(untrusted)))


def test_catalog_never_authorizes_an_arbitrary_executable_by_known_basename(tmp_path: Path):
    attacker_copy = _make_executable(tmp_path / "Desktop", "notepad.exe")
    catalog = WindowsProgramCatalog(app_paths_reader=lambda: ())
    with patch("nesk.platform.windows.programs.subprocess.Popen") as popen:
        with pytest.raises(ProgramLaunchError):
            catalog.launch(ProgramTarget("notepad", str(attacker_copy)))
    popen.assert_not_called()


def test_builtin_catalog_does_not_resolve_notepad_from_path(tmp_path: Path, monkeypatch):
    attacker_copy = _make_executable(tmp_path / "path", "notepad.exe")
    monkeypatch.setenv("PATH", str(attacker_copy.parent))
    monkeypatch.setenv("SystemRoot", str(attacker_copy.parent))
    monkeypatch.setenv("WINDIR", str(attacker_copy.parent))
    monkeypatch.setenv("PROGRAMFILES", str(attacker_copy.parent))
    monkeypatch.setenv("LOCALAPPDATA", str(attacker_copy.parent))
    catalog = WindowsProgramCatalog(app_paths_reader=lambda: ())
    target = catalog.resolve("notepad")
    assert target is not None
    assert Path(target.executable).resolve() != attacker_copy.resolve()


def test_program_directory_rejects_path_like_public_metadata(tmp_path: Path):
    trusted = tmp_path / "Program Files"
    executable = _make_executable(trusted, "Safe/Safe.exe")
    directory = ProgramDirectory(
        {
            r"C:secret": str(executable),
            "unsafe display": {"path": str(executable), "display_name": r"C:\\Users\\user\\secret.exe"},
        },
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (),
    )
    assert directory.resolve("secret").kind is ProgramResolutionKind.MISSING
    assert directory.resolve("unsafe display").kind is ProgramResolutionKind.MISSING
    assert all("\\" not in entry.display_name and ":" not in entry.display_name for entry in directory.entries())


def test_percent_expansion_uses_windows_owned_roots_not_the_process_environment(tmp_path: Path, monkeypatch):
    trusted = tmp_path / "Program Files"
    safe = _make_executable(trusted, "Safe/Safe.exe")
    poisoned = _make_executable(tmp_path / "Evil", "Safe.exe")
    monkeypatch.setenv("PROGRAMFILES", str(poisoned.parent))
    monkeypatch.setattr(
        "nesk.platform.windows.program_directory._known_windows_environment_paths",
        lambda: {"programfiles": trusted},
    )
    directory = ProgramDirectory(
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (
            DiscoveryRecord("Safe App", r"%ProgramFiles%\Safe\Safe.exe", ProgramSource.APP_PATHS),
            DiscoveryRecord("Unknown Variable", r"%NESK_EVASION%\Safe.exe", ProgramSource.APP_PATHS),
        ),
    )
    directory.refresh()
    safe_entry = directory.resolve("safe app").entry
    assert safe_entry is not None and safe_entry.launch_target == safe.resolve()
    assert safe_entry.launch_target != poisoned.resolve()
    assert directory.resolve("unknown variable").kind is ProgramResolutionKind.MISSING


def test_machine_app_paths_provenance_is_narrow_and_revalidated(tmp_path: Path, monkeypatch):
    # Fixtures cannot create C:\\Riot Games in CI.  A controlled double models
    # a local non-profile machine install while the separate assertions below
    # cover the real rejected path categories.
    external = _make_executable(tmp_path, "Riot Games/RiotClient.exe")
    record = DiscoveryRecord(
        "Riot Client",
        str(external),
        ProgramSource.APP_PATHS,
        registry_scope="machine",
    )
    directory = ProgramDirectory(trusted_roots=(), app_paths_reader=lambda: (record,))
    monkeypatch.setattr("nesk.platform.windows.program_directory._is_rejected_machine_app_path", lambda _: False)
    directory.refresh()
    entry = directory.resolve("riot client").entry
    assert entry is not None and entry.machine_app_path_target
    catalog = WindowsProgramCatalog(directory=directory)
    target = catalog.resolve(entry.identifier)
    assert target is not None
    with patch("nesk.platform.windows.programs.subprocess.Popen") as popen:
        catalog.launch(target)
    popen.assert_called_once_with([target.executable], shell=False)
    external.unlink()
    assert catalog.resolve(entry.identifier) is None

    assert _is_rejected_machine_app_path(Path(r"C:\Users\user\Desktop\notepad.exe"))
    assert _is_rejected_machine_app_path(Path(r"C:\Users\user\Downloads\notepad.exe"))
    assert _is_rejected_machine_app_path(Path(r"\\server\share\app.exe"))


def test_launch_failure_never_exposes_the_local_executable_path(caplog):
    catalog = WindowsProgramCatalog(app_paths_reader=lambda: ())
    target = catalog.resolve("notepad")
    assert target is not None
    tool = OpenProgramTool(catalog)
    with caplog.at_level(logging.ERROR, logger="nesk"), patch(
        "nesk.platform.windows.programs.subprocess.Popen",
        side_effect=OSError(f"blocked {target.executable}"),
    ):
        result = tool.run(name="notepad")
    serialized = json.dumps(result.data or {}, ensure_ascii=False)
    assert target.executable not in result.message
    assert target.executable not in serialized
    assert target.executable not in caplog.text


def test_discovered_program_can_open_but_never_infers_a_close_process(tmp_path: Path):
    trusted = tmp_path / "Program Files"
    executable = _make_executable(trusted, "Games/DarkSouls.exe")
    directory = ProgramDirectory(
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (
            DiscoveryRecord("Dark Souls Remastered", str(executable), ProgramSource.APP_PATHS),
        ),
    )
    directory.refresh()
    entry = directory.resolve("dark souls remastered").entry
    assert entry is not None
    catalog = WindowsProgramCatalog(directory=directory)
    assert catalog.resolve(entry.identifier) is not None
    assert catalog.process_names(entry.identifier) == set()
    result = CloseProgramTool(catalog).run(name=entry.identifier, display_name=entry.display_name)
    assert not result.ok
    assert "não sei fechar" in result.message.lower()
    executable.unlink()
    assert catalog.resolve(entry.identifier) is None


def test_program_directory_refresh_replaces_removed_trusted_records(tmp_path: Path):
    trusted = tmp_path / "Program Files"
    executable = _make_executable(trusted, "Riot/RiotClient.exe")
    records = [DiscoveryRecord("Riot Client", str(executable), ProgramSource.APP_PATHS)]
    directory = ProgramDirectory(trusted_roots=(trusted,), app_paths_reader=lambda: tuple(records))
    directory.refresh()
    assert directory.resolve("riot client").kind is ProgramResolutionKind.UNIQUE
    records.clear()
    directory.refresh()
    assert directory.resolve("riot client").kind is ProgramResolutionKind.MISSING


def test_provider_cannot_invent_a_program_or_smuggle_path_and_payload_has_no_path(tmp_path: Path):
    trusted = tmp_path / "Program Files"
    executable = _make_executable(trusted, "Games/Legitimate.exe")
    directory = ProgramDirectory(
        trusted_roots=(trusted,),
        app_paths_reader=lambda: (DiscoveryRecord("Legitimate", str(executable), ProgramSource.APP_PATHS),),
    )
    directory.refresh()
    provider = ProbeSemanticProvider(SemanticCandidate("programs.open", str(executable), 0.99, SemanticSource.PROVIDER))
    core, tools = make_core(tmp_path, directory=directory, provider=provider)
    result = core.handle("por gentileza, abre o aplicativo secreto")
    assert result.action is None
    assert not tools["programs.open"].calls
    assert provider.requests
    payload = provider.requests[-1].provider_payload()
    serialized = json.dumps(payload, ensure_ascii=False)
    assert str(executable) not in serialized
    assert directory.resolve("legitimate").entry.identifier in payload["allowed_targets"]["programs"]
    assert core.resolver.resolve_provider_candidate(
        "abre algo", SemanticCandidate("programs.open", "programa inventado", 0.99)
    ).intent is None


def test_provider_cannot_turn_a_bare_program_mention_into_an_action(tmp_path: Path):
    provider = ProbeSemanticProvider(SemanticCandidate("programs.open", "discord", 0.99))
    core, tools = make_core(tmp_path, provider=provider)
    result = core.handle("Discord")
    assert result.action is None
    assert not provider.requests
    assert not tools["programs.open"].calls
    assert core.resolver.resolve_provider_candidate("Discord", provider.candidate).intent is None


def test_remote_semantic_string_false_fails_closed():
    assert isinstance(create_semantic_provider({"provider": "openai", "allow_remote": "false"}), NullSemanticProvider)
