from __future__ import annotations

from pathlib import Path

from nesk.core.assistant import NeskCore
from nesk.core.events import EventBus
from nesk.core.intent import Intent, IntentSource
from nesk.core.nodes import NeskNode, NodeRegistry
from nesk.core.permissions import RiskLevel
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.storage.database import ConversationStore
from nesk.storage.memory import MemoryRepository, PrivacyLevel
from nesk.tools.base import Tool, ToolParameter, ToolResult
from nesk.tools.registry import ToolRegistry


class MediumTool(Tool):
    name = "test.medium"
    description = "medium test"
    risk = RiskLevel.MEDIUM
    side_effects = True
    parameters = (ToolParameter("name"),)

    def __init__(self) -> None:
        self.calls = 0

    def run(self, **kwargs):
        self.calls += 1
        return ToolResult(True, "feito")


def make_core(tmp_path: Path, tool: Tool | None = None) -> tuple[NeskCore, ToolRegistry]:
    store = ConversationStore(tmp_path / "nesk.db")
    registry = ToolRegistry()
    if tool:
        registry.register(tool)
    core = NeskCore(provider=LocalFallbackProvider(), store=store, tools=registry)
    return core, registry


def test_intent_has_stable_structured_shape():
    intent = Intent("programs.open", {"name": "chrome"}, 0.97, IntentSource.LOCAL_NLU)
    assert intent.tool_name == "programs.open"
    assert intent.name == "programs.open"
    assert intent.confidence == 0.97
    assert intent.source is IntentSource.LOCAL_NLU


def test_tool_schema_exposes_future_model_metadata():
    registry = ToolRegistry()
    tool = MediumTool()
    registry.register(tool)
    schema = registry.schemas()[0]
    assert schema["name"] == "test.medium"
    assert schema["risk"] == "medium"
    assert schema["side_effects"] is True
    assert schema["parameters"][0]["name"] == "name"


def test_medium_action_requires_confirmation(tmp_path: Path):
    tool = MediumTool()
    core, _ = make_core(tmp_path, tool)
    # Inject an intent to isolate the confirmation behavior from Portuguese NLU.
    core.router.route = lambda _: Intent("test.medium", {"name": "x"}, 1.0)  # type: ignore[method-assign]
    first = core.handle("faz isso")
    assert first.action == "confirmation.requested"
    assert tool.calls == 0
    second = core.handle("sim")
    assert second.text == "feito"
    assert tool.calls == 1


def test_confirmation_can_be_cancelled(tmp_path: Path):
    tool = MediumTool()
    core, _ = make_core(tmp_path, tool)
    core.router.route = lambda _: Intent("test.medium", {"name": "x"}, 1.0)  # type: ignore[method-assign]
    core.handle("faz isso")
    result = core.handle("não")
    assert result.action == "confirmation.cancelled"
    assert tool.calls == 0


def test_unrelated_message_expires_pending_action(tmp_path: Path):
    tool = MediumTool()
    core, _ = make_core(tmp_path, tool)
    calls = iter([Intent("test.medium", {"name": "x"}, 1.0), None])
    core.router.route = lambda _: next(calls)  # type: ignore[method-assign]
    core.handle("faz isso")
    result = core.handle("oi tudo bem")
    assert tool.calls == 0
    assert core.pending_action is None
    assert result.text


def test_local_only_memory_can_never_be_cloud_allowed(tmp_path: Path):
    store = ConversationStore(tmp_path / "nesk.db")
    memory = MemoryRepository(store)
    memory.add(
        kind="preference",
        content="teste",
        privacy=PrivacyLevel.LOCAL_ONLY,
        cloud_allowed=True,
    )
    item = memory.recent(1)[0]
    assert item.privacy is PrivacyLevel.LOCAL_ONLY
    assert item.cloud_allowed is False
    assert item.may_leave_device is False


def test_normal_memory_can_be_explicitly_cloud_allowed(tmp_path: Path):
    store = ConversationStore(tmp_path / "nesk.db")
    memory = MemoryRepository(store)
    memory.add(kind="note", content="public", privacy=PrivacyLevel.NORMAL, cloud_allowed=True)
    assert memory.recent(1)[0].may_leave_device is True


def test_event_bus_does_not_require_message_content():
    bus = EventBus()
    events = []
    bus.subscribe("intent.resolved", events.append)
    bus.publish("intent.resolved", tool="system.status", confidence=0.99)
    assert events[0].data["tool"] == "system.status"
    assert "message" not in events[0].data


def test_node_registry_models_future_devices():
    nodes = NodeRegistry()
    node = NeskNode("pc", "windows", "Meu PC", frozenset({"system.status"}), local=True)
    nodes.register(node)
    assert nodes.get("pc") is node
    assert node.supports("system.status")


def test_event_handler_failure_does_not_break_publisher():
    bus = EventBus()
    received = []

    def broken(_event):
        raise RuntimeError("boom")

    bus.subscribe("x", broken)
    bus.subscribe("x", received.append)
    bus.publish("x", value=1)
    assert received[0].data["value"] == 1


def test_low_confidence_intent_is_rejected(tmp_path: Path):
    tool = MediumTool()
    core, _ = make_core(tmp_path, tool)
    core.router.route = lambda _: Intent("test.medium", {"name": "x"}, 0.50)  # type: ignore[method-assign]
    result = core.handle("talvez faça")
    assert result.action == "intent.rejected"
    assert tool.calls == 0


def test_medium_confidence_low_risk_style_intent_requests_confirmation(tmp_path: Path):
    class LowTool(Tool):
        name = "test.low"
        description = "low"
        risk = RiskLevel.LOW
        def __init__(self): self.calls = 0
        def run(self, **kwargs):
            self.calls += 1
            return ToolResult(True, "ok")

    tool = LowTool()
    core, _ = make_core(tmp_path, tool)
    core.router.route = lambda _: Intent("test.low", {"name": "x"}, 0.80)  # type: ignore[method-assign]
    result = core.handle("acho que abre")
    assert result.action == "confirmation.requested"
    assert tool.calls == 0
    confirmed = core.handle("sim")
    assert confirmed.text == "ok"
    assert tool.calls == 1
