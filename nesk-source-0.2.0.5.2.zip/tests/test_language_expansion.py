import pytest

from nesk.core.intent_router import LocalIntentRouter


@pytest.fixture()
def router():
    return LocalIntentRouter()


@pytest.mark.parametrize(
    ("phrase", "canonical"),
    [
        ("abre a calculadora", "calculator"),
        ("bota a calculadora aí", "calculator"),
        ("pode abrir o calc pra mim?", "calculator"),
        ("abre o paint", "paint"),
        ("roda o paint", "paint"),
        ("abre meus arquivos", "explorer"),
        ("abre o explorador de arquivos", "explorer"),
        ("coloca o explorador aí", "explorer"),
        ("abre o bloco notas", "notepad"),
        ("chama o bloco de notas", "notepad"),
        ("inicia o google chrome", "chrome"),
        ("executa o edge", "edge"),
        ("roda o mozilla firefox", "firefox"),
        ("abre o discord por favor", "discord"),
        ("poderia abrir o spotify?", "spotify"),
    ],
)
def test_program_aliases(router, phrase, canonical):
    intent = router.route(phrase)
    assert intent is not None
    assert intent.name == "programs.open"
    assert intent.args["name"] == canonical


@pytest.mark.parametrize(
    ("phrase", "site"),
    [
        ("abre o chatgpt", "chatgpt"),
        ("entra no chat gpt", "chatgpt"),
        ("acessa o Claude", "claude"),
        ("abre a anthropic", "claude"),
        ("abre o gmail", "gmail"),
        ("abre o zap", "whatsapp"),
        ("entra no whatsapp web", "whatsapp"),
        ("abre a twitch", "twitch"),
        ("abre o reddit", "reddit"),
        ("abre o spotify no navegador", "spotify_web"),
        ("entra no github", "github"),
    ],
)
def test_site_aliases(router, phrase, site):
    intent = router.route(phrase)
    assert intent is not None
    assert intent.name == "browser.open_named"
    assert intent.args["name"] == site


@pytest.mark.parametrize(
    ("phrase", "query", "engine"),
    [
        ("pesquisa dragonsteel armor", "dragonsteel armor", "google"),
        ("NESK pesquisa dragonsteel armor pra mim", "dragonsteel armor", "google"),
        ("procura por ice and fire dragon forge", "ice and fire dragon forge", "google"),
        ("busca sobre mibr valorant", "mibr valorant", "google"),
        ("googla mibr valorant", "mibr valorant", "google"),
        ("pode pesquisar MIBR pra mim?", "mibr", "google"),
        ("pesquisa dragonsteel no youtube", "dragonsteel", "youtube"),
        ("busca tutorial de dragonsteel no youtube", "tutorial de dragonsteel", "youtube"),
        ("pesquisa no youtube dragonsteel armor", "dragonsteel armor", "youtube"),
        ("procura no you tube ice and fire", "ice and fire", "youtube"),
        ("pesquisa no google novo time da mibr", "novo time da mibr", "google"),
        ("pesquisa pra mim dragonsteel no youtube", "dragonsteel", "youtube"),
    ],
)
def test_search_natural_language(router, phrase, query, engine):
    intent = router.route(phrase)
    assert intent is not None
    assert intent.name == "browser.search"
    assert intent.args == {"query": query, "engine": engine}


@pytest.mark.parametrize(
    "phrase",
    [
        "o que você consegue fazer?",
        "o que vc faz?",
        "quais são suas funções?",
        "quais seus comandos",
        "me mostra seus comandos",
        "ajuda",
        "help",
    ],
)
def test_capability_questions(router, phrase):
    intent = router.route(phrase)
    assert intent is not None
    assert intent.name == "nesk.capabilities"


@pytest.mark.parametrize(
    "phrase",
    [
        "não pesquisa MIBR",
        "eu pesquisei MIBR ontem",
        "como pesquisar no YouTube?",
        "talvez eu pesquise isso depois",
        "gosto de procurar mods no google",
        "não abre o chatgpt",
        "eu abri o discord ontem",
        "como abrir a calculadora?",
        "quero aprender a abrir o navegador",
        "talvez abra o spotify depois",
        "se eu abrir o youtube o pc trava?",
        "pode não abrir o chrome",
    ],
)
def test_discussion_negation_and_howto_do_not_execute(router, phrase):
    assert router.route(phrase) is None


@pytest.mark.parametrize(
    "phrase",
    [
        "meu pc tá pegando quanto?",
        "quanto o processador tá usando?",
        "qual o consumo de memória ram?",
        "como está o armazenamento?",
        "quanto do SSD tá ocupado?",
        "status da máquina",
        "qual estado do sistema?",
    ],
)
def test_more_system_status_variants(router, phrase):
    intent = router.route(phrase)
    assert intent is not None
    assert intent.name == "system.status"

@pytest.mark.parametrize(
    ("phrase", "site"),
    [
        ("abre uma aba no youtube", "youtube"),
        ("abre uma guia no google", "google"),
        ("entra no site do youtube", "youtube"),
        ("entra na página do github", "github"),
        ("abre o site do claude", "claude"),
    ],
)
def test_natural_site_wrappers(router, phrase, site):
    intent = router.route(phrase)
    assert intent is not None
    assert intent.name == "browser.open_named"
    assert intent.args["name"] == site
