import pytest

from nesk.voice.session import VoiceSession, VoiceState


def test_voice_starts_disabled():
    assert VoiceSession().state == VoiceState.DISABLED


def test_valid_future_voice_cycle():
    session = VoiceSession()
    for state in (
        VoiceState.IDLE,
        VoiceState.LISTENING,
        VoiceState.TRANSCRIBING,
        VoiceState.PROCESSING,
        VoiceState.SPEAKING,
        VoiceState.IDLE,
    ):
        session.transition(state)
    assert session.state == VoiceState.IDLE
    assert session.active


def test_invalid_voice_transition_is_rejected():
    session = VoiceSession()
    with pytest.raises(ValueError):
        session.transition(VoiceState.SPEAKING)


def test_voice_error_can_recover_to_idle():
    session = VoiceSession(VoiceState.IDLE)
    session.transition(VoiceState.ERROR)
    session.transition(VoiceState.IDLE)
    assert session.state == VoiceState.IDLE
