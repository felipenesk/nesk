from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from nesk.core.assistant import NeskCore
from nesk.core.intent import Intent
from nesk.core.permissions import RiskLevel
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.storage.database import ConversationStore
from nesk.tools.base import Tool, ToolParameter, ToolResult
from nesk.tools.registry import ToolRegistry
from nesk.voice.audio import CapturedAudio
from nesk.voice.controller import VoiceController
from nesk.voice.service import VoiceService


def pcm_constant(value: int, seconds: float = 0.5, sample_rate: int = 16000) -> bytes:
    sample = int(value).to_bytes(2, "little", signed=True)
    return sample * int(seconds * sample_rate)


AUDIBLE = CapturedAudio(pcm_constant(1200), 16000)
SILENCE = CapturedAudio(b"\x00\x00" * 8000, 16000)


class FakeCapture:
    def __init__(self, audio: CapturedAudio):
        self.audio = audio
        self.recording = False
        self.overflowed = False
        self.cancelled = False

    def start(self):
        self.recording = True

    def stop(self):
        self.recording = False
        return self.audio

    def cancel(self):
        self.recording = False
        self.cancelled = True


class SequenceSTT:
    def __init__(self, items: list[str]):
        self.items = iter(items)
        self.closed = 0

    def transcribe(self, audio: CapturedAudio) -> str:
        return next(self.items)

    def close(self):
        self.closed += 1


class ConfirmTool(Tool):
    name = "test.medium.voice"
    description = "voice confirmation test"
    risk = RiskLevel.MEDIUM
    side_effects = True
    parameters = (ToolParameter("name"),)

    def __init__(self):
        self.calls = 0

    def run(self, **kwargs):
        self.calls += 1
        return ToolResult(True, "feito por voz")


def make_core(tmp_path: Path, tool: Tool | None = None) -> NeskCore:
    registry = ToolRegistry()
    if tool:
        registry.register(tool)
    return NeskCore(
        provider=LocalFallbackProvider(),
        store=ConversationStore(tmp_path / "voice-hardening.db"),
        tools=registry,
    )


def voice_config() -> dict:
    return {
        "voice": {
            "enabled": True,
            "mode": "push_to_talk",
            "capture": {
                "min_seconds": 0.25,
                "max_seconds": 20.0,
            },
            "stt": {"provider": "local", "local_model": "small"},
        }
    }


def test_silence_gate_rejects_audio_before_stt_or_core(tmp_path: Path):
    core = make_core(tmp_path)
    stt = SequenceSTT(["abre o youtube"])
    controller = VoiceController(core=core, stt=stt)
    service = VoiceService(
        core=core,
        config=voice_config(),
        data_root=tmp_path,
        capture=FakeCapture(SILENCE),
        controller=controller,
    )
    service.start_listening()
    result = service.finish_turn()
    assert result.accepted is False
    assert result.reason == "nenhum sinal de fala foi detectado"
    assert controller.session.state.value == "idle"


def test_quiet_but_realistic_signal_is_not_classified_as_digital_silence():
    quiet = CapturedAudio(pcm_constant(250), 16000)
    assert quiet.rms_dbfs > -55.0
    assert quiet.is_effectively_silent(rms_threshold_dbfs=-55.0, peak_threshold_dbfs=-40.0) is False


def test_ten_consecutive_voice_turns_return_to_idle_without_stale_state(tmp_path: Path):
    core = make_core(tmp_path)
    phrases = [f"oi {index}" for index in range(10)]
    stt = SequenceSTT(phrases.copy())
    controller = VoiceController(core=core, stt=stt)
    capture = FakeCapture(AUDIBLE)
    service = VoiceService(core=core, config=voice_config(), data_root=tmp_path, capture=capture, controller=controller)

    seen = []
    for _ in range(10):
        service.start_listening()
        result = service.finish_turn()
        assert result.accepted is True
        seen.append(result.transcript)
        assert controller.session.state.value == "idle"
    assert seen == phrases


def test_voice_confirmation_accepts_sim_por_favor(tmp_path: Path):
    tool = ConfirmTool()
    core = make_core(tmp_path, tool)
    core.router.route = lambda text: (  # type: ignore[method-assign]
        Intent("test.medium.voice", {"name": "discord"}, 1.0)
        if "fecha" in text.lower()
        else None
    )
    stt = SequenceSTT(["NESK, fecha o Discord.", "Sim, por favor."])
    controller = VoiceController(core=core, stt=stt)
    service = VoiceService(core=core, config=voice_config(), data_root=tmp_path, capture=FakeCapture(AUDIBLE), controller=controller)

    service.start_listening()
    first = service.finish_turn()
    assert "confirm" in first.response.lower() or "quer" in first.response.lower()
    assert tool.calls == 0

    service.start_listening()
    second = service.finish_turn()
    assert second.response == "feito por voz"
    assert tool.calls == 1


def test_negative_voice_command_never_routes_to_action(tmp_path: Path):
    core = make_core(tmp_path)
    stt = SequenceSTT(["NESK, não fecha o Discord."])
    controller = VoiceController(core=core, stt=stt)
    result = controller.process_audio(AUDIBLE)
    assert result.accepted is True
    assert "não executei" in result.response.lower() or "conversa" in result.response.lower()
    assert core.pending_action is None


def test_discussion_about_closing_is_not_an_action(tmp_path: Path):
    core = make_core(tmp_path)
    stt = SequenceSTT(["Eu estava pensando em fechar o Discord."])
    controller = VoiceController(core=core, stt=stt)
    result = controller.process_audio(AUDIBLE)
    assert result.accepted is True
    assert core.pending_action is None


def test_shutdown_closes_loaded_stt_once_and_is_idempotent(tmp_path: Path):
    core = make_core(tmp_path)
    stt = SequenceSTT(["oi"])
    controller = VoiceController(core=core, stt=stt)
    service = VoiceService(core=core, config=voice_config(), data_root=tmp_path, capture=FakeCapture(AUDIBLE), controller=controller)
    service.start_listening()
    result = service.finish_turn()
    assert result.accepted is True
    service.close()
    service.close()
    assert stt.closed == 1
    assert controller.session.state.value == "idle"


def test_voice_metrics_event_contains_no_transcript(tmp_path: Path):
    core = make_core(tmp_path)
    seen = []
    core.events.subscribe("voice.turn.completed", seen.append)
    controller = VoiceController(core=core, stt=SequenceSTT(["segredo de teste"]))
    result = controller.process_audio(AUDIBLE)
    assert result.accepted is True
    assert seen
    assert "transcript" not in seen[0].data
    assert "response" not in seen[0].data
    assert seen[0].data["audio_seconds"] == AUDIBLE.duration_seconds
