from __future__ import annotations

import pytest

from nesk.voice.audio import CapturedAudio


def test_captured_audio_duration_and_frames():
    audio = CapturedAudio(b"\x00\x00" * 16000, 16000)
    assert audio.frames == 16000
    assert audio.duration_seconds == pytest.approx(1.0)
    assert audio.empty is False


def test_captured_audio_rejects_malformed_pcm16():
    with pytest.raises(ValueError):
        CapturedAudio(b"x", 16000)
