from __future__ import annotations

import threading

import pytest

from nesk.core.permissions import RiskLevel
from nesk.platform.windows.programs import WindowsProgramCatalog
from nesk.tools.programs import CloseProgramTool
from nesk.voice.capture import MicrophoneCapture, MicrophoneError


class Stream:
    def __init__(self, *, callback, emit_on_start: bool = True, warning_on_stop: bool = False, **kwargs):
        self.callback = callback
        self.emit_on_start = emit_on_start
        self.warning_on_stop = warning_on_stop
        self.closed = False
        self.aborted = False

    def start(self):
        if self.emit_on_start:
            self.callback(b"\x01\x00" * 320, 320, None, None)

    def stop(self):
        if self.warning_on_stop:
            self.callback(b"\x01\x00" * 320, 320, None, "input overflow")

    def close(self):
        self.closed = True

    def abort(self):
        self.aborted = True


class SoundDevice:
    def __init__(self, *, emit_on_start: bool = True, warning_on_stop: bool = False, sample_rate: int = 16000):
        self.emit_on_start = emit_on_start
        self.warning_on_stop = warning_on_stop
        self.sample_rate = sample_rate
        self.stream = None

    def query_devices(self, device=None, kind=None):
        if kind == "input":
            return {"name": "Mic", "default_samplerate": self.sample_rate, "max_input_channels": 1}
        return []

    def RawInputStream(self, **kwargs):
        self.stream = Stream(
            emit_on_start=self.emit_on_start,
            warning_on_stop=self.warning_on_stop,
            **kwargs,
        )
        return self.stream


def test_capture_start_returns_without_waiting_for_portaudio_first_frame():
    sd = SoundDevice(emit_on_start=False)
    capture = MicrophoneCapture(sounddevice_module=sd, startup_timeout_ms=1, post_roll_ms=0)

    capture.start()

    assert capture.recording is True
    with pytest.raises(MicrophoneError, match="não entregou áudio"):
        capture.stop_result()
    assert sd.stream.aborted is True
    assert sd.stream.closed is True


def test_capture_returns_audio_and_integrity_flags_atomically_after_stop():
    sd = SoundDevice(warning_on_stop=True, sample_rate=44100)
    capture = MicrophoneCapture(sounddevice_module=sd, post_roll_ms=0)

    capture.start()
    result = capture.stop_result()

    assert result.audio.frames == 640
    assert result.audio.sample_rate == 44100
    assert result.backend_warning is True
    assert result.overflowed is False
    assert result.first_frame_latency_ms is not None
    assert sd.stream.closed is True


def test_capture_endpoint_waits_for_speech_then_silence_without_rejecting_quiet_input():
    sd = SoundDevice(emit_on_start=False)
    capture = MicrophoneCapture(
        sounddevice_module=sd,
        post_roll_ms=0,
        endpoint_min_speech_ms=100,
        endpoint_silence_ms=200,
    )
    capture.start()
    # About -52 dBFS: below the old -48 dBFS endpoint threshold, but audible
    # enough that it must end a benchmark turn rather than wait to max time.
    quiet = b"\x50\x00" * 320
    silence = b"\x00\x00" * 320

    capture._observe_endpoint(quiet, 1.0)
    capture._observe_endpoint(quiet, 1.2)
    capture._observe_endpoint(silence, 1.5)

    assert capture.wait_for_endpoint(timeout_seconds=0) is True
    capture.cancel()


def test_callback_from_cancelled_stream_cannot_contaminate_the_next_turn():
    sd = SoundDevice(emit_on_start=False)
    capture = MicrophoneCapture(sounddevice_module=sd, startup_timeout_ms=1, post_roll_ms=0)
    old_payload = b"\x01\x00" * 320
    new_payload = b"\x02\x00" * 320

    capture.start()
    old_stream = sd.stream
    capture.cancel()
    capture.start()
    new_stream = sd.stream
    new_stream.callback(new_payload, 320, None, None)
    old_stream.callback(old_payload, 320, None, None)
    result = capture.stop_result()

    assert result.audio.pcm16 == new_payload


def test_cancel_wakes_a_benchmark_waiting_for_endpoint():
    capture = MicrophoneCapture(sounddevice_module=SoundDevice(emit_on_start=False), post_roll_ms=0)
    capture.start()
    result: list[bool] = []
    waiting = threading.Thread(
        target=lambda: result.append(capture.wait_for_endpoint(timeout_seconds=1.0)),
    )
    waiting.start()

    capture.cancel()
    waiting.join(1.0)

    assert not waiting.is_alive()
    assert result == [True]


def test_stop_failure_cleans_stream_state_so_a_later_turn_can_start():
    class FailingStream(Stream):
        def stop(self):
            raise RuntimeError("driver failure")

    class FailingSoundDevice(SoundDevice):
        def RawInputStream(self, **kwargs):
            self.stream = FailingStream(emit_on_start=True, **kwargs)
            return self.stream

    capture = MicrophoneCapture(sounddevice_module=FailingSoundDevice(), post_roll_ms=0)
    capture.start()
    with pytest.raises(MicrophoneError, match="falhou ao encerrar"):
        capture.stop_result()

    capture.start()
    capture.cancel()


def test_known_program_close_is_direct_but_still_allowlisted():
    tool = CloseProgramTool(WindowsProgramCatalog({}))
    assert tool.risk is RiskLevel.LOW
    assert "confirma" not in tool.description.lower()
