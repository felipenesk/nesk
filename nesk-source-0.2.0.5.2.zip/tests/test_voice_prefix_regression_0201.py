import pytest

from nesk.core.intent_router import LocalIntentRouter
from nesk.nlu.ptbr import strip_wake_name


def route(text: str):
    return LocalIntentRouter().route(text)


@pytest.mark.parametrize(
    ("phrase", "expected"),
    [
        ("NESK, abre o YouTube", "abre o YouTube"),
        ("NESK. Abre o YouTube", "Abre o YouTube"),
        ("NESK... abre o YouTube", "abre o YouTube"),
        ("NESK! abre o YouTube", "abre o YouTube"),
        ("NESK? abre o YouTube", "abre o YouTube"),
        ("NESK: abre o YouTube", "abre o YouTube"),
        ("NESK - abre o YouTube", "abre o YouTube"),
    ],
)
def test_strip_wake_name_accepts_stt_punctuation(phrase: str, expected: str):
    assert strip_wake_name(phrase) == expected


@pytest.mark.parametrize(
    ("phrase", "intent_name"),
    [
        ("NESK. Abre o YouTube para mim.", "browser.open_named"),
        ("NESK... pesquisa valorant pra mim", "browser.search"),
        ("NESK! como está meu PC?", "system.status"),
        ("NESK? fecha o Discord", "programs.close"),
    ],
)
def test_router_accepts_wake_name_punctuation_from_stt(phrase: str, intent_name: str):
    intent = route(phrase)
    assert intent is not None
    assert intent.name == intent_name


def test_negative_command_after_wake_prefix_still_does_not_execute():
    assert route("NESK. não abre o YouTube") is None
