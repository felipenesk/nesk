from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from nesk.core.bootstrap import bootstrap
from nesk.providers.base import AIProvider
from nesk.providers.resilient import ResilientProvider
from nesk.storage.database import ConversationStore


class ClosableProvider(AIProvider):
    def __init__(self) -> None:
        self.closed = 0

    def reply(self, messages):
        return "ok"

    def close(self) -> None:
        self.closed += 1


def test_database_quick_integrity(tmp_path: Path):
    store = ConversationStore(tmp_path / "nesk.db")
    assert store.integrity_check() is True
    assert store.schema_version() == 2


def test_resilient_provider_closes_both_children():
    primary = ClosableProvider()
    fallback = ClosableProvider()
    provider = ResilientProvider(primary, fallback)
    provider.close()
    assert primary.closed == 1
    assert fallback.closed == 1


def test_runtime_shutdown_is_idempotent(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("NESK_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("NESK_AI_PROVIDER", "local")
    runtime = bootstrap()
    seen = []
    runtime.events.subscribe("runtime.stopped", seen.append)
    runtime.shutdown()
    runtime.shutdown()
    assert len(seen) == 1


def test_headless_self_check_does_not_need_qt(tmp_path: Path):
    env = os.environ.copy()
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
    env["NESK_DATA_DIR"] = str(tmp_path)
    env["NESK_AI_PROVIDER"] = "local"
    result = subprocess.run(
        [sys.executable, "-m", "nesk.app", "--self-check"],
        env=env,
        capture_output=True,
        text=True,
        timeout=20,
    )
    assert result.returncode == 0, result.stderr


def test_default_cloud_model_tracks_current_foundation_default():
    from nesk.core.config import DEFAULTS

    assert DEFAULTS["ai"]["model"] == "gpt-5.6"


def test_safe_support_report_source_does_not_include_log_content():
    source = (Path(__file__).resolve().parents[1] / "scripts" / "support_report.py").read_text(encoding="utf-8")
    assert "nesk.log" not in source
    assert "OPENAI_API_KEY" not in source
