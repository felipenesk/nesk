import pytest

from nesk.core.intent_router import LocalIntentRouter


@pytest.mark.parametrize(
    "phrase,target",
    [
        ("fecha o discord", "discord"),
        ("NESK, fecha o spotify pra mim", "spotify"),
        ("pode fechar o chrome?", "chrome"),
        ("encerra o bloco de notas", "notepad"),
    ],
)
def test_close_program_intents(phrase: str, target: str):
    intent = LocalIntentRouter().route(phrase)
    assert intent is not None
    assert intent.tool_name == "programs.close"
    assert intent.args["name"] == target
    assert intent.confidence >= 0.9


def test_discussing_close_does_not_execute():
    assert LocalIntentRouter().route("eu queria saber como fechar o discord") is None
