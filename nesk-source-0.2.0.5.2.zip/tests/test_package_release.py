from __future__ import annotations

import importlib.util
import zipfile
from pathlib import Path


def _package_release_module():
    script = Path(__file__).resolve().parents[1] / "scripts" / "package_release.py"
    spec = importlib.util.spec_from_file_location("nesk_package_release_test", script)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_source_release_excludes_env_logs_and_database_artifacts(tmp_path: Path, monkeypatch):
    module = _package_release_module()
    root = tmp_path / "source"
    root.mkdir()
    (root / "README.md").write_text("source", encoding="utf-8")
    for relative in (
        ".env",
        ".env.local",
        ".env.example",
        "nesk.log",
        "nesk.log.1",
        "nesk.db",
        "nesk.db-wal",
        "state.sqlite3",
        "state.sqlite3-shm",
        ".coverage",
        "NESK.spec",
        "work/pytest/run-artifact.txt",
        "pytest-scratch/config.json",
    ):
        target = root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("sensitive runtime artifact", encoding="utf-8")

    archive = tmp_path / "source-release.zip"
    monkeypatch.setattr(module, "ROOT", root)
    monkeypatch.setattr(module, "OUT", archive)
    monkeypatch.setattr(module, "VERSION", "test")
    module.main()

    with zipfile.ZipFile(archive) as packaged:
        names = set(packaged.namelist())
    assert "NESK_test_FirstListen/README.md" in names
    assert not any(
        name.endswith((
            ".env",
            ".env.local",
            ".env.example",
            ".log",
            ".log.1",
            ".db",
            ".db-wal",
            ".sqlite3",
            ".sqlite3-shm",
            ".coverage",
            ".spec",
            "work/pytest/run-artifact.txt",
            "pytest-scratch/config.json",
        ))
        for name in names
    )
