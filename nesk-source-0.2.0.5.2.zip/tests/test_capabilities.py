from nesk.tools.capabilities import CapabilitiesTool
from nesk.tools.registry import ToolRegistry
from nesk.tools.system_status import SystemStatusTool


def test_registry_describe_returns_safe_metadata():
    registry = ToolRegistry()
    registry.register(SystemStatusTool())
    descriptions = registry.describe()
    assert descriptions == [
        {
            "name": "system.status",
            "description": SystemStatusTool.description,
            "risk": "low",
        }
    ]


def test_capabilities_tool_lists_installed_tools():
    registry = ToolRegistry()
    registry.register(SystemStatusTool())
    tool = CapabilitiesTool(registry)
    registry.register(tool)
    result = tool.run()
    assert result.ok
    assert result.data is not None
    names = {item["name"] for item in result.data["capabilities"]}
    assert "system.status" in names
    assert "nesk.capabilities" not in names


def test_capabilities_exact_field_wording_with_merged_oque():
    from nesk.core.intent_router import LocalIntentRouter

    intent = LocalIntentRouter().route("nesk oque você consegue fazer")
    assert intent is not None
    assert intent.name == "nesk.capabilities"
