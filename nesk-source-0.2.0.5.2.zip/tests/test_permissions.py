from nesk.core.permissions import PermissionDecision, PermissionPolicy, RiskLevel


def test_policy():
    policy = PermissionPolicy()
    assert policy.decide(RiskLevel.LOW) == PermissionDecision.ALLOW
    assert policy.decide(RiskLevel.MEDIUM) == PermissionDecision.CONFIRM
    assert policy.decide(RiskLevel.HIGH) == PermissionDecision.BLOCK
