from pathlib import Path

from nesk.core.models import Message, Role
from nesk.storage.database import ConversationStore


def test_round_trip(tmp_path: Path):
    store = ConversationStore(tmp_path / "nesk.db")
    store.add(Message(Role.USER, "teste"))
    store.add(Message(Role.ASSISTANT, "resposta"))
    recent = store.recent(10)
    assert [m.content for m in recent] == ["teste", "resposta"]


def test_recent_limit(tmp_path: Path):
    store = ConversationStore(tmp_path / "nesk.db")
    for i in range(5):
        store.add(Message(Role.USER, str(i)))
    assert [m.content for m in store.recent(2)] == ["3", "4"]


def test_database_schema_is_versioned(tmp_path: Path):
    store = ConversationStore(tmp_path / "nesk.db")
    assert store.schema_version() == 2


def test_legacy_unversioned_database_is_adopted_without_losing_messages(tmp_path: Path):
    import sqlite3

    path = tmp_path / "legacy.db"
    with sqlite3.connect(path) as con:
        con.execute(
            "CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL)"
        )
        con.execute(
            "INSERT INTO messages(role, content, created_at) VALUES ('user', 'teste antigo', '2026-08-20T00:00:00+00:00')"
        )
    store = ConversationStore(path)
    assert store.schema_version() == 2
    assert [m.content for m in store.recent(10)] == ["teste antigo"]
