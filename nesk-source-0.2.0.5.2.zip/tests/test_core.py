from pathlib import Path

from nesk.core.assistant import NeskCore
from nesk.providers.local_fallback import LocalFallbackProvider
from nesk.storage.database import ConversationStore
from nesk.tools.registry import ToolRegistry
from nesk.tools.system_status import SystemStatusTool


def test_local_tool_result_is_persisted(tmp_path: Path):
    store = ConversationStore(tmp_path / "nesk.db")
    tools = ToolRegistry()
    tools.register(SystemStatusTool())
    core = NeskCore(provider=LocalFallbackProvider(), store=store, tools=tools)
    result = core.handle("quanto de RAM estou usando?")
    assert result.action == "system.status"
    assert "RAM" in result.text
    assert len(store.recent(10)) == 2
