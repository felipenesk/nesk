from unittest.mock import patch

from nesk.core.intent_router import LocalIntentRouter
from nesk.platform.windows.programs import WindowsProgramCatalog


def test_unknown_shell_like_target_is_never_resolved_as_executable():
    catalog = WindowsProgramCatalog()
    assert catalog.resolve("notepad && del C:\\teste") is None
    assert catalog.resolve("cmd /c calc") is None
    assert catalog.resolve("powershell") is None


def test_router_does_not_turn_discussion_into_shell_action():
    router = LocalIntentRouter()
    assert router.route("eu queria saber como abrir cmd") is None


def test_program_launch_never_uses_shell():
    catalog = WindowsProgramCatalog()
    target = catalog.resolve("notepad")
    assert target is not None
    with patch("nesk.platform.windows.programs.subprocess.Popen") as popen:
        catalog.launch(target)
    assert popen.call_args.kwargs.get("shell") is False
