# Changelog

## Post-validation textual hotfix for 0.2.0.5.2

### Contexto plural e UX de programas
- Após uma abertura aprovada de duas opções, referências locais como `fecha eles`,
  `fecha ambos` e `fecha os dois` recriam dois Intents canônicos e os passam
  individualmente por Core, ToolRegistry e PermissionPolicy.
- O grupo plural é somente RAM, contém IDs canônicos e é criado apenas quando
  ambas as aberturas terminam com sucesso; expiração, Tool interveniente, lote
  parcial/cancelado ou refresh que remove uma entrada falham fechados. A
  referência é consumida no começo do novo lote para falha/cancelamento não
  reativarem um grupo antigo.
- Alvos explícitos desconhecidos agora recebem resposta local tipada, sem Tool
  ou provider; alvos vagos continuam clarificação e colisões reais continuam
  ambiguidade local. Alias conhecido embutido em rótulo desconhecido não ganha
  execução e uma nova pergunta após clarificação não vira nome desconhecido.
- `abre Discord e Riot Client` preserva o alvo desconhecido na resposta e só
  executa o Intent canônico de Discord. Path/URL/shell-like não é ecoado nem
  enviado ao catálogo.

### QA
- Adicionadas regressões para contexto plural, confirmação individual,
  cancelamento, resultado parcial, sessão/TTL, UNKNOWN/MISSING/AMBIGUOUS,
  mistura de alvos e refresh seguro de discovery.

## Text / Semantic Hardening for 0.2.0.5.2

### Texto, contexto e clarificação
- Adicionado tratamento composicional de preâmbulos discursivos iniciais (`ae mano`, `vei`, `tipo assim`, `po`, `cara`) sem apagar negação, hipótese, pergunta ou primeira pessoa.
- `procura no YouTube` agora representa engine sem query e só reutiliza tópico de busca recente em RAM; sessão nova pergunta o assunto.
- `abre <entidade> no YouTube|Google` é classificado como busca antes da seleção de programa, sem URL fabricada.
- A ordem de opções de clarificação segue a primeira ocorrência do usuário; matching por alias longo só resolve colisões sobrepostas.
- Clarificação aceita `ambos`/`os dois`/`as duas` apenas para duas aberturas pré-validadas compatíveis. Cada Intent passa individualmente por Core, Tool Registry e PermissionPolicy; falha parcial é explícita.

### Program Discovery Alpha e segurança
- Criado `ProgramDirectory` compartilhado por router, semantic, contexto e catálogo Windows. `allowed_programs` é snapshot atual de IDs seguros, não uma allowlist congelada no import.
- Config custom e App Paths passam a exigir `.exe` existente, absoluto e sem argumentos. Config/HKCU ficam sob Known Folders Windows; a exceção HKLM preserva o escopo `machine` até revalidar o target local exato e exclui UNC/device, perfil, Desktop, Downloads e TEMP. Cache é local/versionado/descartável, mas nunca autoridade de startup.
- Nenhuma descoberta usa scan de disco, `PATH`/raízes de ambiente para apps dinâmicos, Desktop/Downloads, shell ou path vindo de usuário/provider. `%VAR%` só aceita valores de APIs Windows conhecidas.
- Apps descobertos não ganham close por inferência; só nomes de processo Foundation exatos continuam elegíveis.
- `semantic.allow_remote="false"` agora falha fechado em vez de habilitar remoto por truthiness.
- Release check compila também `scripts` e `tests` e amplia o smoke de instalação limpa para ProgramDirectory.

### QA
- Adicionadas 49 regressões de texto/semântica/program discovery; a contagem final é registrada no relatório de release.

## Semantic Context extension for 0.2.0.5.2

### Intent e contexto
- Adicionado `SessionContext` exclusivamente em RAM: último Intent/ferramenta bem-sucedidos, programa, tópico/mecanismo de busca e uma clarificação pendente. Nada é carregado de ou salvo no SQLite.
- Inserido `IntentResolutionCoordinator` entre o NLU e o Core. Ele intercepta alvo literal suspeito, filler, pronome e referência antes que qualquer Tool seja chamada.
- `fecha ele`, `procura isso no YouTube` e `agora vê no YouTube` usam somente antecedente recente, tipado e compatível; ausência ou incompatibilidade vira clarificação.
- Clarificação foi separada de confirmação de permissão. Respostas curtas e índices só funcionam enquanto a pergunta correspondente está pendente; mudança de assunto, expiração ou nova sessão invalidam o estado.

### Interpretação e segurança
- Mantido o NLU local/offline para pedidos claros; adicionadas formas naturais compostas sem dicionário de frases completo, incluindo `boto`, `manda abrir` e fillers em torno de entidade conhecida.
- Novo contrato `SemanticProvider` independente do provider conversacional. Ele devolve candidato estruturado, nunca ferramenta, shell, URL, caminho ou texto executável.
- Provider OpenAI é opcional, com JSON fechado, timeout, cancelamento cooperativo e descarte por geração para resultados tardios. `semantic.allow_remote=false` é o padrão.
- Candidatos só viram `Intent` quando ação, ferramenta registrada, alvo allow-listed, mecanismo de busca, modalidade e confiança passam validação.
- Negações, perguntas explicativas, menções em primeira pessoa e hipóteses continuam em no-op; não chegam ao Tool Registry.

### Privacidade e QA
- O request semântico externo contém somente texto atual, catálogo permitido e view transitória minimizada quando necessária; nunca mensagens, memória, logs, paths, áudio ou credenciais.
- Schema de configuração 10 adiciona opções semânticas opt-in sem alterar escolhas existentes de voz/IA.
- Adicionadas 44 regressões para naturalidade, referências, clarificação, expiração, privacidade, provider inválido/indisponível/timeout e descarte concorrente.

## 0.2.0.5.2 — Shared Speech Pipeline

### Captura e ciclo de vida
- UI, probe STT e benchmark passaram a compartilhar SpeechPipeline, abaixo do Core.
- Captura devolve áudio, warning/overflow, latência do primeiro frame e endpoint no mesmo resultado atômico.
- start() não bloqueia aguardando o primeiro callback; o encerramento valida readiness fora da thread de interação.
- Callback recebe token de geração: áudio tardio de stream cancelado não entra no turno seguinte.
- Falha de stop() limpa o estado da captura para que uma nova tentativa possa iniciar.
- Cancelamento/encerramento durante STT invalida o turno antes do Core; a entrega final ao Core é linearizada contra cancelamento.

### STT e qualidade
- Removidos retry de comando, retry de fala curta, prompt alternativo de comando, normalização e trim energético.
- O front-end agora apenas canonicaliza PCM16 mono para float32/16 kHz e remove DC offset conservadoramente.
- Há exatamente uma decodificação faster-whisper por turno.
- O quality gate espelha a semântica no-speech/logprob do decoder, rejeita baixa confiança/repetição técnica e não reescreve texto.
- Removido o gate RMS/pico de janela inteira; somente buffer PCM exatamente zero é tratado como entrada morta.
- Endpointing substitui a janela fixa de cinco segundos no benchmark, com timeout máximo apenas como proteção.

### Compatibilidade, Windows e release
- A verificação de locutor existente volta a ocorrer antes de STT/Core quando habilitada.
- VoiceController.close() mantém o contrato legado de fechar STT que possui; o serviço transfere ownership ao pipeline para evitar double-close.
- Discord usa allowlist exata (Stable/PTB/Canary/development); Update.exe nunca é terminado e a espera por spawn é limitada a launch recente.
- Schema 9 remove knobs de hotfix obsoletos, preservando preferências explícitas de dispositivo/modelo.
- Source package exclui credenciais, logs, bancos, caches e artefatos de runtime.
- Self-check importa dependências nativas de voz do bundle sem abrir microfone ou carregar modelo.

### Regressões
- Cobertos callback tardio, warning durante stop/post-roll, stop nativo com falha, cancelamento durante STT, shutdown, verificação de locutor, uma decodificação por turno, silêncio digital, fala quieta, schema/defaults e lifecycle de Discord.

## 0.2.0.5.1 — Speech Probe Hotfix

### QA Windows
- Corrigido o probe de 8 frases: durante a gravação ele não depende mais de um segundo `ENTER`, que travou no console real do Windows 10.
- Cada frase agora grava por uma janela padronizada de 5 segundos e encerra automaticamente; o front-end já recorta o silêncio excedente antes do STT.
- O `ENTER` continua sendo usado somente antes de cada frase, fora do stream de microfone.
- Mantido o isolamento: o probe não importa o Core, não executa ferramentas e não salva áudio/transcrições em disco.

## 0.2.0.5 — Speech Pipeline Hardening

### Captura / sinal
- Captura usa blocos de 20 ms e latência baixa configurável para tornar o push-to-talk mais previsível.
- Callback com aviso/overflow do PortAudio marca o turno como inválido; áudio com lacuna não chega ao STT/Core.
- Post-roll padrão aumentado para 180 ms.
- Novo front-end local em RAM com remoção de DC, resampling 16 kHz, recorte conservador de bordas e normalização limitada de ganho.

### STT PT-BR
- Prompt/hotwords reforçam transcrição literal e preservação do tempo verbal (`abre` não deve ser reformulado como `abriu/abro/abrir`).
- Beam/patience levemente elevados; adicionados repetition penalty, no-repeat ngram, thresholds de logprob/no-speech e word timestamps/hallucination guard suportados pelo faster-whisper 1.2.1.
- Segunda passada de comando ocorre somente quando há motivo para rechecagem (forma verbal variante, alvo conhecido sem ação clara ou baixa confiança).
- Decodes que discordam no verbo de ação para o mesmo alvo são rejeitados como ambíguos. O STT nunca corrige texto para forçar execução.
- Diagnósticos incluem duração preparada, ganho do front-end, word probability e uso do retry, sem conteúdo falado.

### QA de voz
- Novo `TESTAR_VOZ_QUALIDADE.bat` com oito frases PT-BR padronizadas; mede exatidão textual, similaridade, latência e rejeições.
- O probe de qualidade não importa/chama o Core e não salva áudio ou transcrições em disco.

### Windows / programas
- Detecção de Discord cobre Stable, PTB e Canary.
- Fechamento faz polling curto para processo recém-iniciado e não trata `Update.exe` como processo do app.
- Fechar aplicativo conhecido continua limitado ao catálogo permitido.

### Configuração / testes
- Config schema 7 preserva configurações anteriores e injeta somente novos defaults.
- Novas regressões cobrem front-end de áudio, retry de comando, rejeição de ambiguidade, PortAudio warning e variantes de processo do Discord.

## 0.2.0.4 — Voice Capture Hardening

### Captura push-to-talk
- O stream só é considerado pronto após o primeiro callback real do PortAudio, com timeout configurável.
- Adicionado post-roll curto e configurável após o release para preservar finais de palavra.
- Falha de arming fecha/aborta o stream de forma limpa em vez de deixar uma captura “meio aberta”.

### STT PT-BR
- Hotwords principais agora incluem respostas curtas comuns como `sim`, `não`, `pode` e `cancela`.
- Falas muito curtas e de baixa confiança podem receber segunda passada literal especializada.
- Segunda passada só vence a primeira quando o `avg_logprob` é melhor; não há pós-correção fuzzy nem mapeamento automático para comandos.
- Gate de qualidade usa sinais técnicos (`avg_logprob`, `no_speech_prob`, `compression_ratio`) e pode descartar saída suspeita antes do Core.
- Probe STT expõe métricas do retry/quality gate sem armazenar conteúdo.

### Política de ações
- `programs.close` passou de MEDIUM para LOW conforme preferência explícita do usuário: fechar programa conhecido executa direto.
- O fechamento continua restrito ao catálogo/process names permitidos; confirmação MEDIUM/HIGH permanece no restante da arquitetura.

### Configuração / testes
- Config schema 6 adiciona readiness/post-roll e parâmetros de quality gate/retry preservando configurações existentes.
- Regressões cobrem arming do microfone, timeout limpo, retry de palavra curta, rejeição de alucinação por no-speech e política direta de fechamento.

## 0.2.0.3 — Voice Input Hardening

### Confirmação segura
- Novo classificador dedicado de confirmação, separado do Core e testável isoladamente.
- `sim.`, `sim por favor`, `pode sim`, `confirmo`, `isso mesmo` e outras formas claras confirmam uma ação pendente.
- `não.`, `não precisa`, `cancela`, `melhor não` e formas claras equivalentes cancelam.
- Respostas como `acho que sim`, `não sei` e `sim mas espera` são ambíguas: nunca executam e mantêm a confirmação pendente.
- Texto não relacionado continua expirando a autorização antiga antes de ser tratado como novo pedido.

### Entrada de voz
- Gate conservador de silêncio antes do STT baseado em RMS + pico dBFS.
- Toque sem fala / entrada digitalmente silenciosa não chega ao Core.
- Thresholds configuráveis em `voice.capture.silence_rms_dbfs` e `silence_peak_dbfs`.
- `TESTAR_STT.bat` mostra níveis técnicos e usa o mesmo gate sem executar ferramentas.

### Ciclo de vida / desempenho
- VoiceService serializa transcrição e shutdown para evitar corrida com inferência nativa.
- SpeechToText/TextToSpeech providers ganharam `close()` idempotente.
- FasterWhisper libera a referência do modelo no shutdown; cliente cloud é fechado quando suportado.
- VoiceTurnResult expõe somente métricas técnicas opcionais de duração/latência, sem conteúdo.
- Regressão automatizada cobre dez turnos consecutivos sem estado antigo.

### Configuração / testes
- Schema de configuração 5 injeta os thresholds de silêncio preservando tuning e preferências existentes.
- Regressões de campo cobrem confirmação por voz, negação, menção conversacional, silêncio e shutdown.

## 0.2.0.2 — PT-BR STT Tuning

### Reconhecimento de voz
- Mantido `small`/CPU/int8 como perfil padrão para o notebook de referência; nenhum salto cego para um modelo pesado.
- Idioma PT fixado explicitamente e task `transcribe` declarada.
- Adicionados `hotwords` configuráveis para NESK e nomes frequentes (YouTube, Google, Discord, Minecraft etc.).
- `initial_prompt` reduzido a contexto PT-BR/literal, sem pós-correção de comandos.
- VAD de fala curta agora tem threshold, padding e tempos configuráveis.
- Beam/patience/max tokens viraram parâmetros de configuração, permitindo benchmark posterior sem reescrever provider.
- `faster-whisper` mínimo atualizado para 1.2.1.

### Segurança / observabilidade
- Nenhuma transcrição fuzzy vira comando automaticamente; erros do STT continuam visíveis ao Core.
- Adicionadas métricas técnicas sem conteúdo: duração, latência, real-time factor, idioma, segmentos e avg_logprob.
- Novo `TESTAR_STT.bat` testa captura + STT isoladamente e nunca executa ferramentas do NESK.

### Configuração
- Schema de configuração 4; migração de schema 3 preserva preferências existentes e injeta os novos defaults de tuning.

## 0.2.0.1 — First Listen Hotfix 1

### Corrigido após teste real no Windows 10
- Prefixo/vocativo `NESK` agora aceita pontuação produzida naturalmente pelo STT, incluindo `NESK.`, `NESK...`, `NESK!` e `NESK?`.
- `NESK. Abre o YouTube para mim.` agora percorre o mesmo NLU seguro que `Abre o YouTube para mim.`.
- Regressões cobrem abertura, pesquisa, status, fechamento e negação após o prefixo.
- Nenhuma flexibilização fuzzy foi adicionada: somente o vocativo inicial é normalizado.

## 0.2.0 — First Listen

### Voz real
- Ativada captura push-to-talk de microfone com buffer PCM16 somente em memória.
- Adicionado `MicrophoneCapture` com limite de duração, cancelamento e enumeração de entradas.
- Adicionado `CapturedAudio` com metadados explícitos de sample rate/canais.
- STT local lazy via `faster-whisper`; padrão `small`, CPU, `int8`, idioma PT.
- Resampling leve normaliza microfones 44.1/48 kHz para a entrada do Whisper.
- Provider OpenAI de transcrição preparado como opção explícita e usa WAV em memória, sem arquivo temporário.
- `VoiceController` agora suporta First Listen sem TTS e continua reutilizando o mesmo Core.

### UI
- Botão `SEGURE` ativa captura enquanto pressionado e processa ao soltar.
- Estados `LISTENING`, `TRANSCRIBING`, `PROCESSING`, `ERROR` integrados ao shell monocromático.
- Transcrição aparece identificada como `VOCÊ · VOZ` antes da resposta do NESK.

### Configuração / privacidade
- Config schema atualizado para 3.
- Migração de 0.1.x ativa First Listen porque Voice anterior era apenas placeholder não funcional.
- `store_audio=false` permanece preservado.
- Cache de modelos fica sob o diretório de dados do NESK.

### Windows / release
- Setup instala `.[voice]` e sincroniza dependências por versão.
- `VALIDAR_NESK.bat` ganhou diagnóstico de dependências e microfone.
- Pipeline de EXE inclui dependências dinâmicas do stack de voz.
- Foundation 0.1.x permanece congelada; mudanças de voz ficam isoladas na linha 0.2.x.

## 0.1.9 — Foundation Release Candidate

### Release engineering
- Adicionado self-check headless (`python -m nesk.app --self-check`) que não depende da GUI.
- Release check agora valida instalação limpa do pacote fora da árvore de desenvolvimento.
- Adicionada verificação de higiene de fonte e possível credencial literal.
- Build Windows exige Python 64-bit, executa self-check no `.exe` gerado e empacota a pasta validada.
- Adicionado empacotador de source release sem caches/venv/builds.

### Ciclo de vida
- Runtime ganhou shutdown idempotente.
- Providers ganharam boundary de `close()` sem acoplar o Core a implementações específicas.
- UI centraliza shutdown de timer, tray e executor.

### Diagnóstico e suporte
- SQLite ganhou `quick_check` programático.
- Diagnóstico seguro informa saúde técnica sem imprimir segredos, conversas, nomes de usuário ou caminhos pessoais.
- Adicionado relatório de suporte seguro em JSON.
- Adicionado `VALIDAR_NESK.bat` para preflight + diagnóstico + self-check.

### Provider
- Novas instalações passam a usar `gpt-5.6` como modelo OpenAI padrão configurável; instalações existentes preservam seu `config.json`.

### Política da linha 0.1.x
- Nenhuma feature grande nova. Esta build é candidata ao congelamento da Foundation antes do First Voice.

## 0.1.8 — Foundation Final Hotfix

### Regressões encontradas no Windows 10
- Corrigido `pesquisa valorant pra min`: o typo comum `min` agora é tratado como filler conversacional e não entra na query.
- Corrigido `nesk oque você consegue fazer`: `oque` é canonicalizado com segurança para `o que` na camada de phrase matching.
- Frases negativas como `não abre o YouTube` agora deixam explícito que nenhuma ação foi executada.
- Perguntas do tipo `como eu faço para abrir a calculadora?` deixam explícito que foram tratadas como pergunta, não comando.
- Menções conversacionais a ações deixam explícito que NESK permaneceu em no-op.

### Capabilities
- Resposta de capacidades passa a ser montada a partir das tools realmente registradas, em vez de depender apenas de um texto fixo.
- Mantida a regra de não executar nada apenas porque uma ação foi mencionada em conversa.

### Release
- Interface/launcher identificados como `Foundation Final 0.1.8`.
- Regressões de campo adicionadas à suíte automatizada.
- Release check: versão, compilação, testes e smoke test aprovados.

## 0.1.7 — Core Hardening

### Core
- Intent padronizada com confiança e origem, mantendo compatibilidade da API 0.1.x.
- Core protegido por lock para futura concorrência entre UI/Voice.
- Ações pendentes com confirmação/cancelamento e expiração ao mudar de assunto.
- Event Bus interno sem conteúdo de conversa por padrão.
- Abstração inicial de NESK Nodes.

### Ferramentas e segurança
- Tool schemas estruturados: categoria, risco, side effects e parâmetros.
- Registry captura exceções de tools sem derrubar o Core.
- `programs.close` adicionado como ação MEDIUM, exigindo confirmação.
- Fechamento limitado a processos associados ao catálogo permitido.
- Shell arbitrário continua não exposto.

### Memória e dados
- MemoryRepository explícito com `local_only`, `private` e `normal`.
- `local_only` nunca permite `cloud_allowed=true`.
- Memória automática continua desligada.
- SQLite atualizado para schema 2.
- Backup SQLite seguro via backup API antes de migrar banco legado.
- Config schema 2 com merge de defaults.
- Configuração corrompida é preservada antes de recriação.
- Overrides de provider/model por ambiente não são persistidos como segredo/config acidental.

### Voice
- VoiceController hardware-independent, reutilizando o mesmo NeskCore.
- Boundary de Speaker Verification preparado e desligado por padrão.
- STT/TTS continuam provider-neutral.

### UI
- UI Preview incorporada e convertida para identidade monocromática.
- Sem blur, partículas, vídeo de fundo ou animação contínua.

### Release engineering
- `scripts/release_check.py` valida versão, compilação, testes e smoke test.
- `scripts/build_exe.bat` prepara build PyInstaller experimental.

## 0.1.6 — Language & Voice Foundation
- NLU PT-BR data-driven, pesquisas, novos aliases, Voice state machine e schema SQLite inicial.

## 0.1.5
- Natural Portuguese Command Layer.

## 0.1.4
- Tool Argument Collision Hotfix.

## 0.1.0
- Primeira Foundation modular.
