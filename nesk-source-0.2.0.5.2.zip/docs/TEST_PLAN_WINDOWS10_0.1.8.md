# Windows 10 — Test Plan 0.1.8

Execute em ordem e registre qualquer diferença.

1. `NESK, como está meu PC?`
2. `consegue abrir meus arquivos rapidinho?`
3. `abre o youtube pra mim`
4. `pesquisa valorant pra min` — a pesquisa deve ser somente `valorant`.
5. `nesk oque você consegue fazer` — deve responder capacidades, não fallback genérico.
6. `não abre o youtube` — não abre nada e confirma no-op.
7. `eu gosto de abrir o youtube enquanto jogo` — não abre nada.
8. `como eu faço para abrir a calculadora?` — não abre nada.
9. `fecha o Discord` -> `não` — cancela.
10. `fecha o Discord` -> `sim` — fecha somente após confirmação.
11. Feche e abra NESK novamente; repita 1, 4 e 5.

Se os casos 1–11 passarem sem regressões, a Foundation 0.1.x pode ser considerada candidata a encerramento antes do First Voice.
