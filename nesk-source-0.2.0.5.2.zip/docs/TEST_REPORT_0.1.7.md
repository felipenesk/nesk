# Test Report — NESK 0.1.7 Core Hardening

## Automated validation
- 170 pytest cases collected and passed.
- `compileall` passed for `src`.
- Smoke test passed.
- Version sync passed (`VERSION`, Python package and `pyproject.toml`).
- Static UI guard confirms all stylesheet hex colors are grayscale/monochrome.

## Covered areas
- PT-BR command routing and negative cases.
- Tool Registry and permission policy.
- Structured intents/confidence.
- Confirmation/cancellation/expiration behavior.
- SQLite schema migration and pre-migration backup.
- Memory privacy rules.
- Config migration/corrupt-config preservation.
- Event Bus observer isolation.
- Node abstraction.
- Voice state machine and simulated STT -> Core -> TTS pipeline.
- Speaker verification rejection boundary.

## Still requires real Windows 10 validation
- PySide6 visual rendering.
- Actual process launch/close behavior on the user's machine.
- Tray behavior.
- Real CPU/RAM consumption with the UI open.
- Experimental PyInstaller `.exe` build.
- Real microphone/STT/TTS are intentionally not enabled in 0.1.7.
