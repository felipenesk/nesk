# Windows 10 — Test Plan 0.1.9 RC

1. Extrair a build em uma pasta nova.
2. Rodar `INICIAR_NESK.bat` e confirmar primeiro boot.
3. Rodar `VALIDAR_NESK.bat` e confirmar `[OK]`.
4. Repetir os fluxos aprovados da 0.1.8: status, abrir programa, site, pesquisa, negação, pergunta e confirmação de fechamento.
5. Fechar pelo X com tray habilitado: NESK deve permanecer no tray.
6. Abrir novamente pelo tray.
7. Usar `Sair` no menu do tray e confirmar que a interface encerrou.
8. Reabrir NESK e confirmar dados/configuração íntegros.
9. Observar CPU/RAM em idle por alguns minutos.
10. Opcional: rodar `scripts\build_exe.bat`; se gerar, abrir `dist\NESK\NESK.exe` e repetir o teste básico.

Se 1–8 passarem sem regressão, a Foundation está aprovada para iniciar `0.2.x`.
