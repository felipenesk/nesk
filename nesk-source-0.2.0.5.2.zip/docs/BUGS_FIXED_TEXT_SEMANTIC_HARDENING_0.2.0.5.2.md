# Bugs corrigidos — Text / Semantic Hardening

1. Preâmbulos coloquiais não alcançavam a ação local.
2. Preambulos poderiam divergir entre router e interpretador semântico.
3. `procura no YouTube` criava a query literal `no youtube` no Google.
4. Continuação engine-only em sessão nova podia seguir para interpretação inadequada em vez de pedir assunto.
5. `abre o canal ... no YouTube` era rotulado como programa local desconhecido.
6. Um `programs.open` local legado com alvo desconhecido podia ultrapassar o coordinator.
7. Ordem por tamanho de alias invertia opções de clarificação.
8. Clarificação não representava seleção múltipla tipada.
9. `config.programs` aceitava arquivo existente sem exigir `.exe`, raiz ou proveniência.
10. NLU/semântica/catálogo Windows tinham fontes de programa desconectadas.
11. Provider remoto poderia ser ativado por string truthy como `"false"`.
12. Release check compilava somente `src`, apesar de scripts/tests fazerem parte da entrega.
13. Cache local sintaticamente válida poderia aparecer no snapshot antes de uma enumeração nova; agora cache nunca é autoridade de entrada ativa.
14. Um `ProgramTarget` manual com basename Foundation, ou uma resolução por `PATH`, poderia tentar contornar o catálogo; launch exige o target canônico exato e revalidado.
15. Metadados de config/cache path-like e erro nativo de `Popen` poderiam transportar path local para uma fronteira pública; ambos são sanitizados/falham fechados.
16. Expansão por ambiente (`%PROGRAMFILES%`, `SystemRoot`, `WINDIR`) poderia ser manipulada pelo launcher; variáveis permitidas agora vêm exclusivamente de APIs Windows conhecidas.
17. App Paths de máquina fora das raízes convencionais não tinha escopo preservado para revalidação; a exceção `HKLM` agora é estreita, tipada e rejeita UNC/device/perfil/Desktop/Downloads/TEMP.

Cada item possui regressão automatizada em `tests/test_text_semantic_hardening_0207.py` ou na suíte Foundation existente.
