# Nota de arquitetura futura — Media / Spotify

Esta nota não adiciona ferramenta, integração ou automação nesta build.

## Contratos futuros desejados

```text
"abre o Spotify"
  -> programs.open
  -> ProgramDirectory / WindowsProgramCatalog

"pausa" / "próxima faixa"
  -> media.play_pause / media.next / media.previous
  -> Windows media-session boundary dedicada

"toca X no Spotify"
  -> futura integração Spotify autenticada, com consentimento e contrato próprio
```

`programs.open` limita-se a abrir o aplicativo legitimamente descoberto. Ele não deve simular play/pause por mouse/teclado, buscar faixa, fabricar URL, controlar processo por texto ou usar shell.

Uma fase futura de mídia deverá ter ToolRegistry próprio, permissões explícitas, identificador de sessão confiável, testes de ausência de sessão e privacidade/autenticação separadas. A integração Spotify específica exigirá credenciais/consentimento fora de `SemanticProvider` e nunca será representada como path/argumento livre de programa.
