# Voice Foundation 0.1.7

A Voice não usa microfone real nesta build. O pipeline foi separado para que o Windows, modelos e voz possam ser trocados sem alterar o Core.

```text
Audio source
  -> optional SpeakerVerifier
  -> SpeechToTextProvider
  -> NeskCore.handle(text)
  -> TextToSpeechProvider
```

## Speaker verification
É uma fronteira futura, não uma promessa de reconhecimento perfeito. Microfones ruins, ruído, vozes parecidas e reprodução de áudio exigirão thresholds, fallback para Push-to-Talk e confirmações para ações importantes.

Por padrão:
- `speaker_verification=false`
- `store_audio=false`
