# Windows 10 — Test Plan 0.2.0.3 Voice Input Hardening

## A. Inicialização / migração
1. Extrair em pasta nova e rodar `INICIAR_NESK.bat`.
2. Confirmar abertura normal da UI.
3. Rodar `VALIDAR_NESK.bat` e confirmar ausência de erro.

## B. STT isolado
1. Rodar `TESTAR_STT.bat`.
2. Falar `NESK, abre o YouTube.`.
3. Confirmar transcrição correta ou próxima o suficiente para manter o sentido literal.
4. Registrar duração do áudio, inferência e realtime factor.

## C. Cadeia completa
1. `NESK, abre o YouTube.` → deve abrir.
2. `NESK, pesquisa Minecraft 1.12.2.` → deve pesquisar.
3. `NESK, abre o Discord.` → deve abrir.

## D. Confirmação por voz
1. `NESK, fecha o Discord.` → deve pedir confirmação.
2. `Sim, por favor.` → deve confirmar e fechar.
3. Reabrir Discord e pedir fechamento novamente.
4. Responder `acho que sim` → **não deve executar**; deve pedir confirmação clara.
5. Responder `não` → deve cancelar.

## E. Segurança de linguagem
1. `NESK, não fecha o Discord.` → nenhuma ação.
2. `Eu estava pensando em fechar o Discord.` → nenhuma ação.
3. Durante confirmação, dizer `sim, mas espera` → nenhuma ação.
4. Durante confirmação, dizer um pedido novo, por exemplo `abre o YouTube` → ação antiga deve expirar antes do novo pedido.

## F. Silêncio / turnos
1. Segurar o botão por ~1 s sem falar → não executar nada; esperar `silêncio detectado`.
2. Dar um toque muito curto → esperar `fala curta demais`.
3. Fazer 10 turnos seguidos de frases curtas e confirmar retorno a `IDLE` em todos.

## G. Shutdown
1. Usar voz pelo menos 3 vezes para garantir modelo STT carregado.
2. Fechar/restaurar pelo tray uma vez.
3. Usar `Sair` no tray.
4. Confirmar que UI, tray e launcher encerram e não há processo NESK restante.

## H. Desempenho de campo
Anotar aproximadamente:
- RAM em idle após carregar STT;
- pico de CPU durante inferência;
- tempo típico de frase curta;
- comportamento com Minecraft/jogo aberto.

TTS só deve entrar depois que C/D/E/F/G passarem de forma repetível.
