# Test Report — NESK 0.2.0.3 Voice Input Hardening

## Origem
Testes reais da 0.2.0.2 mostraram que STT + Core + tools já conseguiam abrir YouTube/Discord e pesquisar Minecraft. O problema de campo remanescente apareceu no fluxo de confirmação: `Sim, por favor.` não era reconhecido como confirmação clara e expirava a ação pendente; o `Sim.` seguinte chegava tarde demais.

## Causa raiz
A confirmação era uma lista simples dentro do Core. Ela não possuía normalização própria de pontuação/polidez nem um estado explícito para resposta ambígua. O normalizador geral preserva alguns caracteres por razões de parsing de URL, então não deve ser reutilizado sozinho como política de autorização.

## Correções
- Classificador dedicado `ConfirmationDecision` com `CONFIRM`, `CANCEL`, `AMBIGUOUS` e `UNRELATED`.
- Frases ambíguas nunca autorizam e mantêm a ação pendente.
- Gate de silêncio conservador antes do STT.
- Lifecycle explícito e idempotente para providers de voz.
- Serialização entre finalização de turno e shutdown.
- Regressão de 10 turnos consecutivos.
- Config schema 5 para thresholds do gate.

## Segurança preservada
- Nenhum fuzzy matching transforma transcrição incorreta em comando.
- Negação continua no-op.
- Menção conversacional continua no-op.
- Áudio continua somente em RAM e não é persistido por padrão.
- Métricas não guardam transcrição.

## Resultado automatizado
- 260 testes coletados e aprovados;
- compileall aprovado;
- smoke test aprovado;
- self-check headless aprovado;
- instalação limpa do pacote aprovada;
- higiene de fonte e sincronização de versão aprovadas;
- suíte Foundation 0.1.x preservada.

## Teste de campo necessário
Executar `docs/TEST_PLAN_WINDOWS10_0.2.0.3.md` no notebook Windows 10 de referência, principalmente confirmação `Sim, por favor.`, ambiguidade, silêncio e shutdown após STT carregado.
