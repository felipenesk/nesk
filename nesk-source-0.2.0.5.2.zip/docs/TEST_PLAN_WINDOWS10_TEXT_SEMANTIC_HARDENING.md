# Plano Windows 10 — Text / Semantic Hardening

Use a build empacotada no Windows 10 de referência. Comece por texto, com somente uma instância do NESK aberta. Não trate falha de voz como falha semântica até comparar com o mesmo texto digitado.

## 1. Preflight

1. Execute `VALIDAR_NESK.bat` ou `NESK.exe --self-check`.
2. Confirme que `config.json` não contém paths arbitrários em `programs` e que o provider semântico remoto continua opt-in.
3. Abra a UI, sem pressionar push-to-talk ainda.

## 2. Texto — regressão Foundation/Semantic Context

Verifique ação direta:

1. `abre o Discord`
2. `fecha ele`
3. `pesquisa Minecraft 1.12.2 no Google`
4. `agora procura isso no YouTube`
5. `abre o YouTube`

Em uma sessão nova, `fecha ele` e `procura isso` devem pedir esclarecimento, nunca agir.

## 3. Texto — preâmbulos e modalidade

Cada uma deve agir na ferramenta indicada:

1. `ae mano abre o Discord aí pra mim`
2. `vei bota o Discord pra rodar`
3. `mano consegue abrir o bloco de notas pra mim`
4. `tipo assim abre o YouTube aí`
5. `po abre a calculadora rapidinho`
6. `cara fecha o Discord aí pra mim`

Nenhuma destas pode executar:

1. `mano não abre o Discord`
2. `cara eu estava pensando em abrir o Discord`
3. `tipo assim como eu faço pra abrir o Discord?`
4. `mano talvez eu abra o Discord depois`
5. `vei eu não quero que você abra o Discord`

## 4. Texto — busca, tipo e clarificação

1. Pesquise `Dark Souls Remastered` no Google; depois diga `agora procura no YouTube`. Confirme query anterior e engine YouTube.
2. Em sessão nova, `agora procura no YouTube` deve perguntar o assunto.
3. `abre o canal do alanzoka no YouTube` deve abrir busca YouTube, sem mensagem de programa desconhecido.
4. `abre Discord e Bloco de Notas` deve listar Discord como opção 1 e Bloco de Notas como opção 2.
5. Repita e responda `a primeira`, depois `a segunda` em uma nova clarificação.
6. Repita e responda `os dois`; confirme que ambos abriram. Se um falhar, a resposta deve dizer qual resultado falhou/parcial.

## 5. Program Discovery Alpha

Sem editar paths manualmente, tente abrir um app realmente instalado e registrado, por exemplo Spotify, Riot Client ou Logitech G Hub.

1. Verifique que `abre <nome>` só funciona quando o app está legitimamente reconhecido.
2. Se houver dois apps com mesmo display, a UI deve pedir escolha, não abrir um arbitrariamente.
3. `fecha <app descoberto>` deve funcionar somente quando o NESK já tiver identidade de processo explicitamente permitida; caso contrário deve recusar com segurança.
4. Não teste com executáveis em Desktop/Downloads, documentos, `.cmd`/`.bat` ou paths copiados; eles devem continuar fora do catálogo.

## 6. Voz — somente após texto passar

Repita por push-to-talk um subconjunto literal:

1. `NESK, abre o Discord.`
2. `NESK, agora procura no YouTube.` após uma busca textual bem-sucedida.
3. `NESK, não fecha o Discord.`

Se o texto digitado funcionar e a voz falhar, registre transcrição, métricas do pipeline e etapa de endpoint/STT. Não altere a semântica para compensar palavra/tempo verbal transcrito incorretamente.

## Registro de campo

Para cada falha, registre versão, texto digitado/transcrição observada, ação exibida, resultado e se havia contexto/clarificação pendente. Não anexe áudio bruto, paths pessoais, credenciais ou banco SQLite.
