# Test Report — NESK 0.1.9 Foundation Release Candidate

## Resultado automatizado

- 187 testes coletados.
- 187 testes aprovados.
- `compileall`: aprovado.
- Smoke test: aprovado.
- Headless self-check: aprovado.
- Instalação limpa do pacote fora da árvore de desenvolvimento: aprovada.
- Version sync: aprovado.
- Source hygiene/credential scan: aprovado.

## O que foi validado nesta build

- NLU e regressões de campo das 0.1.7/0.1.8.
- Tool Registry e Permission Policy.
- Banco SQLite schema 2 + quick integrity check.
- Memória-base e níveis de privacidade.
- Runtime shutdown idempotente.
- Provider shutdown boundary.
- Voice foundation simulada.
- Tema monocromático por teste estático.
- Self-check que roda sem importar Qt.
- Instalação limpa do pacote Python.

## Limitações do ambiente de build desta entrega

Este ambiente não possui PySide6 nem PyInstaller e não é Windows. Portanto:

- a GUI Qt não foi renderizada aqui;
- um `.exe` Windows não pode ser gerado/cross-compilado daqui;
- `scripts\\build_exe.bat` foi preparado para gerar e self-testar o executável no próprio Windows 10/11 64-bit;
- tray, fechamento real da janela e comportamento do executável dependem do teste no PC Windows 10 de referência.

Essas limitações são explícitas e não bloqueiam o pacote fonte da Release Candidate.
