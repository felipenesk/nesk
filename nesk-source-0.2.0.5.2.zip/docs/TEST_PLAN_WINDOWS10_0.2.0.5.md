# Windows 10 — Test Plan 0.2.0.5 Speech Pipeline Hardening

Objetivo: validar no notebook de referência que a entrada de voz ficou mais literal e previsível sem transformar erro de STT em comando.

## 1. Boot / migração
1. Fechar versões anteriores pelo tray.
2. Extrair a 0.2.0.5 em pasta nova.
3. Rodar `INICIAR_NESK.bat`.
4. Confirmar boot sem erro e estado `IDLE`.
5. Rodar `VALIDAR_NESK.bat` e verificar conclusão sem erro.

## 2. Corpus isolado (principal)
Rodar `TESTAR_VOZ_QUALIDADE.bat`.

Falar as oito frases exatamente como exibidas, com dicção normal. O teste não executa Core/tools.

Critério inicial para seguir aos testes de integração:
- nenhuma transcrição absurda/repetitiva;
- `abre`/`fecha` preservados na maioria dos turnos;
- qualquer ambiguidade deve ser rejeitada, nunca convertida em ação;
- driver não deve sinalizar perda de bloco em uso normal.

## 3. Integração com Core
Na UI, em turnos separados:
- `NESK, abre o Discord.` → deve abrir.
- `NESK, fecha o Discord.` → deve fechar diretamente.
- `NESK, abre o YouTube para mim.` → deve abrir.
- `NESK, pesquisa Minecraft 1.12.2.` → deve pesquisar.

## 4. Segurança sem adivinhação
Estas frases não podem executar ação:
- `NESK, não fecha o Discord.`
- `Eu estava pensando em fechar o Discord.`
- se a UI disser que houve duas leituras/baixa confiança, nenhuma ferramenta pode ter sido chamada.

## 5. Repetição / ciclo de vida
- 10 turnos consecutivos curtos; sempre voltar a `IDLE`.
- sair pelo tray após STT carregado; processo deve encerrar limpo.

## 6. Desempenho observado
Registrar visualmente, sem benchmark obsessivo:
- RAM do NESK após carregar STT;
- tempo típico de transcrição;
- se o notebook permanece responsivo.

O modelo permanece `small/int8` nesta build. Só avaliar modelo maior se o corpus real continuar insuficiente.
