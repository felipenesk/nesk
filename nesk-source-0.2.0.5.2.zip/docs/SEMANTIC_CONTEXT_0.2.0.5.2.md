# Semantic Context extension — 0.2.0.5.2 baseline

## Scope

This extension adds structured semantic interpretation, transient context and clarification to the existing First Listen build. It does not add TTS, wake word, continuous listening, Memory Alpha, new integrations, arbitrary shell access or a second speech pipeline.

## Flow

```text
input text / finalized transcript
  -> deterministic local NLU
  -> target/reference validation
  -> local semantic composition if needed
  -> optional semantic provider if still needed
  -> structured candidate validation
  -> transient reference resolution / clarification
  -> existing Intent
  -> existing Core -> Tool Registry -> Permission Policy
```

Clear supported commands remain local and work when offline. The local semantic composition uses action families plus known entities, not fuzzy correction or a list of full phrases. It recognizes indirect/filler-heavy wording only when a canonical allowed entity makes the meaning clear. The Text / Semantic Hardening addendum extends this with initial discourse markers, engine-only local search continuation, typed multi-select and ProgramDirectory; see `TEXT_SEMANTIC_HARDENING_0.2.0.5.2.md`.

## Confidence policy

- High: validated candidate becomes an `Intent` and follows normal tool/permission policy.
- Intermediate: NESK asks a short clarification; it never turns intermediate confidence into a generic execution confirmation.
- Low/invalid/unavailable: no tool runs; NESK uses safe fallback.

The provider's numeric confidence is never sufficient by itself. Tool registration, target allowlist, argument shape, request modality and context compatibility are all required.

## Provider contract

`SemanticProvider` receives `SemanticRequest` and returns `SemanticCandidate | None`.

- Request: current text, allowed actions/current ProgramDirectory IDs and only relevant typed transient fields.
- Candidate: action, scalar target, confidence, constrained entities/options and a clarification flag.
- No ToolRegistry, callable, shell command, path, URL or free-form execution payload crosses the boundary.
- OpenAI is optional and lazy-imported. Set both `semantic.provider="openai"` and `semantic.allow_remote=true`; installation remains `pip install -e ".[openai]"`.
- The Core applies a 4-second default deadline, cancellation event and turn generation check. A late result cannot reach `ToolRegistry`.

## Privacy

Context is session-only RAM and is not automatic memory. It is updated only after a successful tool outcome. Remote semantic requests intentionally exclude conversation messages, SQLite history, memory (including `local_only`), logs, audio, paths and credentials. The remote path is off by default.

## Supported session references

- `abre Discord` → `fecha ele`
- `pesquisa Minecraft 1.12.2` → `agora procura isso no YouTube`
- `pesquisa Ice and Fire` → `agora vê no YouTube`
- `pesquisa Dark Souls Remastered no Google` → `agora procura no YouTube`

The antecedent must be recent, type-compatible and active. If it is missing, stale or incompatible, NESK asks instead of guessing.
