# Windows 10 — Test Plan 0.2.0.4 Voice Capture Hardening

## Objetivo
Validar o caminho real `push-to-talk → captura → STT → Core` após os achados de campo da 0.2.0.3.

## Ordem de teste
1. Abrir `INICIAR_NESK.bat` e confirmar boot normal.
2. Na UI, segurar o botão até `LISTENING`, falar `Não.` e soltar normalmente. Esperado: `Não.` ou rejeição explícita por baixa confiança; nunca texto alucinado enviado ao Core.
3. Falar `NESK, abre o YouTube.`. Esperado: transcrição correta e abertura.
4. Falar `NESK, abre o Discord.`. Esperado: abertura direta.
5. Falar `NESK, fecha o Discord.`. Esperado: fechamento direto, sem confirmação, restrito ao catálogo conhecido.
6. Falar `NESK, não fecha o Discord.`. Esperado: nenhuma ação.
7. Fazer um toque sem fala. Esperado: silêncio/fala curta/baixa confiança; nenhuma ação.
8. Repetir 10 turnos misturando frases curtas e comandos e confirmar retorno a `IDLE`.
9. Sair pelo tray após uso do STT e confirmar encerramento total.

## Probe isolado
Executar `TESTAR_STT.bat` com:
- `Não.`
- `Sim.`
- `NESK, abre o YouTube.`

Registrar duração, RMS/pico, avg_logprob, no_speech, retry e quality gate. O probe nunca executa Core/tools.
