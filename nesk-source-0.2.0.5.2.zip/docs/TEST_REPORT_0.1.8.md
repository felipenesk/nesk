# NESK 0.1.8 — Test Report

## Origem

Esta build foi criada após teste real da 0.1.7 em Windows 10. O teste de campo confirmou a maior parte da Foundation e revelou duas regressões pequenas de linguagem:

1. `pesquisa valorant pra min` mantinha `pra min` na query.
2. `nesk oque você consegue fazer` não reconhecia `oque` sem espaço.

Também foi observado que no-op seguro em negações/perguntas parecia um erro por causa da resposta genérica do fallback local.

## Correções

- filler `pra min` / `para min` tolerado;
- `oque` canonicalizado para phrase matching;
- capability query ampliada;
- fallback local explica no-op seguro;
- capability summary derivado do Tool Registry;
- regressões reais adicionadas aos testes.

## Validação automatizada

- 181 testes coletados e aprovados;
- `compileall`: aprovado;
- smoke test: aprovado;
- version sync: aprovado;
- `scripts/release_check.py`: aprovado.

## Validação ainda necessária

Executar a 0.1.8 no PC Windows 10 de referência e repetir os casos acima antes de declarar a linha Foundation encerrada.
