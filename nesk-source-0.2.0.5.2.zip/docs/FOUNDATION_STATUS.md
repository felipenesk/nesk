# NESK Foundation Status

**Versão:** 0.1.9 Release Candidate

## Automatizado

- Core: aprovado
- NLU PT-BR: aprovado
- Tools/permissões: aprovado
- SQLite/migração: aprovado
- Memória-base/privacidade: aprovado
- Voice contracts/controller simulado: aprovado
- Release engineering: aprovado
- Instalação limpa: aprovada

## Aguardando Windows 10 real

- `VALIDAR_NESK.bat`
- tray / minimizar / restaurar / sair
- ausência de processo residual aparente
- consumo idle de CPU/RAM
- build experimental `NESK.exe`
- self-check do `.exe`
- teste manual básico do `.exe`

Se esses itens passarem, `0.1.x` entra em feature freeze e o próximo desenvolvimento funcional é `0.2.x — First Voice`.
