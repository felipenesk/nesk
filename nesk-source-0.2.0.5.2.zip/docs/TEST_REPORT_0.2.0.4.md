# Test Report — NESK 0.2.0.4 Voice Capture Hardening

## Ambiente de desenvolvimento
Validação automatizada no ambiente de build; hardware real Windows 10 ainda requer teste de campo.

## Resultado automatizado
- 268 testes coletados e aprovados.
- `compileall`: OK.
- Smoke test: OK.
- Headless self-check: OK.
- Instalação limpa fora da árvore de desenvolvimento: OK.
- Source hygiene: OK.
- Version sync: OK.
- Release check completo: OK.

## Regressões novas
- Stream precisa entregar primeiro callback antes de ser considerado armado.
- Timeout de arming aborta/fecha stream de forma limpa.
- Fala curta de baixa confiança pode receber segunda passada literal.
- Fala curta de boa confiança não paga o custo da segunda passada.
- `no_speech_prob` suspeito bloqueia transcrição antes do Core.
- Fechamento de programa conhecido é LOW/direto conforme preferência do usuário.

## Pendente
Executar `TEST_PLAN_WINDOWS10_0.2.0.4.md` no notebook de referência.
