# NESK Vision

NESK is a persistent personal AI that begins on Windows and can later exist through multiple nodes such as a phone, wearable device or project integration.

Core principles:
- Conversation is central, not an add-on.
- NESK identity is independent from any single model provider.
- Memory belongs to the user.
- Capabilities are tools connected to the Core.
- Devices are nodes; NESK should not be recreated per device.
- Offline loss of connectivity should reduce capability rather than erase the assistant.
- Autonomy can grow, but critical self-development remains supervised.
- Performance matters: NESK should remain useful on modest hardware.
