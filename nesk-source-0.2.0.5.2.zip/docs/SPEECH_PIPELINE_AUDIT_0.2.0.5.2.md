# Auditoria do Speech Pipeline — 0.2.0.5.2

## Escopo preservado

Esta revisão limita-se ao First Listen. Foundation 0.1.x, Core, Intent Router, Tool Registry, permissões, privacidade e confirmações foram preservados. Não foram adicionados TTS, wake word, escuta contínua, memória ou correção textual de comandos.

## Causas-raiz encontradas

1. Existiam três implementações práticas de voz:
   - UI: VoiceService, push-to-talk e gate local.
   - TESTAR_STT: captura/provider criados diretamente, encerrados por ENTER.
   - benchmark: captura/provider próprios e gravação fixa de cinco segundos.

   Portanto a mesma fala não passava pelo mesmo código.

2. A janela fixa diluía falas curtas. Uma fala audível em uma pequena fração de cinco segundos podia cair abaixo do gate RMS da janela inteira, apesar de ter pico real válido.

3. Havia heurísticas empilhadas: RMS/pico, trim energético, ganho automático, VAD do faster-whisper, thresholds do decoder e gate externo divergente. Isso permitia que uma camada contradissesse a outra.

4. O provider fazia uma segunda decodificação completa para casos curtos/comando. Além do custo de CPU/RAM, duas leituras podiam divergir e escolher texto diferente sem evidência acústica suficiente.

5. VoiceService lia warning/overflow antes de stop/post-roll. Um aviso tardio podia atravessar para o STT.

6. A UI aguardava até o primeiro callback do PortAudio ao pressionar o botão, enquanto o probe só pedia fala depois de armado. Isso criava comportamento diferente e potencial travamento percebido.

7. Cancelamento durante STT e callbacks tardios de stream não tinham uma geração/ticket explícito. Em condições de corrida, texto cancelado podia chegar ao Core ou bytes antigos contaminar uma captura nova.

8. Discord era lançado por Update.exe, mas a detecção de fechamento precisava esperar apenas pelo processo final permitido, sem encerrar o atualizador.

## Arquitetura final

    MicrophoneCapture
        -> CaptureResult(audio em RAM, formato real, warning/overflow, endpoint)
        -> SpeechPipeline
            -> validação de integridade e duração
            -> verificação de locutor existente, quando habilitada
            -> preparo canônico uma vez
            -> uma decodificação faster-whisper
            -> quality gate técnico único
        -> VoiceController
        -> NeskCore

UI usa start_capture/finish_capture através de VoiceService. TESTAR_STT e TESTAR_VOZ_QUALIDADE usam capture_until_endpoint no mesmo SpeechPipeline e nunca recebem referência ao Core.

## Política de sinal e qualidade

- Captura: mono PCM16, sample rate real relatado, bloco configurável e post-roll curto.
- Endpoint: nível centralizado de -60 dBFS, 120 ms mínimos de fala e 650 ms de pausa. Ele encerra probes; não rejeita a fala.
- Preparo: PCM16 para float32 mono, 16 kHz e remoção de DC. Não há trim, gain ou normalização de fala.
- Entrada morta: apenas buffer PCM exatamente zero é recusado localmente. Não existe gate RMS/pico da janela inteira.
- Decoder: idioma PT, tarefa transcribe, VAD uma vez, beam/patience configuráveis.
- Quality: no-speech é considerado junto de avg_logprob como no decoder; baixa confiança, compression ratio anômalo e repetição adjacente de frase são rejeitados. Não há lista de frases para corrigir verbo ou alvo.

## Integridade e concorrência

- O primeiro callback não bloqueia o clique da UI; readiness é validada quando a captura é finalizada.
- Callback e stream carregam uma geração. Cancelar invalida a geração antes de limpar buffer, impedindo dados tardios.
- Stop devolve o resultado com flags já observadas; falha do driver limpa o stream para a próxima tentativa.
- Cancelar/close durante inferência invalida o ticket do turno. O handoff ao Core é linearizado contra cancelamento; se o handoff já começou, close pode aguardar core.handle terminar para não abrir uma corrida de segurança.
- O provider pertence ao SpeechPipeline em runtime. VoiceController mantém ownership de STT para seu caminho legado direto.

## Discord

O catálogo aceita nomes finais exatos: Discord.exe, DiscordPTB.exe, DiscordCanary.exe e DiscordDevelopment.exe. Update.exe nunca é elegível para encerramento. Após abrir Discord pelo catálogo, a procura pelo processo final é limitada a cinco segundos dentro de uma janela de dez segundos.

## Riscos que permanecem

- A qualidade acústica, driver PortAudio, permissão de microfone, primeiro download do modelo e DLLs nativas do executável exigem Windows real.
- Uma fala extremamente baixa pode não disparar endpoint e o benchmark chegar ao timeout máximo. Ela ainda segue para STT; não é descartada pelo nível médio do buffer.
- O self-check de build importa as dependências nativas de voz, mas não abre GUI/microfone nem carrega/decodifica o modelo; ele não substitui o roteiro manual.
