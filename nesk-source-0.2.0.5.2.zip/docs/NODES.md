# NESK Nodes

NESK não deve ser definido como "o programa do Windows". O Windows é o primeiro node.

```text
NESK Core
├── local-windows
│   └── capabilities atuais
├── android (futuro)
└── glasses (futuro)
```

0.1.7 contém apenas a abstração local. Não há rede, pareamento ou controle remoto implementados.
