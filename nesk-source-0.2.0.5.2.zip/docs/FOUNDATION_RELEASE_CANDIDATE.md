# Foundation Release Candidate — 0.1.9

## Critério de encerramento da linha 0.1.x

A Foundation pode ser congelada quando:

- o release check automatizado estiver verde;
- `VALIDAR_NESK.bat` passar no Windows 10 de referência;
- interface abrir/fechar e tray funcionar sem processo residual aparente;
- comandos e negações já validados na 0.1.8 continuarem sem regressão;
- reinício preservar banco/configuração;
- o primeiro build `NESK.exe`, quando gerado no Windows, passar no self-check e no teste manual básico.

Após isso, mudanças de funcionalidade pertencem à linha `0.2.x`. A `0.1.x` só recebe correção de bug crítico/regressão.

## O que não bloqueia o First Voice

- Vault criptografado;
- memória automática;
- pesquisa web autônoma;
- visão;
- celular/óculos;
- wake word permanente;
- LLM local completo.

Esses recursos são camadas futuras e não devem atrasar o fechamento da Foundation.
