# NESK Architecture Decisions — Foundation

## ADR-001: Core identity is provider-independent
Accepted. AI backends implement a provider interface. Replacing a model does not replace NESK.

## ADR-002: Voice is a transport into the same Core
Accepted. Text and future microphone transcription converge on the same `NeskCore.handle()` path.

## ADR-003: Deterministic safe actions precede model routing
Accepted. High-confidence local actions such as system status and known application launch are routed locally for reliability, latency and safety.

## ADR-004: No arbitrary shell exposed to the model
Accepted. The model cannot pass arbitrary command text to cmd/PowerShell in Foundation.

## ADR-005: Session context is separate from disk history
Accepted. Disabling persistence does not break conversational continuity within the current process.

## ADR-006: SQLite first, encrypted Vault later
Accepted with warning. SQLite is appropriate for Foundation structure and testing; sensitive long-term memory waits for encrypted-at-rest Vault work.

## ADR-007: Windows-specific behavior stays behind a platform boundary
Accepted. Windows 10 is the first reference platform without hard-wiring the Core to Windows APIs.

## ADR-008: PT-BR command vocabulary is data-oriented
Accepted. Synonyms/aliases live in a dedicated lexical layer rather than being spread across the Core. This keeps growth maintainable and testable.

## ADR-009: Local NLU prefers false negatives over unsafe false positives
Accepted. Ambiguous text should fall through to conversation rather than execute a guessed action.

## ADR-010: Raw voice audio is not persisted by default
Accepted. Voice configuration starts with `store_audio=false`; future recording requires explicit user choice.

## ADR-011: Voice gets an explicit state machine before microphone integration
Accepted. Listening/transcribing/processing/speaking states are modeled before asynchronous audio callbacks are introduced.


## ADR-012: SQLite schema must be versioned before Memory grows
Accepted. Foundation databases now carry a schema version. Legacy unversioned databases are adopted without deleting existing messages; future structural changes must use explicit migrations.
