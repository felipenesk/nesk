# Windows 10 — Test Plan 0.2.0 First Listen

## A. Instalação
1. Extrair em pasta nova.
2. Rodar `INICIAR_NESK.bat`.
3. Confirmar instalação do stack de voz e abertura da UI.
4. Rodar `VALIDAR_NESK.bat` e registrar o diagnóstico de microfone.

## B. Regressão Foundation
1. `como está meu PC?`
2. `abre o bloco de notas`
3. `abre o YouTube`
4. `não abre o YouTube` deve ser no-op.
5. fechar/restaurar via tray e sair completamente.

## C. First Listen seguro
1. Segurar `SEGURE`.
2. Falar `NESK, o que você consegue fazer?`.
3. Soltar.
4. Confirmar transcrição `VOCÊ · VOZ` e resposta em texto.
5. Repetir três vezes para verificar reutilização do modelo.

## D. Ação por voz
1. Falar `NESK, abre a calculadora`.
2. Confirmar transcrição correta.
3. Confirmar execução da calculadora.
4. Falar `NESK, não abre o YouTube` e confirmar que nada abre.

## E. Robustez
1. Pressionar/soltar sem falar.
2. Falar por menos de ~0,25 s.
3. Testar com música/jogo em volume normal.
4. Fechar NESK enquanto não está gravando.
5. Iniciar captura e então encerrar pelo tray; processo deve terminar limpo.

## F. Medição
Anotar aproximadamente:
- tempo do primeiro turno;
- tempo dos turnos seguintes;
- RAM idle;
- pico de RAM durante STT;
- CPU durante transcrição;
- impacto perceptível em jogo.

A `0.2.0` não é aprovada para avançar para TTS até B/C/D estarem estáveis.
