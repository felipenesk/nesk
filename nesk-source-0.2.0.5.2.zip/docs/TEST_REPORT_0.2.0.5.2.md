# Test Report — NESK 0.2.0.5.2

## Resultado

- Testes coletados: 294.
- Aprovados: 294.
- Falhos: 0.
- Skipped: 0.
- Compilação de src, scripts e tests: aprovada.
- Release check: aprovado.
- Instalação limpa do pacote: aprovada.
- Smoke test e self-check headless: aprovados.
- Executável Windows onedir: gerado e aprovado em self-check.

## Regressões acrescentadas nesta revisão

- UI, probe e benchmark dependem de SpeechPipeline e não do Core.
- Uma decodificação por turno e uma carga de modelo por provider.
- Alto no-speech com alta confiança não é rejeitado isoladamente.
- Baixa confiança e repetição técnica falham fechados.
- Buffer zero, buffer curto, overflow, warning no stop/post-roll e falha de stop do driver.
- Endpoint com fala quieta e timeout/cancelamento.
- Callback tardio de stream cancelado não contamina o próximo turno.
- Cancelamento durante STT não chama Core.
- Speaker verification volta a ocorrer antes de STT/Core.
- Ownership de STT no VoiceController legado e no serviço sem double-close.
- Defaults serializados e runtime idênticos; migração para schema 9.
- Discord Stable/PTB/Canary/development, spawn atrasado e proteção explícita de Update.exe.
- ZIP de fonte sem .env, logs, bancos, cache de QA ou work.

## Validações executadas

1. pytest completo com 294 aprovados.
2. scripts/release_check.py:
   - sincronização de versão 0.2.0.5.2;
   - higiene de fonte;
   - compile;
   - suite;
   - smoke;
   - self-check;
   - instalação limpa.
3. Build PyInstaller Windows x64:
   - PyInstaller 6.22.2;
   - CPython 3.12.13 no ambiente de build;
   - dependências locais de voz coletadas: faster-whisper, ctranslate2, sounddevice, av, tokenizers e huggingface_hub;
   - NESK.exe --self-check aprovado.

## Performance

Não foi executada medição acústica nesta sessão porque não há microfone real em escopo. O benchmark entregue mostra por turno duração capturada, Hz real, endpoint/timeout, pré-processamento, inferência, RTF, segmentos, carga do modelo e RAM, sem persistir áudio ou transcrição.

## Riscos restantes

- Ainda é obrigatório testar microfone/PortAudio, permissões, modelo small no primeiro download e qualidade das frases no Windows 10 alvo.
- O self-check do executável importa a pilha nativa de voz, mas não abre microfone nem carrega/decodifica o modelo.
- Close pode aguardar core.handle se o handoff seguro ao Core já começou; isso evita corrida em que um cancelamento poderia permitir execução posterior.
- Fala extremamente baixa pode chegar ao timeout de endpoint, mas não é descartada por RMS/pico médio.

Use docs/TEST_PLAN_WINDOWS10_0.2.0.5.2.md para a validação de campo.
