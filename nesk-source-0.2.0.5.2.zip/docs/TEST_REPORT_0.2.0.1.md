# Test Report — NESK 0.2.0.1 First Listen Hotfix 1

## Origem do hotfix
Teste de campo no Windows 10 confirmou que o caminho de voz funcionava, mas uma transcrição válida no formato `NESK. Abre o YouTube para mim.` não era roteada como comando. Sem o vocativo (`Abre o YouTube para mim.`), a mesma ação funcionava normalmente.

## Causa raiz
`strip_wake_name()` aceitava vírgula, ponto-e-vírgula, dois-pontos e hífen após `NESK`, mas não aceitava ponto final e outras pontuações que um STT pode inserir naturalmente ao interpretar o vocativo.

## Correção
O parser agora remove somente o vocativo inicial `NESK` e a pontuação imediatamente associada a ele. O restante da frase continua usando o NLU determinístico e conservador já existente.

Cobertura de regressão adicionada para:
- `NESK, ...`
- `NESK. ...`
- `NESK... ...`
- `NESK! ...`
- `NESK? ...`
- `NESK: ...`
- `NESK - ...`
- abertura de site;
- pesquisa;
- status do sistema;
- fechamento com fluxo de risco existente;
- negação, garantindo que `NESK. não abre o YouTube` não execute ação.

## Resultado automatizado
- 214 testes coletados e aprovados;
- compileall aprovado;
- smoke test aprovado;
- self-check headless aprovado;
- instalação limpa do pacote aprovada;
- higiene de fonte aprovada;
- sincronização de versão aprovada.

## Teste de campo ainda necessário
Confirmar no Windows real que a frase `NESK. Abre o YouTube para mim.` agora abre o YouTube após transcrição por voz.
