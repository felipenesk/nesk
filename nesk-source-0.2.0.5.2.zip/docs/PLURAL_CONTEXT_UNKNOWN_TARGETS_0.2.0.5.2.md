# Hotfix textual pós-validação — contexto plural e alvos desconhecidos

## Escopo

Esta correção é restrita ao caminho texto/semântico da fonte
`NESK_0.2.0.5.2_TextSemanticHardening_source`. Não altera Foundation 0.1.x,
Speech Pipeline, Program Discovery Alpha, catálogo Windows, ToolRegistry,
permissões, TTS, wake word, mídia ou memória persistente.

## Diagnóstico

### Referência plural após abertura em lote

O contrato anterior de `SessionContext` guardava apenas `last_program`. Após
uma abertura aprovada de Spotify e Discord, o segundo sucesso substituía o
primeiro. Além disso, o parser reconhecia somente referências singulares,
portanto `fecha eles` terminava em uma pergunta genérica.

Agora, somente o encerramento bem-sucedido de uma clarificação aprovada de
duas aberturas canônicas registra `recent_program_group`:

```text
("spotify", "discord")
```

O campo fica apenas na instância RAM de `SessionContext`; não guarda Intents,
ToolResults, display names, paths, objetos de Tool, SQLite ou Memory Alpha.
Uma referência plural é resolvida localmente, com TTL e compatibilidade de
ação, e o coordinator relê cada ID no `ProgramDirectory` antes de construir
**novos** Intents de `programs.close` ou `programs.open`. Cada Intent segue
individualmente por `NeskCore._run_intent` → `ToolRegistry` →
`PermissionPolicy`.

Um grupo deixa de ser antecedente após uma Tool bem-sucedida interveniente,
após expiração, sessão nova, lote parcial/cancelado ou entrada removida do
diretório. A própria referência plural é de uso único: o grupo é consumido
assim que a nova operação, já validada, começa. Portanto uma falha ou
cancelamento não permite repetir cegamente a referência antiga. `abre eles` é
aceito somente quando há esse grupo compatível; sem grupo ele pede
clarificação. O grupo nunca é incluído no `SemanticContextView` ou no payload
do provider remoto.

Formas aceitas somente neste contrato de programa são `eles`, `elas`,
`ambos`, `ambas`, `os dois`, `as duas`, `os 2` e `as 2`; elas não ampliam
pesquisa, shell, arquivos ou outras Tools.

### Programa explicitamente desconhecido

O router já recusava converter texto desconhecido em `programs.open`, mas o
interpretador local posteriormente usava `ProgramDirectory.mentions()`. Essa
API devolve apenas aliases conhecidos: ela apagava a parte desconhecida de
`Discord e Riot Client`, fazia `Riot Client` parecer o mesmo caso de alvo
ausente e poderia confundir um alvo explícito como `Discord falso` com o alias
embutido `Discord`.

Foi introduzida uma classificação local, não executável, para alvos diretos:

```text
KNOWN | UNKNOWN | MISSING | AMBIGUOUS | INVALID
```

- `MISSING`: alvo deíctico/vago, por exemplo `abre aquele negócio`; mantém a
  clarificação normal.
- `UNKNOWN`: nome explícito público que o diretório atual não reconhece; não
  chama Tool nem provider e informa que o programa não é reconhecido neste
  computador.
- `AMBIGUOUS`: colisão verdadeira no diretório confiável; mostra opções locais.
- `INVALID`: path, URL, controle ou forma shell-like; falha fechada sem ecoar
  o texto perigoso.

Em uma enumeração explícita com `e`, a resolução tenta primeiro o alvo inteiro
(para não quebrar um display name legítimo que contenha `e`) e só depois separa
os segmentos. Fora do wrapper deíctico já suportado, um alias apenas embutido
em texto explícito desconhecido não promove uma execução. Em uma mistura de um
alvo conhecido e um desconhecido, apenas o conhecido vira Intent canônico e
passa pelo caminho normal; a resposta relata o resultado parcial na ordem
mencionada. Dois ou mais alvos conhecidos ainda mantêm a clarificação
pré-existente antes de abrir em lote. Uma nova pergunta após `Qual programa?`
não é reinterpretada como nome desconhecido.

## Fronteiras preservadas

- `ProgramDirectory` continua a ser a única origem de identidade canônica e
  launch target interno. Esta hotfix não adiciona scan, PATH, Start Menu,
  Desktop, Downloads, `.lnk`, fuzzy path ou fontes de discovery.
- `programs.close` continua usando somente `PROCESS_NAMES` exatos da
  Foundation. Um app descoberto pode abrir se seu launch target já era
  confiável, mas não ganha close por inferência de nome.
- Provider semântico não produz grupo, plano de múltiplos programas, path ou
  executável. A classificação nova é local; comandos claros continuam offline.
- Negações, perguntas e hipóteses são bloqueadas antes da classificação de
  referência/alvo.

## Limitações deliberadas

- O grupo atual é de exatamente duas aberturas seguras selecionadas pela
  clarificação já aprovada. Não existe lista livre de Tools ou batch genérico.
- Uma entrada descoberta removida por refresh invalida a referência plural em
  vez de tentar usar identidade antiga.
- `fecha X` para descoberta dinâmica continua indisponível sem mapeamento de
  processo exato, mesmo se `abre X` for aceito.
- A validação de microfone/STT permanece uma etapa manual separada no Windows
  10; esta hotfix não interpreta uma transcrição ruim como defeito semântico.

## Regressões

`tests/test_plural_unknown_hotfix_0208.py` cobre referências plurais, TTL,
sessão nova e shutdown lógico, contexto remoto minimizado, confirmação/permite
por item, cancelamento, resultado parcial, consumo após falha, UNKNOWN/MISSING/
AMBIGUOUS, alias conhecido embutido em alvo desconhecido, misturas em ambas as
ordens, alvos inválidos, descoberta removida e preservação do multi-select
conhecido. A contagem final validada está no relatório de entrega.
