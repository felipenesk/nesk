# Memory Foundation 0.1.7

Memória permanente é explícita nesta fase. O NESK não transforma toda conversa em memória.

Níveis:
- `local_only`: nunca pode sair do dispositivo.
- `private`: privada por padrão; cloud bloqueada salvo política futura explícita.
- `normal`: pode ser liberada por regra/usuário no futuro.

O banco atual não é criptografado. O Vault virá antes de armazenar segredos altamente sensíveis.
