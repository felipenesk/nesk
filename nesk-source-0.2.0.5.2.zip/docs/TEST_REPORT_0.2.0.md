# Test Report — NESK 0.2.0 First Listen

## Resultado automatizado

- **202 testes coletados**.
- Suíte principal: **PASS**.
- `compileall`: **PASS**.
- Smoke test: **PASS**.
- Headless self-check: **PASS**.
- Instalação limpa fora da árvore de desenvolvimento: **PASS**.
- Version sync (`VERSION`, package e `version.py`): **PASS**.
- Source hygiene: **PASS**.
- Release check final: **PASS**.

## Cobertura nova da 0.2.0

- `CapturedAudio`: formato/duração/validação PCM16.
- Captura de microfone com backend simulado.
- Enumeração de dispositivos de entrada.
- Start/stop/cancel do push-to-talk.
- STT local lazy e resampling para 16 kHz.
- STT cloud com WAV somente em memória.
- Voice Controller com e sem TTS.
- Voice Service: fala curta, turno normal, cancelamento e limite máximo.
- Migração config schema 2 → 3 preservando `store_audio=false`.
- Desativação explícita de Voice em schema 3 permanece respeitada.
- UI First Listen preparada para teste offscreen quando PySide6 está disponível.
- Regressão completa da Foundation permanece verde.

## Validação externa de contratos

A implementação foi comparada com a API atual documentada de `faster-whisper` para `WhisperModel.transcribe`, incluindo `beam_size`, `language`, `condition_on_previous_text` e `vad_filter`, e com a API de `sounddevice` para enumeração/checagem de dispositivos.

## O que não pode ser validado neste ambiente

- Driver/microfone físico do PC Windows 10 de referência.
- Latência real do modelo `small` no i5/8 GB.
- Download inicial do modelo no Windows.
- Impacto de CPU/RAM durante Minecraft/jogos.
- Empacotamento final `.exe` Windows com PortAudio/CTranslate2.

Esses pontos formam o teste de campo da `0.2.0`; não são substituídos por mocks.
