# Test Report — NESK 0.2.0.5 Speech Pipeline Hardening

## Validação automatizada no ambiente de desenvolvimento
- Suite Foundation + First Listen + regressões 0.2.0.5.
- Compileall.
- Smoke test.
- Self-check headless.
- Instalação limpa sem dependências externas (`--no-deps`) para validar empacotamento/imports.

## Regressões específicas desta versão
- front-end de áudio faz recorte/normalização somente no sinal e mantém tudo em RAM;
- decoder recebe guards de repetição/no-speech/hallucination;
- comando saudável não paga retry desnecessário;
- comando com baixa confiança pode ser rechecado;
- discordância `abriu` vs `abre` é rejeitada em vez de virar ação;
- warning do PortAudio é rastreado para rejeição segura;
- Discord Stable/PTB/Canary são reconhecidos pelo catálogo de processos;
- probe de qualidade não possui acesso ao `NeskCore`.

## Pendente de hardware real
Executar `TESTAR_VOZ_QUALIDADE.bat` e `docs/TEST_PLAN_WINDOWS10_0.2.0.5.md` no Windows 10 de referência. O microfone/driver e a precisão acústica real não podem ser simulados pela suíte.
