# NESK Architecture — Semantic Context extension

```text
Text UI / Push-to-Talk transcript
              |
              v
          NeskCore.handle
              |
              +--> confirmation pending (permission only)
              |
              +--> clarification pending (short reply only)
              |
              +--> LocalIntentRouter (clear, offline commands)
              |
              +--> IntentResolutionCoordinator
              |       +--> modality/safety guard
              |       +--> ProgramDirectory target validation / transient references
              |       +--> LocalSemanticInterpreter
              |       +--> optional SemanticProvider, with deadline
              |       +--> candidate validation
              |                |
              |                v
              |             Intent (existing contract)
              |
              +--> ToolRegistry --> PermissionPolicy --> allow-listed tools
              |
              +--> conversational AIProvider fallback

SessionContext (RAM only)   ConversationStore (SQLite, independently optional)

ProgramDirectory (local snapshot) -> WindowsProgramCatalog -> programs.open
```

## Execution boundary

Only `NeskCore._run_intent()` calls `ToolRegistry.execute()`. Neither local nor remote semantic interpretation receives a registry or a callable tool. A semantic candidate must pass all of the following before becoming the existing `Intent`:

- action belongs to the narrow semantic allowlist;
- named Tool is registered;
- program/site/search engine is canonical and allow-listed; dynamic program IDs originate only from ProgramDirectory;
- query size is valid;
- modality is a direct request rather than negation, question, hypothesis or mention;
- confidence is high, or a clarification is requested instead.

The existing `PermissionPolicy` remains the final risk boundary after this validation.

An unknown target after `abre` is not a program by default. A platform clause
such as `no YouTube` is classified before program selection and becomes a safe
browser search when it has a textual topic; no URL is fabricated.

## Transient context

`SessionContext` is created with each `NeskCore`, remains in RAM and is never read from/written to SQLite or memory. It records only successful tool outcomes. References must be both recent and type-compatible:

- program pronouns require the currently active successful program action;
- search pronouns require a recent search topic;
- a page/search never becomes an antecedent for `fecha ele`;
- no antecedent, expired antecedent or ambiguity produces a `ClarificationRequest`.

`PendingAction` (permission confirmation) and `PendingClarification` are independent states. A reply such as `sim`, `isso`, `Discord` or `a segunda` has command meaning only while it resolves the active clarification/confirmation of the right kind.

For the one approved multi-select case, `ClarificationReply` holds a tuple of
prevalidated `programs.open` Intents. Core executes them one at a time through
the usual ToolRegistry/PermissionPolicy and reports partial outcomes; selection
is not a blanket permission.

## Semantic provider boundary

`SemanticProvider.interpret(SemanticRequest, cancel)` is deliberately separate from `AIProvider.reply(messages)`. The request carries the current utterance, dynamically current allowed program IDs, static allowed capabilities and an empty/minimized typed context view. It carries no `Message` history, database rows, memory, logs, local paths, audio or credentials.

The default provider is `NullSemanticProvider`, so local commands and contextual references work without cloud/model dependencies. The optional OpenAI adapter is opt-in, uses a closed JSON schema and a bounded deadline. NeskCore invokes it outside its main lock, applies a per-turn cancellation token and discards a result if another turn starts or the runtime closes.

## Voice boundary

`VoiceService` and `SpeechPipeline` still converge on `NeskCore.handle()` after capture/STT. This extension changes no capture, VAD, pre-processing, decoding or STT correction behavior. The semantic remote path is bounded and does not authorize a separate voice-only execution path.
