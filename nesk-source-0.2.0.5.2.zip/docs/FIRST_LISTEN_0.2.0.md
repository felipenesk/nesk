# First Listen — arquitetura 0.2.0

## Objetivo
Provar entrada de voz real sem misturar TTS/wake word na mesma variável de teste.

```text
Qt button press
   ↓
VoiceService.start_listening()
   ↓
MicrophoneCapture / PortAudio
   ↓
CapturedAudio (PCM16, RAM)
   ↓
SpeechToTextProvider
   ↓
VoiceController
   ↓
NeskCore.handle(transcript)
   ↓
AssistantResult
   ↓
Qt conversation (texto)
```

## Boundaries
- `MicrophoneCapture` conhece hardware, mas não conhece Core.
- `SpeechToTextProvider` conhece áudio, mas não conhece Tools.
- `VoiceController` conecta STT ao Core.
- Core continua sendo a única rota de execução de ações.
- TTS é opcional no Controller e está `None` em First Listen.

## Local STT
Provider padrão: `FasterWhisperSTTProvider`.
- lazy load;
- CPU;
- `int8`;
- idioma `pt`;
- modelo `small`;
- VAD ativo;
- cache sob o data root do NESK.

## Cloud STT
Existe boundary opcional para transcrição cloud. O WAV é montado com `BytesIO`; nenhuma etapa exige arquivo temporário. O provider não é default e só deve ser selecionado explicitamente.

## Falhas esperadas
- sem permissão de microfone;
- dispositivo ocupado/indisponível;
- dependência de voz ausente;
- download inicial de modelo falhar;
- nenhuma fala reconhecida;
- áudio curto demais.

Todas devem retornar a UI para estado utilizável sem derrubar o Core.
