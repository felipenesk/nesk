# NESK — Camada local de Português (0.1.6)

A NLU local existe para ações de alta confiança que precisam continuar rápidas e disponíveis mesmo sem provider de IA.

## Princípio

Não criar centenas de `if frase == ...`.

O vocabulário fica concentrado em `src/nesk/nlu/lexicon.py` e a lógica de limpeza/interpretação em `src/nesk/nlu/ptbr.py`.

## Conceitos atuais

### Ações de abertura
Exemplos de verbos conhecidos: `abre`, `bota`, `coloca`, `inicia`, `executa`, `acessa`, `entra`, `chama`, `roda`.

### Pesquisa
Exemplos: `pesquisa`, `procura`, `busca`, `googla`.

### Molduras de pedido
Exemplos: `pode`, `você consegue`, `tem como`, `dá pra`, `por favor`.

### Preenchimento conversacional
Depois de uma intenção já ter sido detectada com segurança, expressões como `pra mim`, `aí`, `rapidinho`, `por favor` podem ser removidas do alvo.

### Aliases semânticos
Exemplos:

```text
bloco de notas -> notepad
meus arquivos -> explorer
calculadora -> calculator
zap -> whatsapp
chat gpt -> chatgpt
anthropic -> claude
```

A NLU transforma linguagem em **intenção estruturada**; ela não executa nada diretamente.

```text
"abre o bloco de notas pra mim"
        ↓
programs.open
name = notepad
        ↓
Tool Registry / Permission Policy
        ↓
WindowsProgramCatalog
```

## Política de segurança

Frases de discussão, negação ou instrução teórica não devem ser tratadas como pedido de execução.

```text
"não abre o youtube"                    -> nenhuma ação
"eu gosto de abrir o youtube"           -> nenhuma ação
"como abrir a calculadora?"             -> nenhuma ação
"talvez eu pesquise isso depois"        -> nenhuma ação
```

Quando houver dúvida, o roteador deve preferir `None` e deixar a conversa cair para o provider de IA.
