# Windows 10 field plan — Semantic Context

Use the packaged `NESK.exe` on the reference Windows 10 machine. Start with typed text to isolate NLU/context from speech recognition. Do not test multiple NESK instances at once.

## 1. Typed text: local regression

Expected direct result, no clarification:

1. `abre o Discord`
2. `fecha o Discord`
3. `inicia o Discord`
4. `pesquisa Minecraft 1.12.2 no Google`
5. `abre o YouTube`

## 2. Typed text: natural phrasing

Each must open Discord, never try to launch a literal filler string:

1. `boto o Discord`
2. `bota o Discord pra rodar`
3. `manda abrir o Discord`
4. `coloca o Discord aí`
5. `consegue abrir o Discord?`
6. `dá pra abrir o Discord?`
7. `abre essa parada aí, o Discord`

## 3. Typed text: context and clarification

1. `abre o Discord` → `fecha ele` — must close Discord.
2. `pesquisa Minecraft 1.12.2 no Google` → `agora procura isso no YouTube` — same query on YouTube.
3. `pesquisa Ice and Fire` → `agora vê no YouTube` — same query on YouTube.
4. Fresh session: `fecha ele` and `procura isso` — must ask, never act.
5. `abre aquele negócio` → `Discord` — must ask then open only after selection.
6. `abre Discord e Spotify` → `a segunda` — must open Spotify.
7. `abre aquele negócio` → `deixa, pesquisa Minecraft` — old clarification must disappear and search must run.

## 4. Typed text: safety

None may invoke a tool:

1. `não abre o Discord`
2. `não fecha o Discord`
3. `eu gosto de abrir o Discord`
4. `eu estava pensando em fechar o Discord`
5. `como eu faço para abrir o Discord?`
6. `talvez abre o Discord`
7. `seria legal abrir o Discord`
8. `me explica como fechar o Discord`

## 5. Voice subset

After text passes, repeat by push-to-talk with a short pause after each phrase:

1. `NESK, abre o Discord.`
2. `Fecha ele.`
3. `NESK, pesquisa Minecraft 1.12.2.`
4. `Agora procura isso no YouTube.`
5. `NESK, não fecha o Discord.`

Expected voice behavior remains the 0.2.0.5.2 contract: one capture/validation/STT path, no text rewrite to force a command, safe rejection if STT confidence is insufficient, and return to `IDLE`.
