# NESK 0.1.6 — Test Report

Data da build: 2026-08-20

## Resultado automatizado

- Pytest: **145/145 testes passaram**.
- Smoke test: **PASS**.
- `compileall` em `src/`, `scripts/` e `tests/`: **PASS**.
- Diagnóstico seguro: **PASS**.

## Áreas cobertas

- NLU PT-BR e variações naturais.
- Negação/discussão sem execução acidental.
- Aliases de programas e sites.
- Pesquisa Google/YouTube.
- Segurança de URLs.
- Catálogo de programas sem shell.
- Tool Registry e níveis de permissão.
- Status de CPU/RAM/disco.
- Contexto de sessão e persistência.
- Versionamento/adaptação do schema SQLite.
- Provider local fallback.
- Máquina de estados da futura camada Voice.
- Configuração de privacidade de áudio.

## Limitação do ambiente de build

O ambiente automatizado usado para montar esta release não possui PySide6 instalado, portanto a janela Qt não foi renderizada aqui. A sintaxe da UI foi compilada e a arquitetura já foi validada em builds anteriores no Windows 10; a alteração visual nova da 0.1.6 (card de RAM do próprio NESK) precisa ser confirmada no PC de referência.

A validação real de abertura de aplicativos Windows também continua dependendo do teste no Windows 10; os testes automatizados verificam resolução, segurança e chamadas de processo usando mocks/contratos.
