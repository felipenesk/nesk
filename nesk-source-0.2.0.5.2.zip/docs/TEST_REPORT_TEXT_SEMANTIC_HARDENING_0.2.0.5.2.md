# Relatório de validação — Text / Semantic Hardening 0.2.0.5.2

## Escopo validado

Esta entrega foi construída exclusivamente sobre `NESK_0.2.0.5.2_SemanticContext_source`. Foundation 0.1.x e Speech Pipeline 0.2.0.5.2 foram preservados: não houve alteração de arquitetura do pipeline de voz, TTS, wake word, memória persistente, web/knowledge, vision, shell nem automação genérica.

## Resultado

| Verificação | Resultado |
|---|---|
| Baseline antes das alterações | 347 testes aprovados |
| Coleta final | 396 testes |
| Suíte completa final | 396 aprovados |
| Compile check | aprovado para `src`, `scripts` e `tests` |
| Release check | aprovado |
| Smoke test | aprovado |
| Self-check headless Python | aprovado |
| Instalação limpa do pacote | aprovada |
| Build Windows x64 PyInstaller | aprovada |
| `NESK.exe --self-check` empacotado | aprovado |

O release check também reexecutou a suíte, smoke, self-check e instalação limpa. A build foi gerada em host Windows 10 x64 (10.0.19045) com Python 3.12.13 e PyInstaller 6.22.2.

## Regressões novas

`tests/test_text_semantic_hardening_0207.py` contém 49 regressões para:

- preâmbulos coloquiais positivos e preservação de negação/pergunta/hipótese/primeira pessoa;
- continuação de busca engine-only com e sem contexto;
- classificação de entidade YouTube antes de `programs.open`;
- ordenação de candidatos pelo texto do usuário;
- multi-select limitado, parcial, confirmação por item e cancelamento do lote pendente;
- Program Discovery: normalização, aliases, duplicidade, ambiguidade, shortcut inválido, target ausente, refresh, close seguro, cache forjado/stale, config, reparse/revalidação e privacy;
- proteção contra basename/PATH/variáveis de ambiente manipuladas, UNC, Desktop/Downloads, metadados path-like e vazamento de path em erro;
- provider remoto inventando programa/path e `allow_remote="false"` falhando fechado.

Além delas, a suíte integral preservou as regressões prévias de Foundation, contexto semântico, voz, STT e Speech Pipeline.

## Auditoria de segurança final

1. O cache não é fonte de autoridade: uma cache JSON válida e apontando para `.exe` existente não cria entrada ativa.
2. Targets dinâmicos são revalidados imediatamente antes de `Popen`; programas descobertos não ganham nome de processo para close.
3. O launch não aceita basename conhecido ou `PATH`: exige o `ProgramTarget` exato emitido pelo catálogo.
4. Raízes e `%VAR%` permitidas são obtidas por APIs Windows; ambiente do launcher, variável desconhecida, `$...`, UNC e device paths falham fechados.
5. A exceção para App Paths `HKLM` preserva a proveniência `machine`, é revalidada no launch e exclui perfil, Desktop, Downloads e TEMP.
6. Paths não atravessam `SemanticRequest`, provider, Intent, SessionContext, clarificação, Tool result ou logs de falha de launch.

## Limitações que permanecem intencionais

- Nenhum teste manual de microfone, STT de campo, Spotify/Riot/Steam reais ou App Paths de instalações reais foi realizado nesta rodada; o plano Windows 10 anexo cobre essa validação.
- Start Menu continua desativado até existir resolvedor nativo de `.lnk` sem shell e sem argumentos.
- Aplicativos descobertos podem abrir, mas não podem fechar sem uma identidade de processo explicitamente confiável.
- A garantia contra alteração de executável entre a última verificação e a criação do processo é limitada pelo TOCTOU normal do sistema operacional; NESK revalida o target conhecido e não introduz resolução textual/arbitrária.

## Próximo passo recomendado

Executar primeiro a seção de texto do plano Windows 10, depois repetir os mesmos casos por push-to-talk. Se texto estiver correto e voz falhar, registrar a transcrição e investigar STT/Speech antes de alterar esta camada semântica.
