# Program Discovery Alpha

## Objetivo

Permitir que o NESK reconheça e abra aplicativos Windows legitimamente instalados sem transformar texto, PATH, atalhos arbitrários ou executáveis encontrados no disco em autoridade de execução.

## Modelo

`ProgramDirectory` é a fonte única de identidade de programa para NLU, semântica, contexto e catálogo Windows.

```text
fonte local confiável
  -> DiscoveryRecord (ainda não executável)
  -> validação de proveniência, .exe, existência, raiz e escopo
  -> ProgramEntry
       identifier: ID opaco/canônico
       display_name: texto para UI/clarificação
       aliases: matching local
       launch_target: Path interno, nunca remoto
  -> WindowsProgramCatalog
  -> OpenProgramTool / ToolRegistry
```

O semantic layer recebe somente `identifier`, display e aliases por resolução local. `SemanticRequest.allowed_programs` contém IDs, nunca paths.

## Fontes Alpha

1. Built-ins Foundation existentes.
2. `config.programs` legado, com validação nova e restritiva.
3. Windows App Paths em HKCU/HKLM e WOW6432, usando somente o valor padrão de caminho qualificado.
4. Start Menu somente mediante resolvedor nativo explícito que devolva um `.exe` sem argumentos. A build não chama shell, CMD, PowerShell, COM automation ou um parser permissivo de `.lnk`.

Não são fontes: `PATH`, `WINDIR`/`SystemRoot`/`ProgramFiles` do ambiente do launcher, resolução por basename, scan de `C:\`, Desktop, Downloads, perfil de usuário fora das Known Folders, TEMP, UNC/device paths, arquivos de texto, `.cmd`, `.bat`, URLs, argumentos de linha de comando, texto do usuário ou saída do provider.

## Regras de aceitação

- Caminho absoluto; arquivo existente; extensão `.exe`.
- Depois da resolução de symlink/reparse point, o target deve continuar sob Program Files, Program Files (x86), Local AppData ou Roaming AppData obtidos por Known Folders do Windows. Não se usam variáveis de ambiente como raiz de confiança.
- A exceção é restrita a um record App Paths lido de `HKLM` com `registry_scope="machine"`: ele pode usar o `.exe` local exato registrado fora das raízes (por exemplo, instalação corporativa/jogo em `C:\Riot Games`). A flag de escopo é retida em `ProgramEntry` e conferida novamente no launch; nunca vale para config custom, HKCU ou Start Menu. UNC/device, perfil de usuário, Desktop, Downloads e TEMP continuam proibidos.
- O valor deve ser caminho puro, sem argumentos. Aspas são aceitas somente quando envolvem exatamente o caminho.
- `%ProgramFiles%`, `%ProgramFiles(x86)%`, `%LocalAppData%`, `%AppData%`, `%SystemRoot%` e `%WINDIR%` só são expandidos contra valores da API Windows. Variável desconhecida, percent malformado e sintaxe `$...` são rejeitados.
- O ID dinâmico é determinístico a partir do display e de um hash curto do target validado; o path bruto nunca é exposto ao provider.
- Display, aliases e hints recebidos de config/cache também são rejeitados se forem path-like, URL-like, drive-relative ou excessivamente longos; eles não podem carregar um path para UI/payload semântico.
- Mesmo target funde entradas. Mesmo alias/display com targets distintos retorna `AMBIGUOUS`; não há escolha por fuzzy matching.

## Cache

O cache é JSON local, versionado, atômico e descartável. Nesta Alpha ele é apenas uma saída diagnóstica de refresh: **não é lido para construir snapshot ativo**. Corrupção, schema estranho, target existente forjado, extensão inválida, path ausente e entradas stale não podem criar uma identidade executável. O refresh sempre enumera fontes reais, constrói snapshot novo e faz swap atômico.

## Open e close

`WindowsProgramCatalog.launch()` verifica novamente que o `ProgramTarget` pertence à entrada atual antes de `subprocess.Popen(shell=False)`.

`CloseProgramTool` não cria nomes de processo a partir de executável descoberto. Ele só aceita `PROCESS_NAMES` exatos já allow-listed pela Foundation. Logo, `abre X` pode funcionar e `fecha X` pode responder de forma segura que ainda não sabe fechar o app.

## Operação e observabilidade

O refresh ocorre no bootstrap e lê registros pontuais, sem varredura recursiva de disco. O log registra só contagem de records descobertos, não paths. Para depurar um problema real, valide por texto o display/alias e observe a resposta do catálogo; não inclua paths pessoais, dados de usuário ou credenciais em relatório.

## Evolução fora do Alpha

Uma fonte futura precisa preservar a mesma interface: retornar record local, sem argumentos, revalidável e com proveniência explícita. Identidade de processo para close exige uma decisão de segurança separada; não é inferida por nome parecido.
