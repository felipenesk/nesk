# Windows 10 Field Test — NESK 0.1.7

## 1. Boot
- Execute `INICIAR_NESK.bat`.
- Confirm the monochrome UI opens.
- Confirm version `0.1.7` is visible.
- Observe `NESK` RAM card and overall responsiveness.

## 2. Regression
```text
NESK, como está meu PC?
NESK, abre o bloco de notas
Nesk bota o navegador aí
abre o youtube pra mim
pesquisa Dragonsteel no YouTube
```

## 3. Safety / no-action
```text
não abre o youtube
eu gosto de abrir o youtube enquanto jogo
como abrir a calculadora?
```
Nothing should be launched.

## 4. Medium action confirmation
Open Discord first, then:
```text
fecha o discord
```
NESK must ask for confirmation and Discord must remain open.
Reply `não`: it must cancel.
Repeat and reply `sim`: only then may it close Discord.

## 5. Persistence/migration
- Close NESK normally and reopen it.
- Confirm there is no startup error.
- Existing history from the previous Foundation should remain available when persistence is enabled.

## 6. Diagnostics if anything fails
Send a screenshot plus:
```text
%LOCALAPPDATA%\NESK\logs\nesk.log
```
Do not send credentials or personal documents.
