# NESK 0.2.0.5.2 — Text / Semantic Hardening

## Escopo e método

Esta rodada foi feita exclusivamente sobre a fonte `NESK_0.2.0.5.2_SemanticContext_source`. Antes de alterar código foram lidos o contexto, a documentação, a implementação de texto/semântica/programas e o pipeline de voz. A linha de base foi executada sem modificações: **347 testes aprovados**.

O escopo é intencionalmente limitado à camada textual/semântica. Não foram adicionados TTS, wake word, escuta contínua, Memory Alpha/0.3, web/knowledge, vision, automação genérica, shell/CMD/PowerShell, execução arbitrária, integração Spotify/media ou mudança no `SpeechPipeline`.

## Fluxo final

```text
texto digitado ou transcrição finalizada
  -> LocalIntentRouter (comandos claros/offline)
  -> IntentResolutionCoordinator
       -> guarda de modalidade/segurança
       -> ProgramDirectory local validado
       -> SessionContext RAM-only
       -> LocalSemanticInterpreter composicional
       -> SemanticProvider opcional e fechado, somente se necessário
       -> Intent tipado e validado
  -> NeskCore._run_intent
  -> ToolRegistry -> PermissionPolicy -> Tool
```

O `SpeechPipeline` continua convergindo no mesmo `NeskCore.handle()` e não ganhou um caminho de execução próprio.

## Diagnóstico de causa-raiz e correções

| Problema de campo | Causa-raiz auditada | Correção aplicada |
|---|---|---|
| Preâmbulos como `ae mano`, `vei`, `tipo assim`, `po`, `cara` | `strip_request_prefixes()` só removia framing formal; `_starts_action()` só removia `agora/então/depois` | `strip_discourse_preamble()` remove uma sequência pequena de marcadores apenas no começo e é reutilizado nos parsers/guarda local. Ele não procura verbo no meio da frase. |
| `agora procura no YouTube` | `extract_search_request()` tratava `no youtube` como query e deixava o engine em Google | `SearchRequest.query=None` representa explicitamente “engine sem assunto”. Somente o resolver local consulta `SessionContext`; sem assunto recente há clarificação. |
| `abre o canal do alanzoka no YouTube` | O router emitia `programs.open` para qualquer alvo desconhecido após `abre`; o coordinator o deixava passar | A classificação de entidade/plataforma ocorre antes da seleção de programa e vira `browser.search(query="canal do alanzoka", engine="youtube")`, sem URL fabricada. Router e coordinator falham fechados para programa desconhecido. |
| Ordem invertida em `Discord e Bloco de Notas` | Matching por alias longo ordenava a coleção final pelo comprimento | `ProgramDirectory.mentions()` e o matcher de sites ordenam pela primeira ocorrência textual; aliases longos só desempatam spans sobrepostos. |
| `os dois` | `ClarificationReply` comportava apenas um `Intent` | A resposta carrega uma tupla explícita de `Intent`s pré-validados. O Core chama `_run_intent()` individualmente para cada um, com ToolRegistry e PermissionPolicy por item. |
| Catálogos de programas divergentes | Léxico, allowlist semântico congelado e catálogo Windows/config eram independentes | `ProgramDirectory` é injetado no router, coordinator, SessionContext e catálogo Windows. `SemanticRequest.allowed_programs` é lido do snapshot atual, sem paths. |

## Discourse handling e modalidade

Os marcadores reconhecidos são tokens curtos e compostos, não frases completas: por exemplo `ae`, `mano`, `vei`, `cara`, `tipo assim`, `po`, além dos conectores já aceitos. A remoção acontece somente no início e tem limite de iterações.

Assim, a modalidade restante ainda é avaliada antes de qualquer Tool:

- `mano não abre o Discord` mantém a negação;
- `cara eu estava pensando em abrir o Discord` continua sendo conversa em primeira pessoa;
- `tipo assim como eu faço pra abrir o Discord?` continua pergunta explicativa;
- `mano talvez eu abra o Discord depois` continua hipótese;
- `vei eu não quero que você abra o Discord` continua negação.

Não há uma regra “apague tudo até achar um verbo”. Isso evitaria falsos negativos de linguagem, mas quebraria a prioridade de segurança.

## Continuação de busca e SessionContext

`SessionContext` continua por instância, apenas em RAM, pequeno e tipado. Ele guarda somente `last_program`, `last_search_query`, `last_search_engine`, `active_topic` e uma clarificação pendente; não é SQLite, memória persistente nem histórico remoto.

Formas como `agora procura no YouTube`, `agora vê no YouTube`, `procura no YouTube`, `agora no YouTube`, `agora no Google` e `vê isso no YouTube` só reutilizam tópico de busca recente e compatível. Em uma sessão nova, pedem o assunto e não executam busca. A view enviada ao provider continua restrita a referências explícitas; a continuação implícita é resolvida localmente antes de qualquer chamada remota.

## Multi-select de clarificação

O contrato foi ampliado de modo restrito:

```text
ClarificationRequest (opções pré-validadas)
  -> ClarificationReply.intents: tuple[Intent, ...]
  -> NeskCore._run_clarification_batch()
       -> _run_intent(intent 1) -> ToolRegistry/Policy
       -> _run_intent(intent 2) -> ToolRegistry/Policy
```

`ambos`, `os dois`, `as duas`, `pode abrir os dois` e `abre os dois` só são válidos para uma clarificação pendente com exatamente duas opções compatíveis de `programs.open`. Não existe lista livre de ferramentas, argumentos livres ou batch de shell.

Se uma execução falhar, a resposta informa resultado parcial. Se uma ação exigir confirmação, o lote para nessa ação; confirmar uma delas não autoriza automaticamente a seguinte. Respostas mistas de tools não são elegíveis a multi-select.

## Program Discovery Alpha

### Separação de responsabilidades

```text
App Paths / config custom validada / resolvedor seguro de atalho futuro
  -> ProgramDirectory (snapshot local)
       -> ID canônico opaco + display name + aliases + launch target interno
       -> semantic/router/context veem somente identidade pública
  -> WindowsProgramCatalog resolve o launch target interno
  -> programs.open pelo ToolRegistry
```

`ProgramEntry.launch_target` permanece local ao diretório/catálogo. Ele não é incluído em `Intent`, `SemanticRequest`, payload remoto, `SessionContext`, logs de conteúdo ou clarificação.

### Fontes consideradas e política

- **Built-ins Foundation:** aliases existentes, sem ampliar a lista lexical manualmente.
- **Config custom existente:** aceita somente caminho absoluto para `.exe` existente, sem argumentos e dentro de Program Files, Program Files (x86), Local AppData ou Roaming AppData obtidos pelas Known Folders do Windows — nunca por variáveis de ambiente do processo.
- **Windows App Paths:** leitura local de `HKCU`/`HKLM` e da visualização WOW6432 do valor padrão documentado do registro. `HKCU` continua sujeito às raízes acima. Uma entrada `HKLM` pode apontar para uma instalação local legítima fora delas (por exemplo, biblioteca gerenciada em `C:\Riot Games`), mas somente para o `.exe` exato do valor padrão e com a proveniência `machine` preservada até o launch. A documentação da Microsoft descreve App Paths como registro de um caminho qualificado de executável: [Application Registration](https://learn.microsoft.com/en-us/windows/win32/shell/app-registration).
- **Start Menu:** as pastas Known Folders foram estudadas (a Microsoft define pastas Programs por usuário e comuns em [Known Folders](https://learn.microsoft.com/en-us/windows/win32/shell/knownfolderid)), mas a build não ativa parsing de `.lnk` por shell/PowerShell. Há somente um hook para um resolvedor nativo futuro que devolva um `.exe` sem argumentos; sem esse resolvedor, atalhos não se tornam autoridade de execução.

Não há varredura de `C:\`, PATH discovery, resolução por basename, execução de Desktop/Downloads, perfil de usuário, TEMP, UNC/device path, fuzzy matching de caminho, comando de shell, `taskkill` por substring ou path vindo do usuário/LLM. Variáveis como `%ProgramFiles%` são expandidas apenas contra Known Folders/Windows Directory obtidos por API; variáveis desconhecidas e o ambiente do launcher não ganham autoridade. Built-ins também resolvem somente seus alvos absolutos conhecidos por APIs Windows, nunca por `PATH`, `WINDIR` ou `SystemRoot` do ambiente.

### Validação, duplicidade e cache

- O alvo deve resolver para arquivo `.exe` existente e ficar dentro de uma raiz confiável depois de resolução de links/reparse points. A exceção estreita é somente App Paths `HKLM` com escopo `machine`, para target local exato fora das raízes; ela rejeita UNC/device, perfil de usuário, Desktop, Downloads e TEMP.
- Valores com argumentos, extensões não executáveis, caminhos ausentes, fonte não confiável, variável desconhecida e texto público path-like são descartados.
- Duas fontes para o mesmo target fundem aliases/proveniência; dois targets distintos com o mesmo nome geram ambiguidade determinística.
- O cache JSON é local, versionado, atômico e descartável, mas é deliberadamente **somente saída diagnóstica** nesta Alpha: nunca é carregado para criar uma entrada ativa. Todo bootstrap faz refresh das fontes reais; cache corrompido, stale ou forjado falha fechada por não ter autoridade de execução.
- O bootstrap faz um refresh pequeno de fontes registradas. Não há scan recursivo de disco; o snapshot em memória contém metadados mínimos.

### Abrir versus fechar

`programs.open` pode usar launch target descoberto quando ele foi validado pelo catálogo. `programs.close` não infere processo para app descoberto: continua limitado a nomes de processo exatos da allowlist Foundation. Para um app sem identidade de processo explícita, `fecha X` responde que ainda não sabe fechar com segurança.

Isso permite, por exemplo, abrir Spotify se instalado legitimamente/descoberto, mas não transforma `toca X no Spotify` em integração de mídia.

## Provider semântico e privacidade

A arquitetura `SemanticProvider -> SemanticCandidate -> IntentResolutionCoordinator -> Intent -> Core -> ToolRegistry` foi preservada. Provider não recebe ferramentas, shell, executáveis, paths, arquivos, SQLite, memória pessoal, áudio, histórico ou credenciais. O schema continua fechado.

O coordinator rejeita target de programa inexistente, caminho ou URL de provider. Um candidate de busca remoto vazio, path-like ou URL-like também não é convertido em argumento indireto. `semantic.allow_remote` é opt-in estrito: a string manual `"false"` não habilita provider remoto.

## Impacto de startup e memória

O refresh de discovery ocorre uma vez no bootstrap, lê fontes pontuais e não varre o disco. A resolução de Known Folders acontece somente para as raízes necessárias e o cache não é um atalho de autorização. O snapshot troca atômica e completamente sob lock; a camada semântica só mantém IDs, nomes, aliases e referências de curto prazo. Não foi feita alegação de benchmark de hardware: o impacto real de App Paths/instalações deve ser observado no Windows alvo.

## Testes automatizados

Foram acrescentados **49 testes** em `tests/test_text_semantic_hardening_0207.py`, cobrindo:

- todos os preâmbulos positivos e negativos solicitados;
- continuidade implícita, engine correto e sessão nova sem tópico;
- `abre ... no YouTube` como busca e alvo desconhecido sem `programs.open`;
- ordem de opções e primeira/segunda;
- os cinco textos de multi-select, resultado parcial, recusa de batch misto e confirmação individual;
- normalização/display/aliases, duplicatas, colisão de mesmo nome, atalho inválido, alvo ausente, cache corrompido/stale/forjado, config custom, raiz não confiável, extensão não suportada, refresh e close seguro;
- candidate remoto inventado/path-like e payload sem path, além de tentativa de launch por basename conhecido fora do catálogo, target removido e erro de launch sem vazamento de path;
- escopo `HKLM` revalidado, rejeição de Desktop/Downloads/UNC, metadados públicos path-like e expansão `%ProgramFiles%` imune a ambiente envenenado;
- `allow_remote="false"` falhando fechado.

A suíte final aprova **396 testes** (347 da baseline + 49 regressões novas). O resultado de release/check e build deve ser lido no relatório de entrega correspondente.

## Limitações e riscos restantes

- A enumeração App Paths, ACLs reais de `HKLM`, permissões e combinações de instaladores precisam de validação manual no Windows 10 alvo; os testes usam fixtures e doubles, não dependem de Spotify/Steam instalados no CI.
- Start Menu não é uma fonte ativa até existir resolvedor de `.lnk` nativo que mantenha a mesma política sem shell/argumentos.
- Close para apps descobertos fica propositalmente indisponível sem mapeamento exato de processo confiável.
- Discovery não é instalador, gerenciador de arquivos nem mecanismo para abrir documentos/URLs fornecidos pelo usuário.
- A validação de voz/STT continua necessária e deve ser tratada separadamente de falhas de texto: não foram feitas compensações semânticas para uma transcrição errada.

## Fora desta rodada

TTS, wake word, Memory Alpha/0.3, Knowledge/Web, Vision, automação genérica, shell, execução arbitrária, integração Spotify autenticada e controle de mídia permanecem fora de escopo.
