# Windows 10 — Plano de teste 0.2.0.5.2

## Preparação

1. Use Windows 10 x64 e, para execução a partir do código, Python 3.11 x64.
2. Feche qualquer instância da UI NESK antes dos probes para evitar dois modelos locais e disputa pelo microfone.
3. Conceda permissão de microfone ao aplicativo/terminal.
4. Rode VALIDAR_NESK.bat. Se houver dispositivo configurado não padrão, confirme que ele aparece no diagnóstico.

## 1. Benchmark seguro primeiro

Execute TESTAR_VOZ_QUALIDADE.bat.

- Pressione ENTER apenas antes de cada frase.
- Fale normalmente, sem prolongar artificialmente.
- Faça pausa curta ao terminar; não pressione ENTER durante a captura.
- Confirme que cada turno informa duração, Hz reais, endpoint ou timeout, tempo de STT, RTF, segmentos e RAM.
- Confirme que não houve ação da UI/Core e que não apareceu arquivo WAV/log de transcrição.

Frases:

1. NESK, abre o Discord.
2. NESK, fecha o Discord.
3. NESK, abre o YouTube para mim.
4. NESK, pesquisa Minecraft 1.12.2.
5. Abre o Discord.
6. Fecha o Discord.
7. Não.
8. Sim.

Registre para cada uma: aceita/rejeitada, transcrição exibida somente no console, endpoint/timeout, duração e RTF. Rejeição de baixa confiança é aceitável; execução não acontece nesse script.

## 2. Probe isolado

Execute TESTAR_STT.bat e diga:

    NESK, abre o YouTube.

Confirme:

- mesmo modelo é carregado no máximo uma vez nesse processo;
- o sample rate real é mostrado;
- uma pausa encerra por endpoint quando o nível permitir;
- o script não abre YouTube nem chama qualquer ferramenta.

## 3. UI push-to-talk

Abra NESK e teste, um por vez:

1. Toque muito curto no botão sem falar: retorno a IDLE e recusa simples.
2. Diga Não.: transcrição correta ou recusa segura.
3. Diga NESK, abre o Discord.: abre apenas o Discord permitido.
4. Diga NESK, fecha o Discord.: fecha o processo final permitido.
5. Repita cinco a dez turnos curtos. A UI deve sempre voltar a IDLE e não deve ficar presa em LISTENING/TRANSCRIBING.

Durante uma fala mais longa, solte o botão e tente cancelar/fechar a UI. Não pode haver execução de texto cancelado depois que a inferência terminar.

## 4. Segurança semântica

Na UI, estas frases não podem executar ação:

    NESK, não fecha o Discord.
    Eu estava pensando em fechar o Discord.
    Como eu faço para abrir a calculadora?

Se o STT errar ou a confiança for baixa, repita a fala. Não tente adaptar a frase a uma “forma de comando” para compensar o modelo.

## 5. Discord lifecycle

1. Feche Discord manualmente.
2. Peça para abrir Discord.
3. Aguarde a janela terminar de iniciar.
4. Peça para fechar Discord.

Confirme que Discord Stable/PTB/Canary funciona conforme a instalação e que Update.exe não foi encerrado. Se o processo final demorar mais que o limite, o resultado pode dizer que não parece aberto; reporte a demora, sem ampliar a allowlist.

## Critério de aceite de campo

- Nenhum travamento de UI ao armar captura.
- Nenhum áudio de turno anterior em turno novo.
- Nenhuma ação após cancelamento ou por frase negativa/conversacional.
- UI/probe/benchmark concordam quanto à aceitação/rejeição para gravações equivalentes.
- Dados de áudio/transcrição não persistem.
- Qualquer falha de driver/STT retorna a IDLE e permite nova tentativa.
