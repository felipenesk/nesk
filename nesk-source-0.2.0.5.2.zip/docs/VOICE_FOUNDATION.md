# NESK Voice Foundation — 0.1.6

A voz não deve criar um segundo assistente. Ela será apenas outro transporte para o mesmo Core.

## Fluxo alvo

```text
Push-to-Talk / Wake Word
        ↓
captura de áudio
        ↓
Speech-to-Text
        ↓
NeskCore.handle(texto)
        ↓
Tool / AI Provider
        ↓
resposta textual
        ↓
Text-to-Speech
```

## Estados já definidos

```text
DISABLED
IDLE
LISTENING
TRANSCRIBING
PROCESSING
SPEAKING
ERROR
```

A máquina de estados impede callbacks de áudio de virarem um conjunto de flags contraditórias.

## Ordem planejada

1. Push-to-Talk.
2. STT funcional.
3. TTS funcional.
4. Teste em segundo plano com jogo aberto.
5. Otimização de CPU/RAM.
6. Sessão de conversa contínua.
7. Wake word `NESK` apenas após Push-to-Talk estar estável.

## Privacidade padrão

`store_audio = false`.

Áudio bruto não deve ser persistido por padrão. Se no futuro houver gravação, precisa ser uma opção explícita e visível.
