# NESK Roadmap

## 0.1.x — Foundation ✅ CONCLUÍDA

Base validada no Windows 10 de referência:
- Core modular/provider-independent.
- NLU local PT-BR.
- Tools seguras + Permission Policy.
- Intent estruturada, confiança e confirmações.
- Memória-base com privacidade.
- Migrations de banco/config.
- Event Bus e Node abstraction.
- UI leve monocromática.
- Tray, restauração e shutdown limpo.

A linha `0.1.x` fica congelada. Só recebe correção se aparecer bug crítico.

## 0.2.x — First Voice

### 0.2.0 — First Listen
- Push-to-talk real.
- Captura de microfone em RAM.
- STT local real e provider-neutral.
- Transcrição → mesmo Core → resposta em texto.
- Diagnóstico de dispositivos/dependências.
- Sem TTS e sem wake word ainda.

### 0.2.0.2 — PT-BR STT Tuning
- Tuning conservador de idioma/hotwords/VAD.
- Probe isolado de STT e métricas sem conteúdo.
- Validado em campo com YouTube, Minecraft e Discord.

### 0.2.0.3 — Voice Input Hardening
- Confirmação natural/ambígua com regra de segurança explícita.
- Gate de silêncio antes do STT.
- Turnos consecutivos e shutdown do modelo endurecidos.
- Métricas técnicas de latência sem conteúdo.

### 0.2.0.5.1 — Speech Pipeline Hardening
- Front-end de áudio local e conservador antes do Whisper.
- Captura em blocos previsíveis, post-roll e rejeição de callback incompleto.
- Decodificação PT-BR reforçada para preservar formas como `abre/fecha` literalmente.
- Retry acústico de comando sem pós-correção de intent; discordância no verbo é rejeitada.
- Corpus de qualidade PT-BR isolado do Core para teste no notebook real.
- Detecção de processo do Discord endurecida para Stable/PTB/Canary.

### Próximos 0.2.x
- Testes com ruído/microfones reais e benchmark durante jogos.
- Seleção de microfone e UX de erros.
- Medição de latência/CPU/RAM durante jogos.
- Conversação de voz mais contínua.
- TTS real e identidade vocal.
- Wake word somente depois de push-to-talk confiável.
- Speaker verification somente após a voz básica estar estável.

## 0.3.x — Memory
- Memory Manager seletivo.
- Memória de projetos/preferências.
- Viewer/apagar/exportar memórias.
- NESK Vault criptografado.

## Futuro
- Internet/conhecimento atual.
- Visão autorizada.
- Android node.
- Wearables/óculos.
- Integração Sistema RPG.
- Self-development supervisionado.
