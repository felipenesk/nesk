# NESK Privacy Baseline — 0.2.0 / Semantic Context

## Regras
1. Conversas persistidas ficam no SQLite local quando habilitado.
2. Contexto da sessão não depende da persistência.
3. Logs não armazenam texto das conversas por padrão.
4. `local_only` é uma barreira de dados: memória nesse nível não pode ser marcada para cloud.
5. Memória automática permanece desativada.
6. **Áudio bruto permanece `store_audio=false` por padrão.**
7. First Listen captura PCM16 em RAM, processa o turno e descarta o buffer; não cria gravação local por padrão.
8. STT local é o provider padrão da `0.2.0`.
9. Um STT cloud só deve ser usado quando configurado explicitamente; nesse caso o áudio necessário à transcrição é enviado ao provider durante o turno.
10. Speaker verification continua apenas como boundary arquitetural; não existe cadastro biométrico ativo.
11. Chaves/tokens não devem ser armazenados no banco ou `config.json`.
12. `SessionContext` semântico é somente RAM e não é reidratado por `nesk.db`: ele guarda apenas último programa/tópico/ferramenta bem-sucedidos e uma clarificação curta.
13. O provider semântico remoto é desligado por padrão (`semantic.allow_remote=false`). Quando o usuário o habilita, ele recebe somente o texto atual, ações/alvos permitidos e uma view tipada de contexto estritamente necessária.
14. O provider semântico nunca recebe `deque` de mensagens, SQLite, `MemoryRepository`, itens `local_only`, logs, caminhos pessoais, áudio ou credenciais. Referências simples são resolvidas localmente antes da chamada remota sempre que possível.
15. O resultado remoto é candidato não executável: timeout, erro, schema inválido ou resposta tardia são descartados localmente.

## Cache do modelo local
O modelo STT baixado fica em `%LOCALAPPDATA%\NESK\models\` (ou `NESK_MODEL_DIR` quando explicitamente configurado). Ele contém pesos do modelo, não gravações do usuário.

## Limitação
`nesk.db` ainda não é criptografado como o futuro NESK Vault. Não use o NESK nesta fase para guardar senhas, documentos extremamente sensíveis ou tokens.

## Diagnóstico
`diagnostics.py`, `voice_diagnostics.py` e `support_report.py` foram desenhados para evitar chaves e conteúdo de conversa. O diagnóstico de voz pode exibir o nome técnico do dispositivo de microfone para facilitar depuração.
